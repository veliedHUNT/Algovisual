const CACHE = "algovisual-v2.1.0";
const ASSETS = [
  "/",
  "/index.html",
  "/styles.css?v=1",
  "/app.js?v=1",
  "/src/core.mjs",
  "/src/store.mjs",
  "/src/content.mjs",
  "/src/algorithms.mjs",
  "/src/learning-state.mjs",
  "/src/planner.mjs",
  "/src/review-engine.mjs",
  "/src/exam-config.mjs",
  "/src/exam-state.mjs",
  "/manifest.json",
  "/icon.svg",
  "/vendor/pdf.mjs",
  "/vendor/pdf.worker.mjs",
];
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE)
      .then((cache) => cache.addAll(ASSETS))
      .then(() => self.skipWaiting()),
  );
});
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k.startsWith("algovisual-") && k !== CACHE)
            .map((k) => caches.delete(k)),
        ),
      )
      .then(() => self.clients.claim()),
  );
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (
    event.request.method !== "GET" ||
    url.origin !== self.location.origin ||
    url.pathname.startsWith("/api/")
  )
    return;
  event.respondWith(
    fetch(event.request)
      .then((res) => {
        if (res.ok) {
          const copy = res.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, copy));
        }
        return res;
      })
      .catch(async () => {
        const hit = await caches.match(event.request);
        if (hit) return hit;
        if (event.request.mode === "navigate")
          return (await caches.match("/index.html")) || Response.error();
        return Response.error();
      }),
  );
});
