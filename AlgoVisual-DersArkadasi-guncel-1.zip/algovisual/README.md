# AlgoVisual × DersArkadaşı 2.1 — SınavKoçu

Önceki HTML/CSS/JavaScript ve Node.js projesi temel alınarak geliştirilen Türkçe öğrenme uygulaması. Bu sürüm tek cihazda çalışan bir çekirdek üründür; kapsamlı müfredat kütüphanesi veya çok kullanıcılı bulut hizmeti değildir.

## 2.1: SınavKoçu

Menü → **SınavKoçu** veya `http://127.0.0.4:8080/?v=21#examcoach`. İlk açılışta bir profil oluştur; TYT ve AYT gibi birden fazla sınavı aynı cihazda ayrı sonuçlarla takip edebilirsin. Her profil için hedef tarih, hedef net, çalışma dersleri, hazırlık beyanı, çalışma günleri ve ortak günlük süre belirlenir. AYT alanları Sayısal/Eşit ağırlık/Sözel; YDT dilleri İngilizce/Almanca/Fransızca/Rusça/Arapçadır. Ad, okul, telefon veya doğum tarihi istenmez.

### Çalışan akış

- **Genel Bakış:** Sınavım, Bugünkü Programım, Son Denemem, Eksik Konularım, Yanlışlar Defterim ve Gelişimim kartları.
- **Konularım:** Ders ve konu listeleri, beş durum (başlanmadı/çalışılıyor/tamamlandı/tekrar gerekli/eksik), ders ilerlemesi. Konu tamamlandı işaretlemek ölçülmüş başarı puanı üretmez. Hâkimiyet, mevcut ortak öğrenme motorundaki gerçek cevap ve tekrar kanıtlarını kullanır; üç ağırlıklı gözleme kadar “Henüz ölçülmedi”, daha sonra ön bilgiyle yumuşatılmış 0–100 gösterge gösterilir. Beş gözlemden önce otomatik zayıf konu kararı verilmez.
- **Çalışma Programım:** AlgoVisual’ın aynı planı, görev kimlikleri, zaman bütçesi ve sayacı kullanılır; ikinci planlama motoru yoktur. Tüm profiller toplam süreyi paylaşır. Hedef tarihi, hedef net farkı, konu durumu, zorluk, yeterli örneklemde ders sonuçları, yanlışlar, gecikmiş tekrarlar ve son çalışma tarihi önceliğe etki eder. Benzer öncelikli sınavlara azalan ağırlıkla sıra verilir. Tamamlanan, çalışan ve elle düzenlenen görevler korunur; molalar bütçeye dahildir. Plan motoru tarihleri ve gerçek odak sürelerini uydurmaz. Zaman yetersizse tüm müfredatı bitirme sözü verilmez.
- **Denemelerim:** Tam, ders, konu, eksik, süreli mini ve özel deneme. Kapsama göre soru sayısı/süre, geri sayım, soru haritası, önceki/sonraki, cevap değiştirme/boş bırakma/işaretleme, duraklatma/devam ve sayfa içi bitirme onayı. Cevaplar her değişiklikte, çalışan sayaç ayrıca 15 saniyede bir aynı IndexedDB kaydına yazılır. Yenilemede süre gerçek zamanla devam eder; duraklatılmış süre durur. Süre biterse sonuç bir kez hesaplanır. LGS tam denemesi sözel ve sayısal oturumları ayrı sayar; ikinci oturum öğrenci hazır olduğunda başlar, önceki oturum kilitlenir.
- **Dış deneme girişi:** Her zaman kullanılabilir. Gerçek doğru/yanlış/boş toplamı, kullanılan süre ve çözüm tarihi alınır. İsteğe bağlı konu ayrıntısı `dersKodu,konuKodu,doğru,yanlış,boş` satırlarıyla eklenir; ders toplamını aşamaz. Yalnız ders toplamı girildiyse konu hatası uydurulmaz.
- **Sonuçlar:** Toplam ve ders neti, doğru/yanlış/boş, varsa konu ayrıntısı, kullanılan süre, işaretli sorular ve açıklamalı çözüm. Negatif ve kesirli net korunur; yalnız gösterim yuvarlanır. Sınav puanı, sıralama veya yerleştirme tahmini yapılmaz.
- **Yanlışlar Defteri:** İsteğe bağlı otomatik yanlış kaydı, elle metin sorusu, beş hata nedeni, tekrar geçmişi ve aynı aralıklı tekrar motoruna kart ekleme. Aynı profil/soru yinelenmez. Doğru yeniden çözüm kaydı silmez. Boşlar deneme raporunda ayrı kalır; otomatik yanlış defterine eklenmez.
- **Gelişim Raporum:** Eş kapsamlı son/en iyi/ortalama/son 5 neti, hedef farkı, ders/toplam net grafiği, klavyeden seçilebilir grafik ölçümleri, konu tamamlama, gerçek çalışma süresi, doğru/yanlış/boş ve hata nedenleri. Farklı soru sayısı, ders bileşimi, tür, alan, dil ve kural sürümü birbirine karıştırılmaz; konu denemeleri konu kapsamına da ayrılır. Tam sınav hedefi mini deneme netiyle kıyaslanmaz. Yeni haftada rapor açılınca haftalık özet oluşturulur ve saklanır; “Raporu güncelle” ile güncel kayıtlar yeniden değerlendirilir. Konu gelişimi için önceki ve güncel dönemde en az üç gözlem gerekir.
- **AI Sınav Koçu:** Mevcut sunucu/Gemini köprüsü. Mesaj yalnız form gönderilince gider. Gerçek ölçüm özeti varsayılan olarak paylaşılmaz; öğrenci paylaşım kutusunu seçebilir ve gönderilecek özeti inceleyebilir. Özet en fazla 4.800 karakterdir; tam cevap geçmişi, belgeler ve API anahtarı içermez. Koç; plan nedenlerini, eksikleri, denemeyi ve stratejiyi açıklar; mesajına öğrenci tarafından eklenen yanlış soruyu açıklayabilir. AI kapalıyken bütün temel işlevler yerel çalışır. Bu koç sohbeti bellektedir, yenilemede silinir.

### Yapılandırma, kaynaklar ve içerik sınırı

Kurallar `src/exam-config.mjs` içinde **2026.1** sürümüyle tutulur. `examConfigVersions` önceki sürümleri saklamak için merkezi kayıttır; yeni yıl eklenirken eski kayıt değiştirilmeyip yeni sürüm eklenmelidir. Profil ve deneme kendi kural sürümünü, sonuç kendi yanlış bölenini saklar. Hedef tarihi öğrenci belirler; 2027 ve sonraki yıllara ait kılavuz doğrulanmış değildir. Resmî kılavuzların otomatik güncellenmesi yapılmaz.

| Yapı | Soru | Süre | Yanlış böleni |
| --- | ---: | ---: | ---: |
| LGS | 90 | 75 + 80 dakika | 3 |
| TYT | 120 | 165 dakika | 4 |
| AYT seçilen alanın testleri | 80 | 180 dakika | 4 |
| YDT seçilen dil | 80 | 120 dakika | 4 |

AYT kitapçığında dört testte toplam 160 soru bulunur; profil seçilen alandaki testlerin toplamını izler. Din kültürü muafiyetindeki alternatif felsefe testleri ve özel sınav tedbirleri bu başlangıç yapılandırmasında modellenmemiştir; bu uygulama resmî başvuru veya sınav uygulaması yerine geçmez.

Kaynaklar: [ÖSYM 2026-YKS kılavuzu](https://www.osym.gov.tr/2026yuksekogretim-kurumlari-sinavi-yks-kilavuzu), [ÖSYM 2026 SSS — süreler, diller ve ham net](https://dokuman.osym.gov.tr/pdfdokuman/2026/YKS/sss_yksd19022026.pdf), [MEB 2026 LGS kılavuzu — değerlendirme](https://www.meb.gov.tr/meb_iys_dosyalar/2026_03/23190605_LGS_BaYvuru_ve_Uygulama_Kilavuzu_2026.pdf), [MEB öğretim programları](https://mufredat.meb.gov.tr/Programlar.aspx). Konu listeleri çalışma takibi için düzenlenmiştir; resmî kazanımların bire bir/eksiksiz uzman doğrulamalı dökümü değildir.

**Soru kapsamı:** `exam-bank.mjs` içinde 31 özgün açıklamalı başlangıç sorusu ve konuyla eşleşen mevcut ders sınavları kullanılır. Bir TYT profilinde mevcut standart derslerle toplam 100 soru bulunur; her derste resmî tam deneme sayısına yetecek kadar soru yoktur. LGS ve AYT de başlangıç kapsamındadır; YDT’nin İngilizce dışındaki dilleri için hazır soru yoktur. Yeterli soru bulunmayan kapsam açıkça gösterilir; yapay/tekrarlı sorularla tam deneme doldurulmaz. Mini/konu denemesi seçilebilir, dış sonuç girilebilir veya açıklama/cevap anahtarı/konu/zorluk içeren özgün/izinli sorular JSON olarak eklenebilir (bir seferde 300, toplam 2.000). JSON anahtarı kullanıcı sorumluluğundadır; AI üretimi doğrulanmış sınav sorusu gibi notlandırılmaz. Eski soru bankasındaki özel sorular `examMapping: {exam,subject,topic,language?}` ile açıkça eşleştirilebilir. Telifli gerçek sınav soruları kopyalanmadı.

### Saklama, geçiş ve güvenlik

Aynı `algovisual-v3` IndexedDB veritabanı ve aynı şema-3 kök kaydı korunur. `examCoach.version=1` ek bir alandır; eski veride yoksa boş olarak eklenir. Ders, not, PDF, mevcut test, eski sonuç, tekrar, algoritma ve Linux verileri silinmez. JSON yedekleme/geri yükleme yeni alanın tamamını kapsar. Bozuk profil, tarih, soru, sayaç, çapraz profil konu kaydı, tutarsız net ve grafik kapsamı reddedilir. Mevcut revizyon denetimi ikinci sekmenin eski kaydı ezmesini engeller.

Profil düzenleme ekranından yalnız o sınavın verileri silinebilir; önce yedek indirilir ve öğrenci onayı alınır. Diğer profiller ve mevcut ders verileri korunur. Genel Ayarlar’daki tüm yerel verileri silme denetimi de geçerlidir. API anahtarı `.env` içinde yalnız sunucudadır; statik izin listesine yeni istemci modülleri eklendi, `.env` erişimi açılmadı. Anahtarlar ve kişisel yedekler ZIP’e dahil edilmez. Yeni metinler HTML kaçışıyla gösterilir; kod yürütme veya üçüncü taraf grafik bağımlılığı eklenmedi. Büyük UI/deneme/soru modülleri yalnız SınavKoçu gerektiğinde yüklenir ve ilk ziyaretlerinden sonra çevrimdışı önbelleğe alınır.

### Değişen dosyalar ve doğrulama

Yeni: `src/exam-config.mjs`, `src/exam-state.mjs`, `src/exam-bank.mjs`, `src/exam-engine.mjs`, `src/exam-ui.mjs`, `tests/exam-coach.test.mjs`, `tests/exam-ui.test.mjs`.

Güncellenen: `app.js`, `src/core.mjs`, `src/learning-state.mjs`, `src/planner.mjs`, `src/ai-server.cjs`, `server.js`, `sw.js`, `styles.css`, `index.html`, `package.json`, `README.md`. Eski planlama, test ve tekrar motorları genişletildi; paralel ve kopuk bir veri altyapısı kurulmadı.

Otomatik kontroller: `npm run check`, `npm test`. Yeni 47 test; dört profil türü ve AYT alanları/YDT dilleri, çift profil, tarih/süre değişimi, durum/eksik ölçümü, deneme/sayaç/duraklatma/süre sonu, LGS iki oturum, doğru/yanlış/boş ve farklı bölenler, dış sonuç, yanlış/yeniden çözüm/tek kart, grafik ayrımı, boş/küçük örneklem, AI kapalı çalışma, JSON turu, eski veri geçişi, bozuk yedek, özel soru bankası, profil silme, HTML kaçışı ve AI veri paylaşım sınırını kapsar. Önceki 108 test korunmuştur. Son çalıştırma: **155 test, 155 başarılı, 0 başarısız**.

Tarayıcı kontrolü ayrı 8081 test adresinde yapıldı: TYT ve AYT Eşit ağırlık profilleri, cevap/işaret/sayaç korunması, duraklatma/yenileme, sonuçta yanlış ve boşun ayrı sayımı, dış matematik denemelerinde 23→27 net ve 25 ortalama, yanlışın 1/1 başarılı yeniden çözümü, konu durumu, ortak 60 dakika sınırı ve haftalık rapor. Altı ana bölüm 390 px genişlikte taşma olmadan kontrol edildi. Ana 8080 alanına test denemeleri eklenmedi. Bu kontrol kapsamlı ekran okuyucu, gerçek sınav içeriği uzman incelemesi veya yüksek yük/güvenlik denetimi değildir.

## Başlatma

Node.js 22+ gerekir; Node.js 24 ile doğrulandı. Ek npm paketi kurulmaz. PDF.js projeye dahil edilmiştir.

Bu klasörde terminal aç:

```powershell
npm start
```

Windows'ta `Baslat.cmd` dosyasını çift tıklamak da sunucuyu başlatır. Tarayıcı: **http://127.0.0.4:8080**. Durdurmak için Ctrl+C; terminal kapanınca sunucu durur.

Port doluysa:

```powershell
$env:PORT = '8082'
npm start
```

Veriler adres ve porta özgüdür; port/adres değiştirmeden önce JSON yedeği al.

## Tamamlanan özellikler

- Koyu/açık tema, mobil menü, klavye erişimi, okunabilir formlar, arama, sınıf/ders/favori filtreleri, favoriler ve son açılan içerikler.
- Sınıf → ders → ünite → konu → hedef modeli. 43 okul/yazılım/güvenlik konusu, 172 açıklamalı mini sınav sorusu. On okul dersinde toplam 30 konu; ayrıntılı anlatım, çözümlü örnek, alıştırma, cevap kontrolü, sık yapılan hatalar, not ve sınav. Yeni içerik ekleme/düzenleme. Varsa ön koşul, alıştırma ve en az %60 mini sınav başarısıyla konu tamamlama.
- Çoktan seçmeli, doğru/yanlış ve kısa cevaplı testler; oluşturma, düzenleme, silme, kategori/etiket/zorluk, soru bankasından test, sıra karıştırma ve isteğe bağlı süre sınırı.
- Yenilemede cevapları ve kalan süreyi koruyan test akışı; puanlama, sonuçlar, açıklamalı inceleme, yanlışları tekrar çözme ve gerçek konu başarıları.
- Yanlış/boş cevaplardan aralıklı tekrar kartları. Dört değerlendirmeli yeni motor aralıkları performansa göre ayarlar; unutulan kart 10 dakika sonra yeniden açılır, uzun dönem aralığı en fazla 365 gündür.
- PDF yükleme, sayfa görüntüsü, seçilebilir metin paneli, sayfa gezinmesi, belge arama, favori sayfa ve sayfa notu. Seçilen bölüm not olarak işaretlenebilir.
- Belgeden kaynak sayfalı boşluk doldurma soruları ve kartlar, ilk uygun cümlelerden özet, sözcük sıklığından kavram adayları. Taslakları düzenleyip onaylamadan test kaydedilmez. Bu araçlar kural tabanlıdır; anlamsal AI analizi iddia edilmez.
- Dört AlgoVisual simülasyonu: değişken/aritmetik, koşul, döngü/liste toplamı, fonksiyon. Değişebilir girdiler, satır vurgusu, değişken snapshotları, geri/ileri, oynat/duraklat, hız, geçmiş, çıktı ve tahmin soruları. Boş liste ve negatif sayılar desteklenir.
- Python/C editörü: satır numarası, temel renklendirme, otomatik kayıt ve yenilemede kurtarma, yeni dosya, içe açma, yeniden adlandırma, örnek ve indirme.
- Python AST sözdizimi denetimi; öğrenci kodu yürütülmez. Python bulunmazsa/çevrimdışıyken temel yerel denetim. C için parantez/metin/yorum denetimi; derleyici değildir.
- Günlük süre hedefi, haftalık plan, isteğe bağlı odak sayacı, sayfa içi mola hatırlatması. Süre grafikleri yalnızca gerçek odak sayacı kayıtlarını kullanır. Test süresi ayrıca gösterilir; ders tamamlandı diye dakika eklenmez.
- Rapor/JSON dışa aktarma, yazdırma, doğrulanan JSON yedekleme/geri yükleme, kalıcı depolama isteme ve yerel veri silme.
- IndexedDB, PDF Blob saklama, eski localStorage sürümünden geçiş ve sekmeler arasında revizyon kontrolü. Eski sekme yeni kaydı ezemez; hata gösterilir.
- Service worker, PWA manifesti ve çevrimdışı uygulama kabuğu. Daha önce açılan temel modüller sunucu kapalıyken kullanılabilir.
- Backend üzerinden gerçek AI bağlantısı: sohbet, ipucu, seçime bağlı ilerleme özeti ve PDF sayfaları. Anahtar yokken sahte yanıt yoktur; gönderilecek belge metni ve karakter sınırı onay ekranında gösterilir.

Okul içerikleri başlangıç düzeyindedir. 9–10. sınıf altyapısı vardır; tüm derslerin kapsamlı içerikleri henüz eklenmemiştir. Resmî müfredat eşlemesi ve uzman doğrulaması iddia edilmez.

## 2.0: birbirine bağlı dört öğrenme sistemi

Menüde **Çalışma planım**, **Tekrar ve yanlışlar**, **Algoritma oyun alanı**, **Linux ve CTF laboratuvarı** ekranları bulunur. Önceki dört temel AlgoVisual simülasyonu ayrı menüsünde korunmuştur. 43 ders, 172 soru, PDF, kod editörü, Gemini bağlantısı ve Yahya–Mustafa Instagram bağlantıları devam eder.

### Çalışma planı

- Günlük 15/30/45/60/90/120/180 dakika veya 5–480 arasında özel süre; haftanın her günü için farklı süre ve 0 dakikalık dinlenme günü.
- Adı, dersi, tarihi, konu seçimi, önem derecesi ve beyan edilen hazırlık yüzdesi olan sınavlar; sınav ekleme, düzenleme ve silme.
- Ön koşullar, konu gözlemleri, yanlışlar, tekrar tarihleri, sınav yakınlığı ve son çalışma oturumlarına göre açıklamalı öncelik puanı. API gerekmez.
- Yedi günlük görünüm; başlat/duraklat/tamamla/yarına ertele; elle görev ekleme ve düzenleme; planı yeniden oluşturma.
- Bütçeye molalar dahil edilir. Tamamlanan, elle korunan veya çalışan görevler değişmez. Yeni süre bu görevlerden azsa ayar açık hata ile reddedilir; önce düzenlenebilir görev azaltılmalı veya güne özel süre ayrılmalıdır.
- Ertelenen görev yalnız bir kez taşınır. Bütçeye sığmıyorsa ertelenmiş iş listesinde kalır; sessizce kaybolmaz veya bütçeyi aşmaz.
- Sayaç gerçek geçen zamanı kaydeder; göreve yalnızca “Tamamlandı” demek tahmini dakikayı çalışma kaydı yapmaz. Sayaç durdurulana veya hedef süresine kadar geçen zamanı ölçer; dikkat/odak kalitesini ölçmez. Gece yarısı geçen süre günlere ayrılır. Mola çalışma süresine eklenmez.
- Önceki haftalık serbest notlar ve bağımsız odak sayacı, plan sayfasındaki açılır bölümde bulunur. İki sayaç aynı anda başlatılamaz.

Puanın temel bileşenleri: tamamlanmamış konu 20 puan, ölçülen eksiğe göre en fazla 60 puan, gelen tekrar 25 ve gecikmeye en fazla 20 ek puan; sınav puanı kalan gün, önem ve hazırlıkla değişir. Görevde puan ve gerekçeleri açılabilir. Bu öneri bir başarı garantisi değildir.

### Akıllı tekrar

[SM-2'nin yayımlanmış kolaylık faktörü yaklaşımından](https://www.supermemo.com/en/blog/application-of-a-computer-to-improve-the-results-obtained-in-working-with-the-supermemo-method) esinlenen, belgelenmiş bir başlangıç algoritmasıdır; birebir SM-2 veya FSRS uygulaması değildir.

Dört değerlendirme, 1/3/4/5 kalite değerlerine eşlenir. Başlangıç kolaylık faktörü 2,5'tir; yayımlanan faktör güncellemesi uygulanıp 1,3–3,2 aralığına alınır. Unutma 10 dakikalık yeniden öğrenme üretir. “Zor” önceki aralığı 0,6 ile kısaltır. Başarılı ilk tekrar 1, sonraki 6 gün temeliyle; kolay cevaplar ek büyümeyle planlanır. Aralık, geçmişe göre değişir ve 365 günü aşmaz. Bunlar dört düğmeye uyarlanan ürün kurallarıdır; klinik doğrulama veya kişiye uydurulmuş bir hafıza modeli iddia edilmez.

Soru bankasından farklı sorularla kart eklenir; yanlışlar öncelenir ve oturumda konular sırayla dolaşılır. Yetersiz soru açıkça bildirilir. Bugün/geciken/yarın/yedi gün, konu bazlı son–gelecek tarih, başarı/zorlanma sayısı ve gerçek değerlendirme grafiği gösterilir. Üç değerlendirmeden önce hafıza yorumu yapılmaz; sonrası da açıkça kaba tahmindir.

### Algoritma oyun alanı

Yeni 14 simülasyon: Bubble, Selection, Insertion, Merge ve Quick Sort; Linear/Binary Search; Stack, Queue, Linked List, BST; BFS, DFS, Dijkstra. Girdiler değiştirilir; kod satırı, değişkenler, görsel yapı, açıklama, çıktı ve geçmiş aynı snapshot'tan çizilir. İleri/geri/oynat/duraklat/sıfırla, hız ve adım seçimi çalışır. Sayfadan çıkınca animasyon durur.

Sıralama veya arama algoritmaları aynı veriyle yan yana karşılaştırılır. Değer karşılaştırması, takas, yazma ve adım sayısı gerçek simülasyondan gelir. Grafik çizme süresi ölçülmez; evrensel hız sonucu sunulmaz. Quick Sort son elemanı pivot seçen Lomuto bölmesidir. Dijkstra minimum düğümü doğrusal tarar; bu sürümün karmaşıklığı O(V² + E)'dir ve negatif kenar kabul etmez. Binary Search sırasız girdiyi reddeder. Stack/queue/list/BST eğitimsel veri yapılarıdır; diziye kopyalanan görsel snapshot maliyeti teorik işlemlerle karıştırılmaz.

Adım tahmininin ilk cevabı puanlanır; aynı adım tekrar puan kazandırmaz. Beş ek görev ve başarı geçmişi vardır. Yanlışlar ortak hâkimiyete, tekrar kartlarına ve plana bağlanır. Tek bir yanlışın etkisi ön bilgi ve ağırlıklarla sınırlanır.

Sınırlar: 24 sayı/yapı elemanı, 60 yapı işlemi, 12 graf düğümü, 40 kenar, 5.000 snapshot. Kod serbestçe yürütülmez; mevcut Python/C editörünün güvenli runner gereksinimi değişmez.

### Linux ve CTF laboratuvarı

Tarayıcıdaki sanal dosya sisteminde `pwd, ls, cd, mkdir, touch, cat, echo, cp, mv, rm, grep, find, head, tail, wc, clear, help`; ayrıca eğitimsel `chmod` ve `stat` bulunur. En fazla dört okuma komutu boru hattına bağlanır; `>`/`>>` yalnız sanal dosyaya yazar. Ok tuşları komut geçmişini dolaşır.

Bu bir POSIX kabuğu veya Linux sanal makinesi değildir. Kabuk değişkenleri, program yürütme, ağ araçları ve keyfî betikler yoktur. `grep` düz metin arar. `find -name` yıldız/soru işareti eşleştirmesini sınırlı dinamik programla yapar; kullanıcı regex'i çalıştırılmaz. İzinler basitleştirilmiş sahip kipleriyle öğretilir; tam kullanıcı/grup/ACL modeli yoktur.

Sekiz Linux görevi altı aşamayı açar. On başlangıç CTF'si: gizli mesaj, başarısız giriş günlüğü, dosya izni, DNS, HTTP kodu, hash/şifreleme farkı, parola ilkesi, yetkilendirme, örnek IP ve XSS farkındalığı. Her görevde açıklama, dosya alanı, ipucu, flag doğrulaması, puan ve başarı kaydı vardır. Doğru flag yanında gerekli sanal inceleme/dosya durumu da doğrulanır; yalnız komut metni yeterli değildir. İpucu puanı 100'den 80'e indirir; başarı tekrar puan kazandırmaz. Tüm adresler/kişiler/veriler kurgusaldır.

Terminal motorunda `eval`, `Function`, Node dosya erişimi, `child_process` veya ağ isteği yoktur. Hatalı işlem atomik geri alınır. Sınırlar: komut 1.000 karakter, 128 dosya/klasör, dosya 32.000 / toplam 200.000 karakter, çıktı 8.000, geçmiş 100 ve son 200 inceleme kanıtı. HTML çıktısı kaçışla metin olarak gösterilir. Sanal dosyaları sıfırlamak başarıları silmez.

### Ortak kayıt ve geçiş

IndexedDB adı ve ana schema-3 biçimi korunur; sürümlü `learning.version = 2` uzantısı eklenir. Eski yedekte bu alan yoksa mevcut kayıtlar korunup varsayılanlar oluşturulur. Eski test gözlemleri kimlikleriyle yalnız bir kez aktarılır. Tekrar kartlarının mevcut kimlik, soru, tarih ve aralığı korunur; yeni motor metaverisi eklenir.

Sınavlar, planlar, tamamlanan/ertelenen işler, tekrar geçmişi, konu gözlemleri, algoritma sonuçları, sanal dosyalar ve CTF başarıları aynı JSON yedeğine dahildir. Yeni alanlar boyut, tarih, benzersiz kimlik, bütçe, yol ve tekrar parametresi açısından doğrulanır. Eski sekmenin yeni kaydı ezmesini önleyen revizyon kontrolü korunur.

Planlama ve tekrar çalışması için Gemini gerekmez. İsteğe bağlı AI soru üretimi bu sürümde eklenmemiştir; mevcut AI sohbet/PDF asistanı korunur. Doğrulanmamış AI sorularına otomatik not verilmez.

## AI yapılandırması

Varsayılan sağlayıcı **Google Gemini**, seçilen model **`gemini-3.5-flash-lite`**. Model, [Google'ın resmî model sayfasında](https://ai.google.dev/gemini-api/docs/models/gemini-3.5-flash-lite) kararlı sürüm olarak listelenir (22 Ekim 2026).

1. [Google AI Studio](https://aistudio.google.com/apikey) üzerinden Gemini API anahtarı oluştur.
2. Bu klasördeki `env.example` dosyasını `.env` adıyla kopyala. Mevcut `.env` varsa üzerine yazma.
3. `GEMINI_API_KEY=` satırının sağına anahtarını ekleyip kaydet.
4. Sunucuyu Ctrl+C ile kapatıp `Baslat.cmd` veya `npm start` ile yeniden başlat.
5. Sitede AI Asistanı ekranından kısa bir soru gönder.

Node.js'in yerleşik okuyucusu `.env` dosyasını başlangıçta yükler; dosyayı değiştirdikten sonra yeniden başlatmak gerekir. Anahtarı sohbet kutusuna, `app.js` içine veya `env.example` dosyasına koyma. Anahtar yalnızca sunucuda kullanılır. Paylaşılacak ZIP'e `.env` ve `.env.*` dosyalarını dahil etme.

```dotenv
AI_PROVIDER=gemini
GEMINI_API_KEY=buraya_yalnizca_kendi_bilgisayarinda_anahtarini_ekle
GEMINI_MODEL=gemini-3.5-flash-lite
AI_MAX_OUTPUT_TOKENS=4096
AI_DAILY_REQUEST_LIMIT=100
HOST=127.0.0.4
PORT=8080
```

Gemini isteği doğrudan [resmî `generateContent` API'sine](https://ai.google.dev/api/generate-content) gönderilir. Anahtar `x-goog-api-key` başlığındadır; URL'ye eklenmez. Türkçe öğretim ve ipucu talimatları, konuşma geçmişi ve onaylanan belge metni mevcut asistandan bu servise aktarılır. Gemini 3 için düşük düşünme seviyesi seçilmiştir. Dahili düşünce parçaları kullanıcı yanıtı olarak gösterilmez.

API erişimi ve anahtarı pakete dahil değildir. Seçilen model Google projesinde erişilebilir olmalıdır. Ücret/kota Google hesabına bağlıdır; ücretsiz kullanım garantisi verilmez. 403 hatasında anahtarın proje/API izinlerini, 404'te model erişimini, 429'da Google kotasını kontrol et. Sağlık ekranındaki “yapılandırıldı” yalnızca anahtar bulunduğunu belirtir; sağlayıcı erişimi ilk gerçek mesajda doğrulanır.

Eski OpenAI veya Chat Completions uyumlu sağlayıcı desteği korunmuştur. Bunun için `AI_PROVIDER=openai`, `OPENAI_API_KEY`, `OPENAI_MODEL` ve gerekirse `OPENAI_BASE_URL` ayarla. Bu sağlayıcıda `max_completion_tokens` kullanılır; Gemini'de `generationConfig.maxOutputTokens` kullanılır. Sağlayıcı katmanı `src/ai-server.cjs` dosyasındadır.

Sınırlar: 6.000 karakter mesaj, 8 geçmiş ileti (her biri en fazla 3.000 karakter), 5.000 karakter ilerleme, 18.000 karakter belge bağlamı; 40 saniye sağlayıcı zaman aşımı. Çıktı 128–4.096 token arasında ayarlanabilir. 10 dakikada 30 POST, 2 eşzamanlı işlem ve günlük AI istek kotası uygulanır. Günlük sayaç süreç belleğindedir; yeniden başlatmada sıfırlanır. Parasal bütçe garantisi değildir; üretimde kalıcı kullanıcı kotası ve sağlayıcı bütçesi gerekir.

Yalnızca mesaj, sınırlı konuşma ve seçilen bağlam gönderilir. PDF metni gönderim öncesinde açıkça onaylanır. Belge içeriği sistem talimatı olarak değil, kullanıcı verisi olarak iletilir. Sohbet kaydı varsayılan kapalıdır; açılırsa cihazda tutulur. Sağlayıcının veri koşulları ayrıca geçerlidir. AI cevapları ve kaynak iddiaları kontrol edilmelidir.

**22 Ekim 2026'da yerel anahtarla canlı Gemini bağlantısı doğrulandı.** Sitenin AI asistanından “2x + 3 = 11” sorusu gönderildi; Gemini üç adımda x = 4 sonucunu ve yerine koyarak kontrolünü döndürdü. İlk seçilen 3.8 Flash iki kez 40 saniyelik zaman aşımına uğradığı için varsayılan model 3.5 Flash-Lite olarak güncellendi; bu modelle doğrudan API ve site akışı başarılı oldu. Bu deneme, kapsamlı eğitim kalitesi veya sürekli erişilebilirlik garantisi değildir. Gerçek anahtar yalnızca yerel .env dosyasındadır ve paylaşım paketine dahil edilmez.

Gemini istek biçimi, model/anahtar seçimi, geçmiş/bağlam sınırları, belge onayı, HTTP asistan akışı, zaman aşımı, kota/izin/model hataları, engellenen/boş/kesilen yanıtlar ve sırların sızmaması ayrıca sahte sağlayıcıyla otomatik test edildi. Otomatik testlerin yanıtları gerçek uygulamaya eklenmez.

## Python denetimi ve güvenli yürütme

`python` komutu varsa gerçek AST denetimi yapılır. Gerekirse `.env` içine `PYTHON_BIN` ile tam yol yaz. Sabit `ast.parse` betiği `-I -S` ile çalışır; öğrenci kodu yalnızca standart girdiden veri olarak okunur. 100.000 karakter ve 3,5 saniye sınırı vardır. AST çalışma zamanı/mantık hatalarını değerlendirmez.

**Python/C yürütme sandbox'ı kurulmuş değildir.** `/api/code/run`, `RUNNER_URL` yoksa 501 ve anlaşılır açıklama döner. Ayrı, doğrulanmış izolasyon servisini yönetici bağlayabilir:

```dotenv
RUNNER_URL=http://127.0.0.1:9000/run
RUNNER_TOKEN=servise_ozel_gizli_token
```

Runner'a POST:

```json
{"language":"python","source":"print(1)","stdin":"","limits":{"wallTimeMs":3000,"memoryMb":128,"network":false}}
```

Beklenen yanıt:

```json
{"stdout":"1\n","stderr":"","exitCode":0}
```

Yetkisiz kullanıcı, kapalı ağ, geçici dosya sistemi, CPU/bellek/process/çıktı sınırı ve otomatik sonlandırma runner tarafından zorunlu uygulanmalıdır. C derlemesi de izolasyonda yapılmalıdır. Bu sunucunun JSON limitlerini göndermesi tek başına güvenlik sağlamaz. Adapter 6 saniyede bağlantıyı keser; runner ayrıca işi öldürmelidir. Bu servisin kurulumu/doğrulanması sonraki entegrasyon işidir.

## Veri, yedek ve sınırlar

IndexedDB `algovisual-v3` çalışma verisi ve PDF'yi ayrı depolarda tutar. Tema ve son kodun kurtarma tamponu localStorage kullanır. Hesap/cihazlar arası senkronizasyon yoktur. Tarayıcı verileri temizlenirse kayıtlar kaybolabilir; yedek al.

İlk açılışta eski `algovisual-dersarkadasi-v1` kaydının test, sonuç, ders tamamlama, tekrar ve Python/C taslakları aktarılır. Eski sonuçlarda olmayan soru ayrıntıları oluşturulmaz. Eski tahminî dakikalar yeni gerçek süre grafiğine alınmaz. Eski anahtarlar otomatik silinmez.

Ayarlar → Yedeği indir. JSON; içerik, not, favori, ilerleme, test, sonuç, tekrar, plan, kod ve belge **metnini** içerir. PDF aslı dahil değildir; ayrıca sakla. Aynı adlı PDF'yi yeniden yüklemek görüntüyü metin kaydına bağlar. Belge değiştiyse sayfa notlarının eşleşmesini kontrol et.

Geri yükleme: en fazla 35 MB; veri yapısı, soru anahtarları, benzersiz kimlikler, sınırlar ve boyutlar doğrulanır. Mevcut veri için otomatik yedek indirilir, onaydan sonra veri kümesi değiştirilir. Tarayıcı indirmeyi engellerse önce elle yedek al. Birleştirme yoktur; açık test ve sayaç sıfırlanır. Eşzamanlı sekmede eski revizyonun kaydı reddedilir; kaydedilmemiş veriyi yedekleyip yenile.

PDF: 20 MB, 200 sayfa, sayfa başına 100.000 / toplam 1.500.000 metin karakteri. Açma/sayfa/işleme zaman aşımı vardır. Şifreli/bozuk PDF okunmayabilir. **OCR yoktur**; taranmış sayfalardan metin çıkarılamayabilir. Görüntü ve seçilebilir metin ayrı panellerdedir; çizim tabanlı vurgu ve tam konumlu metin katmanı yoktur. Vurgular sayfa notudur.

Kısa cevaplar tanımlı anahtarlarla Türkçe harf/boşluk normalizasyonuyla eşleştirilir. Anlamca benzer farklı ifade otomatik doğru sayılmayabilir.

## Mimari

- `index.html`, `styles.css`: arayüz ve tasarım sistemi.
- `app.js`: ekranlar, formlar ve etkileşimler.
- `src/core.mjs`: doğrulama, puanlama, tekrar, rapor ve belge mantığı; DOM'dan bağımsız.
- `src/store.mjs`: IndexedDB transaction, revizyon ve Blob'lar.
- `src/content.mjs`: başlangıç içerikleri.
- `src/algorithms.mjs`: girdiden hesaplanan algoritma snapshotları.
- `src/learning-state.mjs`: yeni veri uzantısı, geçiş, ortak hâkimiyet ve doğrulama.
- `src/planner.mjs`: sınav/süre/ön koşul öncelikleri, korunan plan ve görev sayacı.
- `src/review-engine.mjs`: dört değerlendirme, kart seçimi ve hafıza özeti.
- `src/playground.mjs`: 14 algoritma, sayaçlar, tahminler ve görevler.
- `src/linux-lab.mjs`: sanal terminal, dosya sistemi, aşamalar ve 10 CTF.
- `src/v2-ui.mjs`: yeni ekranlar; ağır algoritma/laboratuvar modülleri ilk kullanımda yüklenir.
- `src/ai-server.cjs`: AI sağlayıcısı.
- `server.js`: yerel sunucu, API kontrolleri, AST ve runner adapteri.
- `vendor/`: `pdfjs-dist@4.10.38`, PDF.js/worker, CMap ve standart fontlar. Apache-2.0 lisansı `vendor/LICENSE`; font lisansları kendi klasöründedir. CDN gerekmez.
- `sw.js`, `manifest.json`, `icon.svg`: çevrimdışı/PWA kabuğu.
- `tests/`: Node yerleşik test çalıştırıcısı.

## Kontroller

```powershell
npm run check
npm test
```

2.0 test kapsamı: önceki 50 teste ek olarak plan/tekrar, 14 algoritma, Linux/CTF ve modüller arası entegrasyon testleri. Son sonuç aşağıdaki 2.0 kontrol notunda kayıtlıdır.

Tarayıcı kontrolleri ayrı **8081 test adresinde** yapıldı; deneme sonuçları 8080 ana çalışma alanına eklenmedi:

- Not/favori/alıştırmanın yenilemede korunması; seçili test cevabı ve kaldığı sorudan devam.
- Mini sınav 1/2 doğru → %50, yanlış inceleme ve tekrar kartı; üç soru tipli test 3/3 → %100.
- Gerçek iki sayfalı PDF yükleme/görüntü/metin; ikinci sayfada arama, favori, dört kaynaklı taslağın onayla teste kaydı.
- Python dosyası, kodun yenilemede korunması, eksik `:` için AST hatası, runner yokluğu mesajı.
- AlgoVisual ileri adım/satır/değişken/geçmiş; AI anahtarı yokluğu ve temel modüllerin devam etmesi.
- JSON indirme ve aynı yedeği geri yükleme.
- 390 px mobil / 768 px tablette sekiz ana ekran; yatay taşma görülmedi.
- Test sunucusu kapalıyken yenileme ve ders gezinmesi önbellekten çalıştı.

Tam tarayıcı/ekran okuyucu matrisi, yük testi ve bağımsız güvenlik denetimi yapılmadı.

### 2.0 kontrol notu — 23 Ekim 2026

- **108 otomatik test çalıştı, 108 geçti, 0 hata:** günlük bütçe/mola, sınav yakınlığı, ön koşul, elle korunan görev, tek seferlik erteleme, gerçek süre/gece yarısı, SM-2 uyarlaması, dört derece, tüm algoritmaların sınır girdileri, tahmin idempotansı, atomik sanal işlemler, 10 CTF'nin tamamlanması, yedek ve entegrasyon zinciri kapsanır.
- Ayrı 8081 adresinde 15 dakikalık plan, sınav ekleyince öncelik değişimi, başlat/yenile/duraklat ile gerçek süre kaydı; Bubble–Quick karşılaştırması, geri/ileri/oynat/duraklat; yanlış tahmin → kart → değerlendirme → yeni tarih; terminalden 8 görev ve bir CTF; yenilemede dosya/başarı korunması doğrulandı.
- Dört yeni ekran 390 px genişlikte kontrol edildi, yatay taşma görülmedi. Linux ekranı açık tema ile incelendi. Terminalde HTML örneği metin kaldı, DOM'da resim/olay işleyicisi oluşmadı.
- Ana adreste güncelleme öncesi JSON yedeği alındı. Bu gerçek yedek yeni geçişten geçirildi; mevcut tüm alanların birebir korunduğu doğrulandı. Test sonuçları 8080 alanına eklenmedi.
- FSRS, tam Linux/POSIX, gerçek ağ saldırısı, serbest Python/C yürütme, AI ile otomatik yeni soru üretimi ve uzman müfredat doğrulaması bu sürümün tamamlanmış özellikleri değildir.

## Dağıtım ve sonraki adımlar

Sunucu yalnızca loopback adresinde çalışır. Statik dosyalar izin listesiyle sunulur; `.env`, sunucu kaynağı, testler ve yedekler webden okunamaz. CSP, aynı origin, içerik türü, istek boyutu/hızı ve zaman sınırları vardır. Bu yerel sunucu internete açık üretim hizmeti değildir.

Uzaktan kullanım öncesinde HTTPS, güvenli oturum, kullanıcı verisi/izinleri, kalıcı kotalar, sır yönetimi, izleme ve güvenlik testleri gerekir.

Sıradaki işler: uzman doğrulamalı geniş müfredat, güvenli runner, AI kaynaklarının ve kullanım maliyetinin kapsamlı değerlendirmesi, OCR/gelişmiş PDF katmanı ve gerekirse hesap/senkronizasyon. Bunlar tamamlanmış gibi gösterilmez.
