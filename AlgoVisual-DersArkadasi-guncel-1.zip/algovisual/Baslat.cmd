@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 22 veya uzeri gerekli. https://nodejs.org adresinden kurun.
  pause
  exit /b 1
)
echo AlgoVisual - http://127.0.0.4:8080
echo Durdurmak icin Ctrl+C kullanin.
node server.js
pause
