import { esc as e, answerText } from "./core.mjs";
import {
  localDay,
  shiftDay,
  validDay,
  daysBetween,
  topicCatalog,
  mastery,
  upgradeLearning,
  recordEvidence,
} from "./learning-state.mjs";
import {
  availableMinutes,
  rebuildPlan,
  validateExam,
  editTask,
  deferTask,
  startTask,
  settleTask,
  taskElapsed,
  configureStudyTime,
} from "./planner.mjs";
import {
  ratings,
  isDue,
  rateCard,
  addBankReviews,
  reviewSummary,
} from "./review-engine.mjs";
const $ = (s) => document.querySelector(s);
const button = (name, label, id = "", style = "secondary", disabled = false) =>
  `<button type="button" class="btn ${style}" data-action="v2-${name}" data-id="${e(id)}" ${disabled ? "disabled" : ""}>${e(label)}</button>`;
const link = (route, label) =>
  `<a class="btn ghost small" href="#${e(route)}">${e(label)}</a>`;
const card = (title, body) =>
  `<section class="card"><div class="card-header"><h2>${e(title)}</h2></div>${body}</section>`;
const heading = (title, description) =>
  `<div class="page-heading"><div><span class="eyebrow">ALGOVISUAL 2.0 · BİRLİKTE ÖĞREN</span><h1>${e(title)}</h1><p>${e(description)}</p></div></div>`;
const empty = (text) => `<div class="empty"><p>${e(text)}</p></div>`;
const option = (value, label, current) =>
  `<option value="${e(value)}" ${String(value) === String(current) ? "selected" : ""}>${e(label)}</option>`;
const metric = (title, value, note) =>
  `<div class="stat"><small>${e(title)}</small><div class="stat-value">${e(value)}</div><small>${e(note)}</small></div>`;
const dateLabel = (date) =>
  new Date(date + "T12:00:00").toLocaleDateString("tr-TR", {
    day: "numeric",
    month: "short",
    weekday: "short",
  });
const topicLabel = (state, id) =>
  topicCatalog(state).find((t) => t.id === id)?.label ||
  state.learning.topics.find((t) => t.id === id)?.label ||
  state.review.find((c) => c.topic === id)?.question.tag ||
  id;
let playground,
  linux,
  examEditor = null,
  reviewShown = new Set(),
  loop = null,
  clockBusy = false,
  labFocus = false;
let sim = {
  kind: "bubble",
  input: "8, 3, 6, 1",
  parameter: "5",
  compare: "",
  trace: null,
  other: null,
  index: 0,
  speed: 900,
};
const planDate = (id) => (validDay(id) ? id : localDay());
export function ready(page, id, state) {
  return (
    (page !== "playground" || Boolean(playground)) &&
    (page !== "linuxlab" || Boolean(linux && state.learning.lab)) &&
    (page !== "coach" ||
      state.learning.plans.some((p) => p.date === planDate(id)))
  );
}
export async function prepare(page, id, ctx) {
  let changed = false;
  if (page === "playground" && !playground) {
    playground = await import("./playground.mjs");
    sim.trace = playground.buildSimulation(sim.kind, sim.input, sim.parameter);
  }
  if (page === "linuxlab") {
    linux ??= await import("./linux-lab.mjs");
    if (!ctx.state.learning.lab) {
      ctx.state.learning.lab = linux.createLab();
      changed = true;
    }
  }
  if (
    page === "coach" &&
    !ctx.state.learning.plans.some((p) => p.date === planDate(id))
  ) {
    rebuildPlan(ctx.state, planDate(id));
    changed = true;
  }
  if (changed) await ctx.save();
}
export function leave(page) {
  if (page !== "playground") pauseSimulation();
}
export function pauseSimulation() {
  if (loop) {
    clearInterval(loop);
    loop = null;
  }
}
function progressTable(state) {
  if (!state.learning.topics.length)
    return empty(
      "Henüz ölçüm yok. Bir test, tekrar veya laboratuvar göreviyle başla.",
    );
  return `<div class="table-wrap"><table><thead><tr><th>Konu</th><th>Gözlem</th><th>Hâkimiyet göstergesi</th></tr></thead><tbody>${state.learning.topics
    .slice()
    .sort((a, b) => b.last.localeCompare(a.last))
    .slice(0, 20)
    .map((t) => {
      const m = mastery(state, t.id);
      return `<tr><td>${e(topicLabel(state, t.id))}</td><td>${Math.round(m.observations * 100) / 100}</td><td>%${m.score} <small>(tahmin)</small></td></tr>`;
    })
    .join(
      "",
    )}</tbody></table></div><p class="input-hint">Test, tekrar, algoritma ve CTF gözlemleri aynı göstergede birleşir. Ön bilgi ağırlığı tek bir yanlışın etkisini sınırlar; bu bir sınav notu veya kesin hatırlama olasılığı değildir.</p>`;
}
function coach(ctx, id) {
  const state = ctx.state,
    date = planDate(id),
    plan = state.learning.plans.find((p) => p.date === date),
    today = localDay();
  const done = plan.tasks.filter((t) => t.status === "done"),
    active = plan.tasks.filter((t) => t.status === "pending");
  const total = plan.tasks
      .filter((t) => t.status !== "deferred")
      .reduce((n, t) => n + t.minutes, 0),
    completed = done.reduce((n, t) => n + t.minutes, 0);
  const logged = state.sessions
    .filter((s) => s.date === date)
    .reduce((n, s) => n + s.seconds, 0);
  const selected = state.learning.exams.find((x) => x.id === examEditor);
  const catalogue = topicCatalog(state),
    subjects = [...new Set(catalogue.map((t) => t.subject))];
  const examForm = `<form data-v2="exam" data-id="${e(selected?.id || "")}"><div class="form-grid">
    <label class="field">Sınav adı<input name="title" maxlength="200" value="${e(selected?.title || "")}" required></label>
    <label class="field">Ders<select name="subject">${subjects.map((s) => option(s, s, selected?.subject)).join("")}</select></label>
    <label class="field">Sınav tarihi<input type="date" name="date" value="${selected?.date || shiftDay(today, 7)}" required></label>
    <label class="field">Önem derecesi<select name="importance">${[
      [1, "Normal"],
      [2, "Önemli"],
      [3, "Çok önemli"],
    ]
      .map(([v, l]) => option(v, l, selected?.importance || 2))
      .join("")}</select></label>
    <label class="field">Hazırlık durumu (%)<input type="number" name="prepared" min="0" max="100" value="${selected?.prepared || 0}" required></label>
    </div><details><summary>Sınav konularını seç (${selected?.topics.length || 0} seçili)</summary><div class="v2-topic-picker">${catalogue.map((t) => `<label class="check"><input type="checkbox" name="topics" value="${e(t.id)}" ${selected?.topics.includes(t.id) ? "checked" : ""}>${e(t.subject + " / " + t.label)}</label>`).join("")}</div></details>
    <p class="input-hint">Konu seçmezsen seçtiğin dersin konuları değerlendirilir. Hazırlık yüzdesi senin beyanındır.</p><div class="actions"><button class="btn">${selected ? "Sınavı güncelle" : "Sınav ekle"}</button>${selected ? button("exam-cancel", "Vazgeç", "", "ghost") : ""}</div></form>`;
  const backlog = state.learning.plans
    .filter((p) => p.date < date)
    .flatMap((p) =>
      p.tasks
        .filter(
          (t) =>
            t.status === "deferred" && t.deferUntil <= date && !t.carriedTo,
        )
        .map((t) => ({ ...t, sourceDate: p.date })),
    );
  const rows = plan.tasks
    .map((t) => {
      const running =
        state.learning.activeTask?.date === date &&
        state.learning.activeTask?.taskId === t.id;
      return `<article class="v2-task ${t.status}" data-task="${e(t.id)}"><div class="v2-task-header"><div><span class="tag">${t.kind === "break" ? "MOLA" : t.kind === "review" ? "TEKRAR" : t.manual ? "SANA AİT" : "ÇALIŞMA"}</span><h3>${e(t.title)}</h3><small>${t.minutes} dk · ${t.manual ? "Elle düzenlendi" : t.score + " öncelik puanı"} · ${t.status === "done" ? "Tamamlandı" : t.status === "deferred" ? "Ertelendi: " + t.deferUntil : "Bekliyor"}</small></div>${t.status === "done" ? '<span class="correct">✓</span>' : ""}</div>
      <details><summary>Neden bu görev?</summary><ul>${t.reasons.map((r) => `<li>${e(r)}</li>`).join("")}</ul></details>
      ${running ? "<pPlaceholder/>" : ""}${
        t.status === "pending"
          ? `<div class="actions">
      ${button("task-start", running && state.learning.activeTask.startedAt !== null ? "Çalışılıyor" : "Çalışmaya başla", t.id, "", running && state.learning.activeTask.startedAt !== null)}
      ${button("task-pause", "Duraklat", t.id, "secondary", !running || state.learning.activeTask.startedAt === null)}
      ${button("task-done", "Tamamlandı", t.id)}
      ${button("task-defer", "Yarına ertele", t.id, "ghost")}${link(t.route, t.kind === "break" ? "Plana dön" : "İçeriği aç")}</div>
      <details><summary>Görevi değiştir</summary><form data-v2="task-edit" data-id="${e(t.id)}" data-date="${date}" class="form-grid"><label class="field">Görev adı<input name="title" maxlength="200" value="${e(t.title)}" required></label><label class="field">Tahmini süre (dk)<input name="minutes" type="number" min="1" max="480" value="${t.minutes}" required></label><button class="btn secondary">Değişikliği koru</button></form></details>`
          : ""
      }</article>`;
    })
    .join("")
    .replaceAll(
      "<pPlaceholder/>",
      `<p class="v2-clock" id="v2TaskClock">Kaydedilen süre: ${Math.floor(taskElapsed(state) / 60)} dk ${taskElapsed(state) % 60} sn</p>`,
    );
  return (
    heading(
      "Zamanını öğrenmeye dönüştür.",
      "Sınavların, eksiklerin, tekrarların ve gerçek çalışma kayıtlarınla güncellenen plan.",
    ) +
    `<div class="v2-week-nav">${Array.from({ length: 7 }, (_, i) =>
      shiftDay(today, i),
    )
      .map(
        (d) =>
          `<a href="#coach/${d}" class="v2-day ${d === date ? "selected" : ""}"><strong>${e(dateLabel(d))}</strong><span>${availableMinutes(state, d)} dk</span></a>`,
      )
      .join("")}</div>
    <div class="stats">${metric("Kullanılabilir süre", plan.capacity + " dk", dateLabel(date))}${metric("Planlanan", total + " dk", "Molalar dahil")}${metric("Tamamlanan", done.length + " görev", "Tahmini görev süresi: " + completed + " dk")}${metric("Gerçek odak süresi", Math.floor(logged / 60) + " dk " + (logged % 60) + " sn", "Yalnız çalışan sayaçtan")}</div>
    <div class="two-col"><div>${card(
      "Planın · " + dateLabel(date),
      `<div class="progress" role="progressbar" aria-label="Günlük görev ilerlemesi" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${total ? Math.round((100 * completed) / total) : 0}"><span style="width:${total ? (100 * completed) / total : 0}%"></span></div><p class="input-hint">Saatler başlangıç saatin bilinmeden uydurulmaz. Görev tamamlamak otomatik çalışma dakikası eklemez.</p>
      ${total > plan.capacity ? '<div class="notice warning">Tamamlanan veya elle korunan görevler yeni süreyi aşıyor. Geçmiş korunmuştur; yeni otomatik görev eklenmedi. Düzenlenebilir görevlerin sürelerini azaltabilirsin.</div>' : ""}
      ${backlog.length ? `<div class="notice warning"><strong>Bütçeye sığmayı bekleyen ${backlog.length} ertelenmiş görev</strong><p>Süre sınırı korunur; bu görevler kaybolmaz. Uygun yer açıldığında plana alınır.</p>${backlog.map((t) => link("coach/" + t.sourceDate, t.title + " · " + t.minutes + " dk")).join("")}</div>` : ""}
      ${rows || empty("Bugün için süre ayrılmamış veya uygun görev bulunmuyor. Süreni ve ön koşulları kontrol et.")}
      <div class="actions">${button("plan-rebuild", "Bugünkü planı yeniden oluştur", date)}${link("review", "Tekrar kontrol paneli")}</div>`,
    )}
      ${card("Kendi görevini ekle", `<form data-v2="task-add" data-date="${date}" class="form-grid"><label class="field">Görev adı<input name="title" maxlength="200" required></label><label class="field">İlgili konu<select name="topic">${catalogue.map((t) => option(t.id, t.label, "")).join("")}</select></label><label class="field">Süre (dk)<input name="minutes" type="number" min="1" max="480" value="15" required></label><button class="btn secondary">Görevi ekle</button></form>`)}
      ${card(
        "Sınav takvimin",
        state.learning.exams.length
          ? state.learning.exams
              .slice()
              .sort((a, b) => a.date.localeCompare(b.date))
              .map(
                (x) =>
                  `<div class="row"><div><strong>${e(x.title)}</strong><small>${e(x.subject)} · ${x.date} · ${daysBetween(today, x.date) < 0 ? "Tarihi geçti" : daysBetween(today, x.date) + " gün kaldı"} · hazırlık %${x.prepared}</small></div><div class="row-actions">${button("exam-edit", "Düzenle", x.id, "ghost small")}${button("exam-delete", "Sil", x.id, "ghost small")}</div></div>`,
              )
              .join("")
          : empty(
              "İlk sınavını eklediğinde yaklaşan sınavlar öncelikleri etkileyecek.",
            ),
      )}
      ${card(selected ? "Sınavını düzenle" : "Yeni sınav", examForm)}
    </div><aside>${card("Sana uygun çalışma süresi", `<form data-v2="availability"><label class="field">Günlük süre seç<select data-v2-change="duration">${[15, 30, 45, 60, 90, 120, 180].map((n) => option(n, n + " dakika", state.settings.dailyMinutes)).join("")}${option("custom", "Özel süre", ![15, 30, 45, 60, 90, 120, 180].includes(state.settings.dailyMinutes) ? "custom" : "")}</select></label><label class="field">Günlük dakika<input id="v2Minutes" type="number" name="daily" min="5" max="480" value="${state.settings.dailyMinutes}" required></label><details><summary>Haftanın günlerine farklı süre ayır</summary><p class="input-hint">Boş alan günlük süreyi kullanır; 0 dinlenme günüdür.</p>${["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"].map((d, i) => `<label class="field">${d}<input name="day${i}" type="number" min="0" max="480" value="${state.learning.availability[i] ?? ""}" placeholder="Günlük süreyi kullan"></label>`).join("")}</details><div class="actions"><button class="btn">Süreleri kaydet</button></div></form>`)}
      ${card("Ortak öğrenme ilerlemen", progressTable(state))}
      <details class="card"><summary>Haftalık notlar ve bağımsız odak sayacı</summary>${ctx.legacyCoach()}</details>
    </aside></div>`
  );
}
function review(ctx) {
  const state = ctx.state,
    summary = reviewSummary(state),
    catalog = topicCatalog(state);
  const pool = summary.due
    .slice()
    .sort(
      (a, b) =>
        a.due.localeCompare(b.due) ||
        (b.srs?.failures || 0) - (a.srs?.failures || 0),
    );
  // Interleave topics so the same topic does not occupy the whole session.
  const groups = new Map();
  for (const c of pool) {
    if (!groups.has(c.topic)) groups.set(c.topic, []);
    groups.get(c.topic).push(c);
  }
  const cards = [];
  while (cards.length < 12 && [...groups.values()].some((a) => a.length))
    for (const a of groups.values())
      if (a.length && cards.length < 12) cards.push(a.shift());
  return (
    heading(
      "Bilgini unutmadan pekiştir.",
      "Dört değerlendirmeli aralıklı tekrar; sorular ve ilerleme cihazında saklanır.",
    ) +
    `<div class="stats">${metric("Bugün hazır", summary.due.length, "Şu anda tekrarlanabilir")}${metric("Geciken", summary.late.length, "Önceki günlerden")}${metric("Yarın", summary.tomorrow.length, "Planlanan kart")}${metric("Toplam kart", state.review.length, "Yanlışlar ve soru bankası")}</div>
    <div class="two-col"><div>${card(
      "Tekrar oturumun",
      `<div class="actions">${button("review-bank", "Soru bankasından 12 farklı kart ekle", "", "")}</div><p class="input-hint">Yanlış cevaplar önce değerlendirilir; oturumda konular sırayla dolaşılır. Kart sayısı yetersizse yeni soru uydurulmaz.</p>
      ${
        cards.length
          ? cards
              .map((c) => {
                const shown = reviewShown.has(c.id);
                return `<article class="v2-review"><span class="tag">${e(topicLabel(state, c.topic))}</span><p class="question-text">${e(c.question.text)}</p><small>Tekrar: ${c.due} · aralık ${c.interval} gün</small>
      ${shown ? `<div class="notice"><strong>Yanıt: ${e(answerText(c.question))}</strong><p>${e(c.question.explain || "")}</p>${c.question.source ? "<small>Kaynak: sayfa " + c.question.source.page + "</small>" : ""}</div><p>Kendi hatırlamanı değerlendir:</p><div class="v2-ratings">${ratings.map((label, i) => button("review-rate", label, c.id + ":" + (i + 1), i === 0 ? "ghost" : i === 3 ? "" : "secondary")).join("")}</div>` : "<divPlaceholder/>"}</article>`.replace(
                  "<divPlaceholder/>",
                  button("review-reveal", "Cevabı göster", c.id),
                );
              })
              .join("")
          : empty(
              state.review.length
                ? "Şu anda hazır kart yok. Yeni kart ekleyebilir veya planlanan tarihte dönebilirsin. Unutulan kartlar 10 dakika sonra yeniden açılır."
                : "Henüz kart yok. Soru bankasından oturum ekle veya bir mini sınav çöz.",
            )
      }`,
    )}
      ${card("Konu bazlı hafıza analizi", summary.topics.length ? `<div class="table-wrap"><table><thead><tr><th>Konu</th><th>Son / gelecek tekrar</th><th>Başarılı / zorlanılan</th><th>Durum</th></tr></thead><tbody>${summary.topics.map((t) => `<tr><td>${e(topicLabel(state, t.id))}</td><td>${t.last || "Henüz yok"} / ${t.next || "—"}</td><td>${t.successes} / ${t.failures}</td><td>${e(t.memory)}</td></tr>`).join("")}</tbody></table></div><p class="input-hint">En az üç değerlendirme olmadan hafıza yorumu yapılmaz. Durumlar basit zaman/performans tahminleridir; kesin unutma yüzdesi değildir.</p>` : empty("İlk tekrarlarından sonra konu analizi oluşacak."))}
      ${card(
        "Kart arşivin",
        `<details><summary>Tüm kartlar ve tarihleri</summary>${
          state.review
            .slice(0, 200)
            .map(
              (c) =>
                `<div class="row"><span>${e(c.question.text.slice(0, 150))}</span><small>${c.due}</small></div>`,
            )
            .join("") || empty("Arşiv boş.")
        }</details>`,
      )}
    </div><aside>${card("Önümüzdeki 7 gün", `<div class="v2-calendar">${summary.calendar.map((d) => `<div><small>${e(dateLabel(d.date))}</small><strong>${d.count}</strong><span>kart</span></div>`).join("")}</div>`)}
      ${card("Hatırlama performansın", state.learning.reviewLog.length ? `<div class="v2-performance">${summary.performance.map((d) => `<div><span>${e(dateLabel(d.date))}</span><div class="v2-chart-track"><span style="width:${d.total ? (100 * d.correct) / d.total : 0}%"></span></div><small>${d.correct} / ${d.total}</small></div>`).join("")}</div><p class="input-hint">Son 7 gündeki gerçek değerlendirmeler: “Hatırladım” ve “Çok kolaydı” / toplam. Kendi değerlendirmen başarı oranını etkiler.</p>` : empty("Grafik ilk değerlendirmenden sonra oluşacak."))}
      ${card(
        "En çok zorlanılan konular",
        summary.topics
          .filter((t) => t.failures)
          .slice(0, 5)
          .map(
            (t) =>
              `<div class="row"><strong>${e(topicLabel(state, t.id))}</strong><small>${t.failures} zorlanma</small></div>`,
          )
          .join("") || empty("Henüz zorlanma kaydı yok."),
      )}
      <div class="notice">SM-2 esinli başlangıç algoritması kullanılır. Hatırlama arttıkça aralık uzar; unutulan kart 10 dakika sonra yeniden gelir. İlerleme çalışma planını günceller.</div>${link("coach", "Güncel çalışma planını aç")}
    </aside></div>`
  );
}
function visualBoard(step, kind) {
  const v = step.visual;
  if (v.graph) {
    const graph = v.graph,
      n = graph.nodes.length,
      position = new Map(
        graph.nodes.map((node, i) => {
          const angle = (2 * Math.PI * i) / n - Math.PI / 2;
          return [
            node,
            { x: 210 + 145 * Math.cos(angle), y: 150 + 108 * Math.sin(angle) },
          ];
        }),
      );
    return `<div class="v2-graph"><svg viewBox="0 0 420 300" role="img" aria-label="Grafın anlık ziyaret durumu"><defs><marker id="arrow-${kind}" markerWidth="8" markerHeight="8" refX="23" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8" fill="currentColor"/></marker></defs>
      ${graph.edges
        .map(([a, b, w]) => {
          const p = position.get(a),
            q = position.get(b);
          return `<g><line x1="${p.x}" y1="${p.y}" x2="${q.x}" y2="${q.y}" ${graph.directed ? `marker-end="url(#arrow-${kind})"` : ""}/><text class="edge-weight" x="${(p.x + q.x) / 2 + 7}" y="${(p.y + q.y) / 2 - 7}">${w}</text></g>`;
        })
        .join("")}
      ${graph.nodes
        .map((node) => {
          const p = position.get(node);
          return `<g class="${v.current === node ? "current" : v.visited?.includes(node) ? "visited" : ""}"><circle cx="${p.x}" cy="${p.y}" r="19"/><text x="${p.x}" y="${p.y + 5}" text-anchor="middle">${e(node)}</text></g>`;
        })
        .join(
          "",
        )}</svg></div><p class="input-hint">${graph.directed ? "Yönlü" : "Yönsüz"} graf · yeşil: ziyaret edilmiş · çerçeveli: aktif düğüm</p><p>Bekleyenler: ${e((v.frontier || []).join(" → ") || "—")}</p>`;
  }
  if (v.tree) {
    const positions = [],
      edges = [];
    let counter = 0,
      maxDepth = 0;
    function walk(node, depth = 0) {
      if (!node || node.value === null) return null;
      const left = walk(node.left, depth + 1),
        p = { value: node.value, x: 40 + counter++ * 58, y: 35 + depth * 65 };
      positions.push(p);
      maxDepth = Math.max(maxDepth, depth);
      const right = walk(node.right, depth + 1);
      if (left) edges.push([p, left]);
      if (right) edges.push([p, right]);
      return p;
    }
    walk(v.tree);
    return positions.length
      ? `<div class="v2-tree"><svg viewBox="0 0 ${Math.max(350, counter * 58 + 30)} ${Math.max(180, maxDepth * 65 + 70)}" role="img" aria-label="İkili arama ağacı">
      ${edges.map(([p, q]) => `<line x1="${p.x}" y1="${p.y}" x2="${q.x}" y2="${q.y}"/>`).join("")}
      ${positions.map((p) => `<g><circle cx="${p.x}" cy="${p.y}" r="20"/><text x="${p.x}" y="${p.y + 5}" text-anchor="middle">${p.value}</text></g>`).join("")}</svg></div>`
      : empty("Ağaç boş.");
  }
  const a = v.array || [],
    scale = Math.max(1, ...a.map((n) => Math.abs(n)));
  return a.length
    ? `<div class="v2-array ${kind === "stack" ? "v2-stack" : ""}">${a.map((value, i) => `<div class="v2-array-item ${v.active?.includes(i) ? "active" : v.sorted?.includes(i) ? "sorted" : ""}"><div class="v2-bar" style="height:${v.linked || ["stack", "queue"].includes(kind) ? 48 : 35 + (90 * Math.abs(value)) / scale}px"><strong>${value}</strong></div><small>[${i}]</small>${v.linked ? '<span class="v2-node-arrow" aria-hidden="true">→</span>' : ""}</div>`).join("")}${v.linked ? "<span>null</span>" : ""}</div><p class="input-hint">${kind === "stack" ? "Sağdaki son eleman tepedir (LIFO)." : kind === "queue" ? "Soldaki ilk eleman baştır (FIFO)." : v.linked ? "Oklar bir sonraki düğüm bağlantısını gösterir." : "İndisler 0'dan başlar. Çubuk yüksekliği büyüklüğü, sayı etiketi işareti gösterir."}</p>`
    : empty("Boş yapı / dizi.");
}
function algorithmPanel(trace, index, caption) {
  const step = trace.steps[Math.min(index, trace.steps.length - 1)];
  return `<section class="card v2-sim-panel"><div class="card-header"><h2>${e(caption)}</h2><span class="tag">${Math.min(index + 1, trace.steps.length)} / ${trace.steps.length}</span></div>
    ${visualBoard(step, trace.kind)}<p class="v2-explanation" role="status">${e(step.explain)}</p>
    <div class="v2-counts"><span>Karşılaştırma <b>${step.metrics.comparisons}</b></span><span>Takas <b>${step.metrics.swaps}</b></span><span>Yazma <b>${step.metrics.writes}</b></span><span>Ziyaret <b>${step.metrics.visits}</b></span></div>
    <div class="algorithm-code" aria-label="Algoritma kodu">${trace.code.map((line, i) => `<span class="algorithm-line ${i + 1 === step.line ? "active" : ""}" ${i + 1 === step.line ? 'aria-current="step"' : ""}><span class="line-number">${i + 1}</span>${e(line)}</span>`).join("")}</div>
    <details open><summary>Değişkenlerin anlık değerleri</summary><pre class="code">${e(JSON.stringify(step.vars, null, 2))}</pre></details>
    <h3>Çıktı</h3><pre class="code">${e(
      trace.steps
        .slice(0, Math.min(index + 1, trace.steps.length))
        .filter((s) => s.output)
        .map((s) => s.output)
        .join("\n") || "Henüz çıktı yok.",
    )}</pre>
    <p class="input-hint">Zaman: ${e(playground.algorithms[trace.kind].time)} · Alan: ${e(playground.algorithms[trace.kind].space)}</p></section>`;
}
function simFrame(ctx) {
  const t = sim.trace,
    q = playground.predictionQuestion(t, sim.index),
    answer =
      q && ctx.state.learning.algorithms.answers.find((x) => x.id === q.id);
  const count = Math.max(t.steps.length, sim.other?.steps.length || 0);
  return `<div class="v2-sim-controls">${button("sim-reset", "↺ Sıfırla", "", "ghost")}${button("sim-back", "← Geri", "", "secondary", sim.index === 0)}
    ${button(loop ? "sim-pause" : "sim-play", loop ? "Duraklat" : "▶ Oynat", "", "")}${button("sim-next", "İleri →", "", "secondary", sim.index === count - 1)}
    <label class="field">Adıma git<input aria-label="Simülasyon adımı" type="range" data-v2-change="seek" min="0" max="${count - 1}" value="${sim.index}"></label></div>
    <div class="${sim.other ? "v2-compare" : "v2-solo"}">${algorithmPanel(t, sim.index, playground.algorithms[t.kind].name)}${sim.other ? algorithmPanel(sim.other, sim.index, playground.algorithms[sim.other.kind].name) : ""}</div>
    ${card("Tahmin et ve öğren", q ? (answer ? `<div class="notice ${answer.correct ? "" : "warning"}"><strong>${answer.correct ? "Doğru tahmin!" : "Bu kez eşleşmedi."}</strong><p>Bir sonraki işlem: ${e(q.options[q.answer])}. ${e(q.explain)}</p><small>Bu adımın ilk cevabı kaydedildi; aynı adım tekrar puan kazandırmaz.</small></div>` : `<p>${e(q.text)}</p><div class="actions">${q.options.map((label, i) => button("prediction", label, String(i))).join("")}</div>`) : empty("Son adımdasın. Farklı bir girdiyi veya başka bir algoritmayı dene."))}
    ${card(
      "Adım geçmişi",
      `<details><summary>İşlenen adımları aç / bir adıma dön</summary><ol class="history v2-step-history">${t.steps
        .slice(0, Math.min(sim.index + 1, t.steps.length))
        .map(
          (s, i) =>
            `<li>${button("sim-seek", String(i + 1) + ". " + s.explain, String(i), "ghost small")}</li>`,
        )
        .join("")}</ol></details>`,
    )}`;
}
function playgroundPage(ctx, id) {
  if (id && playground.algorithms[id] && id !== sim.kind) {
    pauseSimulation();
    sim.kind = id;
    sim.input = playground.algorithms[id].input;
    sim.parameter = playground.algorithms[id].group === "Graf" ? "A" : "5";
    sim.compare = "";
    sim.other = null;
    sim.trace = playground.buildSimulation(id, sim.input, sim.parameter);
    sim.index = 0;
  }
  const a = playground.algorithms[sim.kind],
    comparable = Object.entries(playground.algorithms).filter(
      ([, m]) => m.group === a.group && ["Sıralama", "Arama"].includes(m.group),
    );
  const answers = ctx.state.learning.algorithms.answers,
    correct = answers.filter((x) => x.correct).length;
  return (
    heading(
      "Algoritmayı izleme, deneyerek öğren.",
      "14 simülasyon, adım tahmini ve aynı veriyle algoritma karşılaştırması.",
    ) +
    `<div class="actions">${link("algovisual", "Döngü, koşul, değişken ve fonksiyon simülasyonları")}${link("coach", "Ortak çalışma planın")}</div>
    <div class="stats">${metric("Tahminlerin", answers.length, "İlk cevaplar kaydedilir")}${metric("Doğru tahmin", correct, answers.length ? "%" + Math.round((correct / answers.length) * 100) : "Henüz gözlem yok")}${metric("Görev başarısı", ctx.state.learning.algorithms.challenges.length + " / " + playground.challenges.length, "Ayrı görevler")}${metric("Simülasyon", Object.keys(playground.algorithms).length, "4 temel simülasyon ayrıca korunuyor")}</div>
    ${card(
      "Deneyini hazırla",
      `<form data-v2="simulation"><div class="form-grid"><label class="field">Algoritma<select name="kind" data-v2-change="kind">${Object.entries(
        playground.algorithms,
      )
        .map(([kind, m]) => option(kind, m.group + " / " + m.name, sim.kind))
        .join("")}</select></label>
    <label class="field">Karşılaştır<select name="compare">${option("", "Karşılaştırma kapalı", sim.compare)}${comparable
      .filter(([kind]) => kind !== sim.kind)
      .map(([kind, m]) => option(kind, m.name, sim.compare))
      .join(
        "",
      )}</select><small>Aynı türde sıralama veya arama algoritmaları karşılaştırılır.</small></label>
    <label class="field">Hedef / başlangıç düğümü<input name="parameter" maxlength="30" value="${e(sim.parameter)}"><small>${a.group === "Graf" ? "Grafın başlangıç düğümü (örn. A)." : a.group === "Arama" ? "Aranacak sayı." : "Bu algoritmada kullanılmaz."}</small></label>
    <label class="field">Oynatma hızı<select name="speed" data-v2-change="speed">${[
      [1600, "Yavaş"],
      [900, "Normal"],
      [350, "Hızlı"],
    ]
      .map(([v, l]) => option(v, l, sim.speed))
      .join("")}</select></label>
    <label class="field span-2">${a.group === "Graf" ? "Graf JSON'u" : a.group === "Veri yapısı" ? "Noktalı virgülle işlemler" : "Virgülle sayılar (boş dizi desteklenir)"}<textarea name="input" rows="${a.group === "Graf" ? 5 : 2}" maxlength="6000" spellcheck="false">${e(sim.input)}</textarea></label></div>
    <div class="actions"><button class="btn">Girdiyi uygula</button>${a.group === "Sıralama" ? button("preset-best", "Sıralı girdi örneği") + button("preset-worst", "Ters sıralı girdi örneği") : ""}</div>
    <p class="input-hint">En fazla 24 sayı/yapı elemanı, 12 graf düğümü ve 5.000 adım. Ters sıralı veri her algoritmanın en kötü durumu değildir; Quick Sort'ta seçilen son-eleman pivotu sıralı girdide de dengesiz bölünebilir.</p></form>`,
    )}
    <div id="v2Frame">${simFrame(ctx)}</div>
    ${sim.other ? card("Aynı veri kümesinin tamamındaki sayaçlar", `<div class="table-wrap"><table><thead><tr><th>Algoritma</th><th>Karşılaştırma</th><th>Takas</th><th>Yazma</th><th>Adım</th></tr></thead><tbody>${[sim.trace, sim.other].map((t) => `<tr><td>${e(playground.algorithms[t.kind].name)}</td><td>${t.metrics.comparisons}</td><td>${t.metrics.swaps}</td><td>${t.metrics.writes}</td><td>${t.steps.length}</td></tr>`).join("")}</tbody></table></div><p class="input-hint">Bunlar bu uygulamadaki işlemlerdir. Ara yüz çizim süresi ölçülmez; evrensel hız sıralaması iddia edilmez.</p>`) : ""}
    ${card("Big O ne anlatır?", `<p>O(1) boyuttan bağımsız, O(log n) her adımda daralan, O(n) doğrusal, O(n log n) bölerek işleyen ve O(n²) iki kat büyüyen girdide yaklaşık dört kat temel iş gerektirebilen büyüme sınıflarıdır. O(V + E), düğüm ve kenar sayısıyla büyür. Bunlar kesin süre veya saniye ölçümü değildir.</p><p class="input-hint">Sıralamada değer karşılaştırmaları sayılır; üç yönlü arama karşılaştırması tek karşılaştırma olarak sayılır. Dijkstra sayaçları minimum aday seçimini ve kenar gevşetmesini içerir. Görselleştirme snapshotlarının belleği, algoritmanın teorik alan karmaşıklığına dahil edilmez.</p>`)}
    ${card("Algoritma görevleri", `<div class="v2-challenges">${playground.challenges.map((c) => `<form class="v2-challenge" data-v2="challenge" data-id="${c.id}"><span class="tag">${ctx.state.learning.algorithms.challenges.some((x) => x.challenge === c.id) ? "✓ Tamamlandı" : "Uygulama"}</span><h3>${e(c.text)}</h3><label class="field">Cevabın<select name="answer">${c.options.map((o, i) => option(i, o, -1)).join("")}</select></label><button class="btn secondary">Cevabı kontrol et</button></form>`).join("")}</div>`)}
    <div class="notice">Bu alan önceden tanımlı algoritmaların gerçek adımlarını hesaplar. Serbest Python/C kodu ana sunucuda çalıştırılmaz.</div>`
  );
}
function linuxPage(ctx) {
  const lab = ctx.state.learning.lab,
    completed = lab.completed.filter((x) => x.startsWith("m-")).length,
    unlocked = linux.stageUnlocked(lab, 5);
  return (
    heading(
      "Güvenli bir laboratuvarda keşfet.",
      "Linux komutları, dosya sistemi ve kurgusal siber güvenlik görevleri.",
    ) +
    `<div class="notice">Burası tarayıcı içindeki sınırlı bir simülasyondur. Komutların gerçek işletim sistemine, kişisel dosyalarına veya internete erişmez. Tüm kayıt ve hesaplar kurgusaldır.</div>
    <div class="v2-learning-path">${linux.stages.map((stage, i) => `<span class="tag ${linux.stageUnlocked(lab, i) ? "green" : "muted"}">${lab.completed.includes("path-" + linux.stageKeys[i]) ? "✓" : linux.stageUnlocked(lab, i) ? "●" : "🔒"} ${e(stage)}</span>`).join('<span aria-hidden="true">→</span>')}</div>
    <div class="stats">${metric("Linux görevleri", completed + " / " + linux.missions.length, "Sanal durumdan doğrulanır")}${metric("CTF başarıları", lab.ctf.length + " / " + linux.ctfs.length, "İnceleme + flag doğrulaması")}${metric(
      "CTF puanı",
      lab.ctf.reduce((n, x) => n + x.score, 0),
      "İpucu kullanılan görev 80 puan",
    )}${metric("Sanal alan", lab.fs.length + " / 128", "En fazla 200.000 karakter")}</div>
    <div class="two-col"><div>${card(
      "Sanal terminal",
      `<div class="v2-terminal"><div class="v2-terminal-title"><span aria-hidden="true">● ● ●</span><span>ogrenci@algovisual · ${e(lab.cwd)}</span></div>
      <div class="v2-terminal-log" role="log" aria-label="Sanal terminal çıktısı" tabindex="0">${
        lab.history
          .slice(-30)
          .map(
            (row) =>
              `<div><span class="v2-prompt">$ ${e(row.command)}</span><pre class="${row.error ? "incorrect" : ""}">${e(row.output)}</pre></div>`,
          )
          .join("") || "<p>Hoş geldin. help yazıp Enter tuşuna bas.</p>"
      }</div>
      <form data-v2="terminal" autocomplete="off"><label class="sr-only" for="v2Command">Sanal Linux komutu</label><div class="v2-command-line"><span aria-hidden="true">$</span><input id="v2Command" name="command" maxlength="1000" spellcheck="false" autocapitalize="off" placeholder="help" required><button class="btn secondary small">Çalıştır</button></div></form></div>
      <p class="input-hint">Yukarı/aşağı ok: önceki komutlar. grep düz metin arar; en fazla 4 okuma komutu | ile bağlanır. > ve >> sanal dosyaya yazar. Tam bir POSIX kabuğu değildir.</p>
      <div class="actions">${button("terminal-help", "Komutları göster")}${button("terminal-clear", "Ekranı temizle", "", "ghost")}${button("terminal-reset", "Sanal dosyaları sıfırla", "", "ghost")}</div>`,
    )}
      ${card(
        "Linux görevlerin",
        linux.missions
          .map((m) => {
            const done = lab.completed.includes(m.id),
              open = linux.stageUnlocked(lab, m.stage);
            return `<article class="v2-task"><span class="tag">${e(linux.stages[m.stage])}</span><h3>${done ? "✓ " : open ? "" : "🔒 "}${e(m.title)}</h3><p>${e(m.description)}</p><small>${done ? "Tamamlandı; istersen komutları tekrar deneyebilirsin." : open ? "Sanal dosyalar ve inceleme çıktıları uygun olduğunda otomatik doğrulanır." : "Önce bir önceki aşamayı tamamla."}</small></article>`;
          })
          .join(""),
      )}
    </div><aside>${card(
      "Sanal dosyaların",
      `<details><summary>Dosya ağacını aç</summary><div class="v2-file-tree">${lab.fs
        .slice()
        .sort((a, b) => a.path.localeCompare(b.path))
        .map(
          (f) =>
            `<div><code>${e(f.type === "dir" ? "▸ " : "")}${e(f.path)}</code><small>${f.mode}</small>${f.type === "file" ? button("terminal-read", "Oku", f.path, "ghost small") : ""}</div>`,
        )
        .join("")}</div></details>`,
    )}
      ${card("Nasıl ilerlersin?", `<p>Önce bulunduğun konumu ve dosyaları incele. Görevler tamamlandıkça bir sonraki aşama açılır. CTF'lerde yalnızca flag'i bilmek yetmez; ilgili sanal kaydı incelemen veya dosya durumunu düzeltmen gerekir.</p><p class="input-hint">Dosyalar ve ilerleme IndexedDB'de tutulur, JSON yedeğine dahildir. “Sanal dosyaları sıfırla” dosyaları başlangıca döndürür; kazanılan başarılar korunur.</p>${link("coach", "Çalışma planını aç")}${link("review", "Zorlandığın konuları tekrar et")}`)}
      ${card(
        "Başarı geçmişin",
        lab.ctf
          .slice()
          .reverse()
          .map(
            (c) =>
              `<div class="row"><span>${e(linux.ctfs.find((t) => t.id === c.id)?.title || c.id)}</span><small>${c.date} · ${c.score} puan</small></div>`,
          )
          .join("") ||
          empty("İlk CTF görevinin ardından başarıların burada görünecek."),
      )}
    </aside></div>
    ${card(
      "CTF görevleri · kontrollü eğitim alanı",
      `<p>${unlocked ? "Temel yol tamamlandı; görevleri istediğin sırayla çözebilirsin." : "CTF doğrulaması için öğrenme yolunun önceki beş aşamasını tamamla."}</p><div class="v2-challenges">${linux.ctfs
        .map((c, i) => {
          const done = lab.ctf.find((x) => x.id === c.id),
            hint = lab.hints.includes(c.id);
          return `<article class="v2-challenge"><small>CTF ${String(i + 1).padStart(2, "0")} · Başlangıç</small><h3>${done ? "✓ " : ""}${e(c.title)}</h3><p>${e(c.description)}</p><code class="v2-path">${e(c.path)}</code>
      ${hint ? "<divPlaceholder/>" : button("ctf-hint", "İpucu aç (−20 puan)", c.id, "ghost small", !unlocked)}
      <form data-v2="flag" data-id="${c.id}"><label class="field">Flag · ${e(c.title)}<input name="flag" maxlength="100" placeholder="FLAG{...}" required ${!unlocked || done ? "disabled" : ""}></label><button class="btn secondary" ${!unlocked || done ? "disabled" : ""}>${done ? done.score + " puan · Tamamlandı" : "Flag'i doğrula"}</button></form></article>`.replace(
            "<divPlaceholder/>",
            `<p class="notice">${e(c.hint)}</p>`,
          );
        })
        .join("")}</div>`,
    )}`
  );
}
export function renderPage(page, id, ctx) {
  if (page === "coach") return coach(ctx, id);
  if (page === "review") return review(ctx);
  if (page === "playground") return playgroundPage(ctx, id);
  if (page === "linuxlab") return linuxPage(ctx);
  return "";
}
const saveRender = async (ctx, message, error = false) => {
  await ctx.save();
  ctx.render();
  if (message) ctx.toast(message, error);
};
const currentDate = (ctx) => planDate(ctx.route()[1]);
const findTask = (ctx, id) =>
  ctx.state.learning.plans
    .find((p) => p.date === currentDate(ctx))
    ?.tasks.find((t) => t.id === id);
function updateFrame(ctx) {
  if (ctx.route()[0] !== "playground") {
    pauseSimulation();
    return;
  }
  const el = $("#v2Frame");
  if (el) el.innerHTML = simFrame(ctx);
}
function applySimulation(input, parameter, compare) {
  const first = playground.buildSimulation(sim.kind, input, parameter);
  let other = null;
  if (compare) {
    const a = playground.algorithms[compare],
      b = playground.algorithms[sim.kind];
    if (!a || a.group !== b.group || !["Sıralama", "Arama"].includes(a.group))
      throw Error("Karşılaştırma için aynı türde iki algoritma seç.");
    other = playground.buildSimulation(compare, input, parameter);
  }
  pauseSimulation();
  Object.assign(sim, {
    input,
    parameter,
    compare,
    trace: first,
    other,
    index: 0,
  });
}
async function terminalCommand(ctx, command) {
  const result = linux.runCommand(ctx.state.learning.lab, command);
  ctx.state.learning.lab = result.lab;
  const added = linux.checkMissions(ctx.state);
  if (result.error)
    recordEvidence(ctx.state, {
      id: "linux-error:" + crypto.randomUUID(),
      topic: "linux:files",
      source: "linux",
      correct: false,
      weight: 0.25,
      question: {
        id: "linux-location",
        type: "short",
        text: "Linux'ta bulunduğun dizinin tam yolunu hangi komut gösterir?",
        answers: ["pwd"],
        explain:
          "pwd mevcut çalışma dizininin yolunu gösterir; ls içeriği listeler.",
        tag: "Linux temel komutlar",
      },
    });
  labFocus = true;
  await saveRender(
    ctx,
    added.length
      ? added.length + " Linux görevi doğrulandı."
      : result.error
        ? result.output
        : "",
    result.error,
  );
}
export async function action(name, id, element, ctx) {
  const state = ctx.state;
  switch (name.replace(/^v2-/, "")) {
    case "plan-rebuild":
      rebuildPlan(state, planDate(id));
      await saveRender(
        ctx,
        "Plan güncellendi; tamamlanmış ve sana ait görevler korundu.",
      );
      break;
    case "task-start":
      startTask(state, currentDate(ctx), id);
      await saveRender(ctx, "Görev sayacı başladı.");
      break;
    case "task-pause":
      settleTask(state, "pause");
      await saveRender(ctx, "Geçen gerçek süre kaydedildi.");
      break;
    case "task-done": {
      const task = findTask(ctx, id);
      if (!task || task.status !== "pending")
        throw Error("Tamamlanabilecek görev bulunamadı.");
      if (
        state.learning.activeTask?.taskId === id &&
        state.learning.activeTask.date === currentDate(ctx)
      )
        settleTask(state, "done");
      else task.status = "done";
      await saveRender(
        ctx,
        "Görev tamamlandı. Sayaç kullanılmadıysa çalışma dakikası eklenmedi.",
      );
      break;
    }
    case "task-defer":
      deferTask(state, currentDate(ctx), id);
      await saveRender(ctx, "Görev yarına ertelendi.");
      break;
    case "exam-edit":
      examEditor = id;
      ctx.render();
      break;
    case "exam-cancel":
      examEditor = null;
      ctx.render();
      break;
    case "exam-delete":
      state.learning.exams = state.learning.exams.filter((x) => x.id !== id);
      if (examEditor === id) examEditor = null;
      await saveRender(ctx, "Sınav kaldırıldı, plan yeniden değerlendirildi.");
      break;
    case "review-bank": {
      const result = addBankReviews(state);
      upgradeLearning(state);
      await saveRender(
        ctx,
        result.added
          ? result.added + " yeni kart eklendi."
          : "Bankadaki bütün uygun sorular zaten kartlarda; yeni soru bulunamadı.",
      );
      break;
    }
    case "review-reveal":
      reviewShown.add(id);
      ctx.render();
      break;
    case "review-rate": {
      const split = id.lastIndexOf(":"),
        cardId = id.slice(0, split),
        rating = Number(id.slice(split + 1));
      if (!reviewShown.has(cardId)) throw Error("Önce cevabı incele.");
      const result = rateCard(state, cardId, rating);
      reviewShown.delete(cardId);
      await saveRender(
        ctx,
        rating === 1
          ? "Kart 10 dakika sonra tekrar açılacak."
          : "Sonraki tekrar: " + result.due,
      );
      break;
    }
    case "sim-reset":
      pauseSimulation();
      sim.index = 0;
      updateFrame(ctx);
      break;
    case "sim-back":
      pauseSimulation();
      sim.index = Math.max(0, sim.index - 1);
      updateFrame(ctx);
      break;
    case "sim-next":
      pauseSimulation();
      sim.index = Math.min(
        Math.max(sim.trace.steps.length, sim.other?.steps.length || 0) - 1,
        sim.index + 1,
      );
      updateFrame(ctx);
      break;
    case "sim-seek":
      pauseSimulation();
      sim.index = Math.max(
        0,
        Math.min(sim.trace.steps.length - 1, Number(id) || 0),
      );
      updateFrame(ctx);
      break;
    case "sim-play":
      pauseSimulation();
      if (
        sim.index >=
        Math.max(sim.trace.steps.length, sim.other?.steps.length || 0) - 1
      )
        sim.index = 0;
      loop = setInterval(() => {
        sim.index = Math.min(
          Math.max(sim.trace.steps.length, sim.other?.steps.length || 0) - 1,
          sim.index + 1,
        );
        if (
          sim.index ===
          Math.max(sim.trace.steps.length, sim.other?.steps.length || 0) - 1
        )
          pauseSimulation();
        updateFrame(ctx);
      }, sim.speed);
      updateFrame(ctx);
      break;
    case "sim-pause":
      pauseSimulation();
      updateFrame(ctx);
      break;
    case "preset-best":
    case "preset-worst": {
      const values =
        name === "v2-preset-best" ? "1, 2, 3, 4, 5, 6" : "6, 5, 4, 3, 2, 1";
      applySimulation(values, sim.parameter, sim.compare);
      ctx.render();
      break;
    }
    case "prediction": {
      pauseSimulation();
      const result = playground.recordPrediction(
        state,
        sim.trace,
        sim.index,
        Number(id),
      );
      await ctx.save();
      ctx.render();
      ctx.toast(
        result.correct
          ? "Doğru tahmin; ilerlemene işlendi."
          : "Açıklamayı incele; bu konu tekrar listesine eklendi.",
        !result.correct,
      );
      break;
    }
    case "terminal-help":
      await terminalCommand(ctx, "help");
      break;
    case "terminal-clear":
      await terminalCommand(ctx, "clear");
      break;
    case "terminal-read":
      await terminalCommand(ctx, "cat " + id);
      break;
    case "terminal-reset": {
      if (
        !confirm(
          "Yalnız sanal dosyalar başlangıca dönecek. Kazanılan görev ve CTF başarıların korunacak. Devam edilsin mi?",
        )
      )
        break;
      const old = state.learning.lab;
      state.learning.lab = {
        ...linux.createLab(),
        completed: old.completed,
        ctf: old.ctf,
        hints: old.hints,
      };
      await saveRender(ctx, "Sanal dosyalar sıfırlandı; başarılar korundu.");
      break;
    }
    case "ctf-hint": {
      const c = linux.ctfs.find((x) => x.id === id);
      if (!c || !linux.stageUnlocked(state.learning.lab, 5))
        throw Error("Önce temel öğrenme yolunu tamamla.");
      if (!state.learning.lab.hints.includes(id))
        state.learning.lab.hints.push(id);
      await saveRender(
        ctx,
        "İpucu açıldı; bu görev en fazla 80 puan kazandırır.",
      );
      break;
    }
  }
}
export async function submit(form, ctx) {
  const data = new FormData(form),
    state = ctx.state,
    type = form.dataset.v2;
  if (type === "availability") {
    const daily = Number(data.get("daily")),
      weekly = Array.from({ length: 7 }, (_, i) =>
        data.get("day" + i) === "" ? null : Number(data.get("day" + i)),
      );
    configureStudyTime(state, daily, weekly);
    await saveRender(ctx, "Çalışma sürelerin ve planların güncellendi.");
  } else if (type === "exam") {
    const exam = {
      id: form.dataset.id || crypto.randomUUID(),
      title: String(data.get("title") || "").trim(),
      subject: String(data.get("subject") || "").trim(),
      date: String(data.get("date") || ""),
      topics: data.getAll("topics").map(String),
      importance: Number(data.get("importance")),
      prepared: Number(data.get("prepared")),
    };
    validateExam(exam, state);
    if (!form.dataset.id && state.learning.exams.length >= 100)
      throw Error("En fazla 100 sınav kaydedebilirsin.");
    state.learning.exams = state.learning.exams
      .filter((x) => x.id !== exam.id)
      .concat(exam);
    examEditor = null;
    await saveRender(
      ctx,
      "Sınav kaydedildi; öncelikler yeniden değerlendirildi.",
    );
  } else if (type === "task-edit") {
    editTask(state, form.dataset.date, form.dataset.id, {
      title: String(data.get("title") || ""),
      minutes: Number(data.get("minutes")),
    });
    await saveRender(
      ctx,
      "Görevin korumaya alındı; otomatik planlama düzenlemeni değiştirmez.",
    );
  } else if (type === "task-add") {
    const date = planDate(form.dataset.date),
      p = state.learning.plans.find((p) => p.date === date),
      topic = topicCatalog(state).find((t) => t.id === data.get("topic"));
    const minutes = Number(data.get("minutes")),
      title = String(data.get("title") || "").trim();
    if (
      !p ||
      !topic ||
      !title ||
      title.length > 200 ||
      !Number.isInteger(minutes) ||
      minutes < 1 ||
      minutes > 480
    )
      throw Error("Görev adı, konu ve süreyi kontrol et.");
    const fixed = p.tasks
      .filter(
        (t) =>
          t.status === "done" ||
          (t.manual && t.status === "pending") ||
          (state.learning.activeTask?.date === date &&
            state.learning.activeTask?.taskId === t.id),
      )
      .reduce((n, t) => n + t.minutes, 0);
    if (fixed + minutes > p.capacity)
      throw Error(
        "Sana ait ve tamamlanmış görevler günlük süreyi aşamaz. Süreyi veya görevleri düzenle.",
      );
    p.tasks.push({
      id: "manual:" + crypto.randomUUID(),
      topic: topic.id,
      title,
      kind: "manual",
      route: topic.route,
      minutes,
      status: "pending",
      manual: true,
      deferUntil: null,
      loggedSeconds: 0,
      score: 0,
      reasons: ["Bu görevi sen ekledin; otomatik planlama değiştirmez."],
    });
    rebuildPlan(state, date);
    await saveRender(ctx, "Kendi görevin eklendi.");
  } else if (type === "simulation") {
    applySimulation(
      String(data.get("input") || ""),
      String(data.get("parameter") || ""),
      String(data.get("compare") || ""),
    );
    ctx.render();
  } else if (type === "challenge") {
    const result = playground.answerChallenge(
      state,
      form.dataset.id,
      Number(data.get("answer")),
    );
    await saveRender(
      ctx,
      (result.correct ? "Doğru. " : "Yeniden düşün: ") + result.explain,
      !result.correct,
    );
  } else if (type === "terminal") {
    const command = String(data.get("command") || "");
    if (!command.trim()) throw Error("Bir sanal komut yaz.");
    await terminalCommand(ctx, command);
  } else if (type === "flag") {
    const result = linux.submitFlag(
      state,
      form.dataset.id,
      String(data.get("flag") || ""),
    );
    await saveRender(
      ctx,
      result.message ||
        (result.already
          ? "Bu görev daha önce tamamlanmış."
          : "Görev doğrulandı."),
      !result.correct,
    );
  }
}
export async function change(element, ctx) {
  const type = element.dataset.v2Change;
  if (type === "duration") {
    if (element.value !== "custom") $("#v2Minutes").value = element.value;
    else $("#v2Minutes").focus();
  }
  if (type === "kind") {
    const kind = element.value,
      m = playground.algorithms[kind];
    if (!m) return;
    pauseSimulation();
    Object.assign(sim, {
      kind,
      input: m.input,
      parameter: m.group === "Graf" ? "A" : "5",
      compare: "",
      other: null,
      index: 0,
    });
    sim.trace = playground.buildSimulation(kind, sim.input, sim.parameter);
    await ctx.go("playground/" + kind);
  }
  if (type === "seek") {
    pauseSimulation();
    sim.index = Math.max(
      0,
      Math.min(
        Math.max(sim.trace.steps.length, sim.other?.steps.length || 0) - 1,
        Number(element.value) || 0,
      ),
    );
    updateFrame(ctx);
  }
  if (type === "speed") {
    sim.speed = Number(element.value);
    if (loop) {
      pauseSimulation();
      await action("v2-sim-play", "", null, ctx);
    }
  }
}
export function afterRender(page, ctx) {
  if (page === "linuxlab") {
    const area = $(".v2-terminal-log");
    if (area) area.scrollTop = area.scrollHeight;
    const input = $("#v2Command"),
      history = ctx.state.learning.lab.history.map((x) => x.command);
    let at = history.length;
    input?.addEventListener("keydown", (event) => {
      if (!["ArrowUp", "ArrowDown"].includes(event.key)) return;
      event.preventDefault();
      at = Math.max(
        0,
        Math.min(history.length, at + (event.key === "ArrowUp" ? -1 : 1)),
      );
      input.value = history[at] || "";
    });
    if (labFocus) {
      input?.focus();
      labFocus = false;
    }
  }
}
export function tick(ctx) {
  const active = ctx.state.learning.activeTask;
  if (!active) return;
  const elapsed = taskElapsed(ctx.state),
    clock = $("#v2TaskClock");
  if (clock)
    clock.textContent =
      "Kaydedilen süre: " +
      Math.floor(elapsed / 60) +
      " dk " +
      (elapsed % 60) +
      " sn";
  const task = ctx.state.learning.plans
    .find((p) => p.date === active.date)
    ?.tasks.find((t) => t.id === active.taskId);
  if (
    task &&
    active.startedAt !== null &&
    elapsed >= task.minutes * 60 &&
    !clockBusy
  ) {
    clockBusy = true;
    settleTask(ctx.state, "pause");
    ctx
      .save()
      .then(() => {
        ctx.toast(
          "Görev için ayrılan süre doldu; mola verip tamamlandı olarak işaretleyebilirsin.",
        );
        if (ctx.route()[0] === "coach") ctx.render();
      })
      .catch((err) => ctx.toast(err.message, true))
      .finally(() => {
        clockBusy = false;
      });
  }
}
