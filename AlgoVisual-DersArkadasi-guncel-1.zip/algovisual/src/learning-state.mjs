import { newExamCoach, coachCatalog } from './exam-state.mjs';
// Versioned extension of the existing schema-3 record; old backups remain readable.
export const localDay = (date = new Date()) =>
  date.getFullYear() +
  "-" +
  String(date.getMonth() + 1).padStart(2, "0") +
  "-" +
  String(date.getDate()).padStart(2, "0");
export const validDay = (value) =>
  typeof value === "string" &&
  /^\d{4}-\d{2}-\d{2}$/.test(value) &&
  localDay(new Date(value + "T12:00:00")) === value;
export function shiftDay(date, count) {
  if (!validDay(date) || !Number.isInteger(count))
    throw Error("Geçersiz tarih.");
  const d = new Date(date + "T12:00:00");
  d.setDate(d.getDate() + count);
  return localDay(d);
}
export function daysBetween(a, b) {
  if (!validDay(a) || !validDay(b)) throw Error("Geçersiz tarih.");
  return Math.round(
    (Date.parse(b + "T12:00:00Z") - Date.parse(a + "T12:00:00Z")) / 86400000,
  );
}
export const newLearning = () => ({
  version: 2,
  availability: Array(7).fill(null),
  exams: [],
  plans: [],
  topics: [],
  events: [],
  seenAttempts: [],
  reviewLog: [],
  activeTask: null,
  algorithms: { answers: [], challenges: [] },
  lab: null,
});
export const domainTopics = [
  ...[
    "bubble",
    "selection",
    "insertion",
    "merge",
    "quick",
    "linear",
    "binary",
    "stack",
    "queue",
    "linked",
    "bst",
    "bfs",
    "dfs",
    "dijkstra",
  ].map((kind, i) => ({
    id: "algo:" + kind,
    label: [
      "Bubble Sort",
      "Selection Sort",
      "Insertion Sort",
      "Merge Sort",
      "Quick Sort",
      "Linear Search",
      "Binary Search",
      "Stack",
      "Queue",
      "Linked List",
      "Binary Search Tree",
      "BFS",
      "DFS",
      "Dijkstra",
    ][i],
    subject: "Algoritmalar",
    route: "playground/" + kind,
    minutes: 15,
    prerequisites:
      kind === "binary"
        ? ["algo:linear"]
        : kind === "dijkstra"
          ? ["algo:bfs"]
          : [],
  })),
  ...["intro", "commands", "files", "network", "security", "ctf"].map(
    (kind, i) => ({
      id: "linux:" + kind,
      label: [
        "Linux'a başlangıç",
        "Temel komutlar",
        "Sanal dosya sistemi",
        "Ağ temelleri",
        "Güvenlik temelleri",
        "CTF alıştırmaları",
      ][i],
      subject: "Linux ve güvenlik",
      route: "linuxlab",
      minutes: 15,
      prerequisites: i
        ? [
            "linux:" +
              ["intro", "commands", "files", "network", "security"][i - 1],
          ]
        : [],
    }),
  ),
];
export function topicCatalog(state) {
  return state.lessons
    .map((l) => ({
      id: "lesson:" + l.id,
      label: l.title,
      subject: l.subject,
      route: "lesson/" + l.id,
      minutes: 20,
      prerequisites: (l.prerequisites || []).map((id) => "lesson:" + id),
    }))
    .concat(domainTopics, coachCatalog(state));
}
export function topicForQuestion(state, question, lessonId) {
  const lesson =
    state.lessons.find(
      (l) => l.id === lessonId || l.quiz.some((q) => q.id === question.id),
    ) || state.lessons.find((l) => l.title === question.tag);
  let hash = 2166136261;
  for (const c of String(question.tag || "Genel"))
    hash = Math.imul(hash ^ c.codePointAt(0), 16777619) >>> 0;
  return lesson ? "lesson:" + lesson.id : "tag:" + hash.toString(16);
}
export function upgradeLearning(state) {
  let changed = false;
  if (!state.examCoach) { state.examCoach = newExamCoach(); changed = true; }
  if (!state.learning) {
    state.learning = newLearning();
    changed = true;
  }
  if (state.learning.version !== 2)
    throw Error("Öğrenme verisinin sürümü desteklenmiyor.");
  const learning = state.learning;
  for (const attempt of state.attempts) {
    if (learning.seenAttempts.includes(attempt.id)) continue;
    for (const [i, result] of (attempt.results || []).entries())
      recordEvidence(state, {
        id: "test:" + attempt.id + ":" + i,
        topic: topicForQuestion(state, result.question, attempt.lessonId),
        source: "test",
        correct: result.correct,
        question: result.question,
        date: localDay(new Date(attempt.date)),
        createReview: false,
      });
    learning.seenAttempts.push(attempt.id);
    changed = true;
  }
  for (const card of state.review) {
    if (!card.topic) {
      card.topic = topicForQuestion(state, card.question);
      changed = true;
    }
    if (!card.srs) {
      card.srs = {
        version: 1,
        ease: 2.5,
        streak: 0,
        lapses: 0,
        successes: 0,
        failures: 0,
        last: null,
        againAt: null,
      };
      changed = true;
    }
  }
  for (const topic of learning.topics) {
    if (topic.id.startsWith("tag:") && !topic.label) {
      const question =
        state.review.find((c) => c.topic === topic.id)?.question ||
        state.attempts
          .flatMap((a) => a.results || [])
          .find((r) => topicForQuestion(state, r.question) === topic.id)
          ?.question;
      topic.label = String(question?.tag || "Genel çalışma").slice(0, 200);
      changed = true;
    }
  }
  return changed;
}
export function recordEvidence(state, evidence) {
  const learning = state.learning;
  if (learning.events.some((event) => event.id === evidence.id)) return false;
  const date = evidence.date || localDay(),
    weight = evidence.weight ?? 1;
  if (
    !validDay(date) ||
    !Number.isFinite(weight) ||
    weight <= 0 ||
    weight > 1 ||
    typeof evidence.correct !== "boolean"
  )
    throw Error("Geçersiz öğrenme gözlemi.");
  let topic = learning.topics.find((item) => item.id === evidence.topic);
  if (!topic) {
    topic = { id: evidence.topic, successes: 0, failures: 0, last: date };
    learning.topics.push(topic);
  }
  if (evidence.question?.tag && evidence.topic.startsWith("tag:"))
    topic.label = String(evidence.question.tag).slice(0, 200);
  topic[evidence.correct ? "successes" : "failures"] += weight;
  topic.last = date;
  learning.events.push({
    id: evidence.id,
    topic: evidence.topic,
    correct: evidence.correct,
    source: evidence.source,
    weight,
    date,
  });
  learning.events = learning.events.slice(-5000);
  if (
    !evidence.correct &&
    evidence.question &&
    evidence.createReview !== false
  ) {
    const old = state.review.find(
      (r) => r.question.id === evidence.question.id,
    );
    if (old) {
      old.due = date;
      old.topic = evidence.topic;
    } else
      state.review.push({
        id: crypto.randomUUID(),
        question: structuredClone(evidence.question),
        topic: evidence.topic,
        due: date,
        interval: 0,
        repetitions: 0,
      });
  }
  return true;
}
export function mastery(state, topicId) {
  const item = state.learning.topics.find((t) => t.id === topicId);
  if (!item) return { observations: 0, score: null, successes: 0, failures: 0 };
  const observations = item.successes + item.failures;
  return {
    ...item,
    observations,
    score: Math.round((100 * (3 + item.successes)) / (6 + observations)),
  };
}
const bounded = (n, min, max) => Number.isFinite(n) && n >= min && n <= max;
const text = (s, length) => typeof s === "string" && s.length <= length;
const id = (s) => text(s, 200) && /^[\w:.-]+$/.test(s);
const arr = (a, max) => Array.isArray(a) && a.length <= max;
const stamp = (n) => Number.isSafeInteger(n) && n >= 0;
function assert(ok, name) {
  if (!ok) throw Error("Öğrenme yedeği geçersiz: " + name);
}
export function validateLearning(s) {
  if (s === undefined) return; // Schema-3 backups are upgraded on import.
  assert(s && s.version === 2, "sürüm");
  assert(
    arr(s.availability, 7) &&
      s.availability.length === 7 &&
      s.availability.every(
        (n) => n === null || (Number.isInteger(n) && bounded(n, 0, 480)),
      ),
    "haftalık süre",
  );
  assert(
    arr(s.exams, 100) &&
      s.exams.every(
        (x) =>
          id(x.id) &&
          text(x.title, 200) &&
          text(x.subject, 100) &&
          validDay(x.date) &&
          arr(x.topics, 100) &&
          x.topics.every(id) &&
          [1, 2, 3].includes(x.importance) &&
          bounded(x.prepared, 0, 100),
      ),
    "sınavlar",
  );
  assert(
    arr(s.topics, 5000) &&
      s.topics.every(
        (x) =>
          id(x.id) &&
          bounded(x.successes, 0, 1000000) &&
          bounded(x.failures, 0, 1000000) &&
          validDay(x.last) &&
          (x.label === undefined || text(x.label, 200)),
      ),
    "konu hâkimiyeti",
  );
  assert(
    arr(s.events, 5000) &&
      s.events.every(
        (x) =>
          id(x.id) &&
          id(x.topic) &&
          text(x.source, 40) &&
          typeof x.correct === "boolean" &&
          bounded(x.weight, 0.01, 1) &&
          validDay(x.date),
      ),
    "gözlemler",
  );
  assert(arr(s.seenAttempts, 10000) && s.seenAttempts.every(id), "test geçişi");
  assert(
    arr(s.reviewLog, 10000) &&
      s.reviewLog.every(
        (x) =>
          id(x.id) &&
          id(x.cardId) &&
          id(x.topic) &&
          validDay(x.date) &&
          [1, 2, 3, 4].includes(x.rating) &&
          bounded(x.interval, 0, 365),
      ),
    "tekrar geçmişi",
  );
  assert(
    arr(s.plans, 90) &&
      s.plans.every(
        (p) =>
          validDay(p.date) &&
          bounded(p.capacity, 0, 480) &&
          arr(p.tasks, 200) &&
          new Set(p.tasks.map((t) => t?.id)).size === p.tasks.length &&
          p.tasks
            .filter((t) => t?.status !== "deferred")
            .reduce((n, t) => n + (t?.minutes || 0), 0) <= p.capacity &&
          p.tasks.every(
            (t) =>
              id(t.id) &&
              text(t.title, 200) &&
              id(t.topic) &&
              ["lesson", "review", "practice", "break", "manual"].includes(
                t.kind,
              ) &&
              text(t.route, 250) &&
              !/[<>"'\s]/.test(t.route) &&
              Number.isInteger(t.minutes) &&
              bounded(t.minutes, 1, 480) &&
              ["pending", "done", "deferred"].includes(t.status) &&
              typeof t.manual === "boolean" &&
              (t.deferUntil === null || validDay(t.deferUntil)) &&
              (t.carriedTo === undefined || validDay(t.carriedTo)) &&
              bounded(t.loggedSeconds, 0, 86400) &&
              bounded(t.score, 0, 10000) &&
              arr(t.reasons, 15) &&
              t.reasons.every((r) => text(r, 300)),
          ),
      ),
    "planlar",
  );
  if (s.activeTask)
    assert(
      validDay(s.activeTask.date) &&
        id(s.activeTask.taskId) &&
        (s.activeTask.startedAt === null || stamp(s.activeTask.startedAt)) &&
        s.plans.some(
          (p) =>
            p.date === s.activeTask.date &&
            p.tasks.some(
              (t) => t.id === s.activeTask.taskId && t.status === "pending",
            ),
        ),
      "görev sayacı",
    );
  assert(
    s.algorithms &&
      arr(s.algorithms.answers, 5000) &&
      s.algorithms.answers.every(
        (x) =>
          id(x.id) &&
          id(x.kind) &&
          Number.isInteger(x.step) &&
          bounded(x.step, 0, 5000) &&
          typeof x.correct === "boolean" &&
          validDay(x.date),
      ) &&
      arr(s.algorithms.challenges, 1000) &&
      s.algorithms.challenges.every(
        (x) => id(x.id) && id(x.challenge) && validDay(x.date),
      ),
    "algoritma sonuçları",
  );
  if (s.lab) {
    const l = s.lab;
    assert(
      arr(l.fs, 128) &&
        text(l.cwd, 300) &&
        l.cwd.startsWith("/") &&
        l.fs.every(
          (f) =>
            text(f.path, 300) &&
            /^\/[\w/.-]*$/.test(f.path) &&
            (f.path === "/" ||
              (!f.path.endsWith("/") && !f.path.includes("//"))) &&
            !f.path
              .split("/")
              .some((p) =>
                [".", "..", "__proto__", "constructor", "prototype"].includes(
                  p,
                ),
              ) &&
            ["dir", "file"].includes(f.type) &&
            text(f.content, 32000) &&
            /^[0-7]{3}$/.test(f.mode),
        ) &&
        l.fs.reduce((n, f) => n + f.content.length, 0) <= 200000 &&
        new Set(l.fs.map((f) => f.path)).size === l.fs.length &&
        l.fs.some((f) => f.path === "/" && f.type === "dir") &&
        l.fs.some((f) => f.path === l.cwd && f.type === "dir"),
      "sanal dosya sistemi",
    );
    for (const f of l.fs.filter((x) => x.path !== "/"))
      assert(
        l.fs.some(
          (p) =>
            p.path === f.path.slice(0, f.path.lastIndexOf("/")) ||
            (p.path === "/" && f.path.lastIndexOf("/") === 0),
        ) &&
          l.fs.some(
            (p) =>
              p.path === (f.path.slice(0, f.path.lastIndexOf("/")) || "/") &&
              p.type === "dir",
          ),
        "üst klasör",
      );
    assert(
      arr(l.history, 100) &&
        l.history.every(
          (x) =>
            text(x.command, 1000) &&
            text(x.output, 8000) &&
            typeof x.error === "boolean",
        ),
      "terminal geçmişi",
    );
    assert(
      arr(l.completed, 100) &&
        l.completed.every(id) &&
        arr(l.ctf, 100) &&
        l.ctf.every(
          (x) => id(x.id) && validDay(x.date) && bounded(x.score, 0, 100),
        ) &&
        arr(l.hints, 100) &&
        l.hints.every(id) &&
        arr(l.evidence, 200) &&
        l.evidence.every(
          (x) => text(x.type, 30) && text(x.path, 300) && text(x.detail, 1000),
        ),
      "laboratuvar ilerlemesi",
    );
  }
  for (const list of [
    s.exams,
    s.topics,
    s.events,
    s.plans.map((p) => ({ id: p.date })),
  ])
    assert(
      new Set(list.map((x) => x.id)).size === list.length,
      "yinelenen kayıt",
    );
}
