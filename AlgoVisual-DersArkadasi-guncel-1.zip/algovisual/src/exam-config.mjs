// Append a new immutable version for a new guide; saved results retain their rule snapshot.
export const GUIDE_VERSION = '2026.1';
export const guideSources = {
  yks: 'https://www.osym.gov.tr/2026yuksekogretim-kurumlari-sinavi-yks-kilavuzu',
  lgs: 'https://www.meb.gov.tr/meb_iys_dosyalar/2026_03/23190605_LGS_BaYvuru_ve_Uygulama_Kilavuzu_2026.pdf',
  curriculum: 'https://mufredat.meb.gov.tr/Programlar.aspx',
};
export const fields = { sayisal: 'Sayısal', ea: 'Eşit ağırlık', sozel: 'Sözel' };
export const languages = { en: 'İngilizce', de: 'Almanca', fr: 'Fransızca', ru: 'Rusça', ar: 'Arapça' };
export const topicStatuses = { new: 'Başlanmadı', studying: 'Çalışılıyor', done: 'Tamamlandı', review: 'Tekrar gerekli', weak: 'Eksik konu' };
export const mistakeReasons = { unknown: 'Konuyu bilmiyordum', attention: 'Dikkat hatası', time: 'Zamanım yetmedi', calculation: 'İşlem hatası', reading: 'Soruyu yanlış anladım', unset: 'Henüz seçilmedi' };
const topic = (id, label, difficulty = 2, lessons = [], prerequisites = []) => ({id, label, difficulty, lessons, prerequisites});
const t = (id, label, lessons = [], difficulty = 2) => topic(id, label, difficulty, lessons);
const subject = (id, label, count, topics, section) => ({id, label, count, topics, section});
const lgs = [
  subject('tr', 'Türkçe', 20, [t('word','Sözcükte anlam'),t('sentence','Cümlede anlam'),t('paragraph','Paragraf ve çıkarım'),t('verbals','Fiilimsiler'),t('syntax','Cümlenin ögeleri ve cümle türleri'),t('voice','Fiilde çatı'),t('spelling','Yazım ve noktalama'),t('expression','Anlatım bozuklukları'),t('visual','Görsel, grafik ve sözel mantık')], 'verbal'),
  subject('history','T.C. İnkılap Tarihi ve Atatürkçülük',10,[t('hero','Bir Kahraman Doğuyor'),t('awakening','Millî Uyanış'),t('independence','Millî Mücadele'),t('reforms','Atatürkçülük ve Çağdaşlaşan Türkiye'),t('democracy','Demokratikleşme Çabaları'),t('foreign','Atatürk Dönemi Türk Dış Politikası'),t('legacy','Atatürk’ün Ölümü ve Sonrası')], 'verbal'),
  subject('religion','Din Kültürü ve Ahlak Bilgisi',10,[t('fate','Kader ve Kaza'),t('sharing','Zekât ve Sadaka'),t('life','Din ve Hayat'),t('prophet','Hz. Muhammed’in Örnekliği'),t('quran','Kur’an-ı Kerim ve Özellikleri')], 'verbal'),
  subject('language','Yabancı Dil (İngilizce)',10,[t('friendship','Friendship'),t('teen','Teen Life'),t('kitchen','In the Kitchen'),t('phone','On the Phone'),t('internet','The Internet'),t('adventure','Adventures'),t('tourism','Tourism'),t('chores','Chores'),t('science','Science'),t('disasters','Natural Forces')], 'verbal'),
  subject('math','Matematik',20,[t('factors','Çarpanlar ve katlar'),t('powers','Üslü ifadeler',['math9']),t('roots','Kareköklü ifadeler'),t('data','Veri analizi'),t('probability','Basit olayların olma olasılığı'),t('algebra','Cebirsel ifadeler ve özdeşlikler'),t('equations','Doğrusal denklemler',['math9-equations']),t('inequality','Eşitsizlikler'),t('triangles','Üçgenler'),t('congruence','Eşlik ve benzerlik'),t('transformation','Dönüşüm geometrisi'),t('solids','Geometrik cisimler')], 'numeric'),
  subject('science','Fen Bilimleri',20,[t('climate','Mevsimler ve iklim'),t('dna','DNA ve genetik kod'),t('pressure','Basınç'),t('matter','Madde ve endüstri'),t('machines','Basit makineler'),t('energy','Enerji dönüşümleri ve çevre bilimi'),t('electric','Elektrik yükleri ve elektrik enerjisi')], 'numeric'),
];
const tr = [t('word','Sözcükte anlam'),t('sentence','Cümlede anlam'),t('paragraph','Paragraf ve metin',['literature9-text']),t('grammar','Sözcük türleri ve dil bilgisi'),t('syntax','Cümlenin ögeleri'),t('spelling','Yazım ve noktalama'),t('expression','Anlatım bozuklukları')];
const math = [t('basics','Temel kavramlar ve sayı kümeleri'),t('digits','Sayı basamakları'),t('division','Bölme, bölünebilme, EBOB ve EKOK'),t('rationals','Rasyonel sayılar'),t('powers','Üslü ve köklü ifadeler',['math9']),t('inequality','Eşitsizlik ve mutlak değer'),t('equations','Denklemler ve oran-orantı',['math9-equations']),t('problems','Problemler'),t('sets','Kümeler ve mantık'),t('functions','Fonksiyonlar',['math10']),t('counting','Sayma ve olasılık'),t('data','Veri ve istatistik'),t('triangles','Üçgenler ve açılar'),t('polygons','Çokgenler ve dörtgenler'),t('circle','Çember ve daire'),t('analytic','Analitik geometri'),t('solids','Katı cisimler')];
const physics = [t('science','Fizik bilimine giriş'),t('matter','Madde ve özellikleri'),t('motion','Hareket ve kuvvet',['physics9','physics9-force']),t('energy','İş, güç ve enerji'),t('heat','Isı, sıcaklık ve genleşme'),t('pressure','Basınç ve kaldırma kuvveti'),t('electric','Elektrik ve manyetizma',['physics10-circuit']),t('waves','Dalgalar'),t('optics','Optik')];
const chemistry = [t('science','Kimya bilimi'),t('atom','Atom ve periyodik sistem',['chem9','chem9-periodic']),t('bonds','Kimyasal türler arası etkileşimler'),t('states','Maddenin hâlleri'),t('nature','Doğa ve kimya'),t('calculations','Temel yasalar ve kimyasal hesaplamalar'),t('mixtures','Karışımlar',['chem10-mixtures']),t('acids','Asit, baz ve tuz'),t('everyday','Kimya her yerde')];
const biology = [t('life','Canlıların ortak özellikleri ve temel bileşenler',['bio9-enzymes']),t('cell','Hücre ve madde geçişleri',['bio9']),t('classification','Canlıların sınıflandırılması'),t('division','Hücre bölünmeleri',['bio10-division']),t('genetics','Kalıtım'),t('ecology','Ekosistem ve çevre')];
const history = [t('method','Tarih ve zaman',['history9-evidence']),t('early','İnsanlığın ilk dönemleri',['history9-settlement']),t('turks','İlk Türk devletleri'),t('islam','İslam tarihi ve Türk-İslam devletleri'),t('ottoman','Osmanlı Devleti',['history10-ottoman']),t('modern','Değişen dünya ve yenileşme'),t('independence','Millî Mücadele'),t('reforms','Atatürk ilke ve inkılapları')];
const geography = [t('map','Doğa, insan ve harita',['geography9-map']),t('climate','İklim bilgisi',['geography9-climate']),t('earth','İç ve dış kuvvetler',['geography10-internal']),t('population','Nüfus ve yerleşme'),t('economy','Ekonomik faaliyetler'),t('regions','Bölgeler ve ulaşım'),t('environment','Afetler ve çevre')];
const philosophy = [t('intro','Felsefeye giriş',['philosophy10-inquiry']),t('arguments','Düşünme ve akıl yürütme',['philosophy10-arguments']),t('knowledge','Bilgi felsefesi'),t('being','Varlık felsefesi'),t('ethics','Ahlak felsefesi'),t('art','Sanat felsefesi'),t('religion','Din felsefesi'),t('politics','Siyaset ve bilim felsefesi')];
const religion = [t('knowledge','Bilgi ve inanç',['religion9-knowledge']),t('ethics','Ahlak ve değerler',['religion9-ethics']),t('solidarity','İslam ve toplumsal yaşam',['religion10-solidarity']),t('prophet','Hz. Muhammed ve Kur’an'),t('interpretation','İslam düşüncesinde yorumlar'),t('religions','Dinler ve ortak özellikleri')];
const tyt = [subject('tr','Türkçe',40,tr,'tr'),subject('math','Temel Matematik',40,math,'math'),subject('history','Tarih',5,history,'social'),subject('geography','Coğrafya',5,geography,'social'),subject('philosophy','Felsefe',5,philosophy,'social'),subject('religion','Din Kültürü',5,religion,'social'),subject('physics','Fizik',7,physics,'science'),subject('chemistry','Kimya',7,chemistry,'science'),subject('biology','Biyoloji',6,biology,'science')];
const advancedMath = [t('functions','Fonksiyonlar',['math10']),t('polynomials','Polinomlar'),t('quadratic','İkinci derece denklemler',['math10-quadratic']),t('parabola','Parabol ve eşitsizlikler'),t('trigonometry','Trigonometri'),t('exponential','Üstel ve logaritmik fonksiyonlar'),t('sequences','Diziler'),t('limit','Limit ve süreklilik'),t('derivative','Türev'),t('integral','İntegral'),t('probability','Olasılık'),t('geometry','Geometri ve analitik geometri')].map(x=>({...x,difficulty:3}));
const literature = [t('genres','Metin türleri ve anlatım',['literature9-text','literature9-story']),t('poetry','Şiir bilgisi',['literature10-poetry']),t('early','İslamiyet öncesi ve geçiş dönemi'),t('folk','Halk edebiyatı'),t('divan','Divan edebiyatı'),t('tanzimat','Tanzimat edebiyatı'),t('servet','Servetifünun ve Fecriati'),t('national','Millî Edebiyat'),t('republic','Cumhuriyet Dönemi edebiyatı')];
const ayt = [subject('math','Matematik',40,advancedMath,'math'),subject('physics','Fizik',14,[t('motion','Vektör, kuvvet ve hareket'),t('energy','Enerji, momentum ve denge'),t('circular','Çembersel hareket ve kütle çekimi'),t('oscillation','Basit harmonik hareket ve dalgalar'),t('electric','Elektrik, manyetizma ve alternatif akım'),t('modern','Atom, modern fizik ve uygulamaları')],'science'),subject('chemistry','Kimya',13,[t('atom','Modern atom teorisi'),t('gas','Gazlar ve çözeltiler'),t('energy','Tepkimelerde enerji ve hız'),t('equilibrium','Kimyasal denge'),t('acid','Asit-baz dengesi'),t('electro','Elektrokimya'),t('organic','Organik kimya')],'science'),subject('biology','Biyoloji',13,[t('systems','İnsan fizyolojisi ve sistemler'),t('behavior','Duyu organları ve davranış'),t('genetics','Genden proteine'),t('energy','Canlılarda enerji dönüşümleri'),t('plants','Bitki biyolojisi'),t('ecology','Komünite, popülasyon ve çevre')],'science'),subject('literature','Türk Dili ve Edebiyatı',24,literature,'social1'),subject('history1','Tarih-1',10,history,'social1'),subject('geography1','Coğrafya-1',6,geography,'social1'),subject('history2','Tarih-2',11,[...history,t('contemporary','Çağdaş Türk ve dünya tarihi')],'social2'),subject('geography2','Coğrafya-2',11,[...geography,t('countries','Küresel ortam ve ülkeler')],'social2'),subject('philosophy','Felsefe Grubu',12,[...philosophy,t('psychology','Psikoloji'),t('sociology','Sosyoloji'),t('logic','Mantık')],'social2'),subject('religion','Din Kültürü',6,religion,'social2')];
const ydtTopics = [t('vocabulary','Sözcük bilgisi'),t('grammar','Dil bilgisi ve zamanlar',['english9-present','english10','english10-pastcontinuous']),t('cloze','Boşluk doldurma'),t('sentence','Cümle tamamlama'),t('translation','Çeviri'),t('paragraph','Paragraf tamamlama ve bütünlük'),t('reading','Okuduğunu anlama'),t('dialogue','Diyalog tamamlama'),t('restatement','Anlamca en yakın cümle'),t('irrelevant','Anlam bütünlüğünü bozan cümle')];
export const examConfigs = {
  LGS: {id:'LGS',version:GUIDE_VERSION,year:2026,wrongDivisor:3,minutes:155,subjects:lgs,sections:[{id:'verbal',label:'Sözel oturum',minutes:75},{id:'numeric',label:'Sayısal oturum',minutes:80}],source:guideSources.lgs},
  TYT: {id:'TYT',version:GUIDE_VERSION,year:2026,wrongDivisor:4,minutes:165,subjects:tyt,sections:[{id:'all',label:'TYT',minutes:165}],source:guideSources.yks},
  AYT: {id:'AYT',version:GUIDE_VERSION,year:2026,wrongDivisor:4,minutes:180,subjects:ayt,sections:[{id:'all',label:'AYT',minutes:180}],source:guideSources.yks},
  YDT: {id:'YDT',version:GUIDE_VERSION,year:2026,wrongDivisor:4,minutes:120,subjects:[subject('language','Yabancı Dil',80,ydtTopics,'all')],sections:[{id:'all',label:'YDT',minutes:120}],source:guideSources.yks},
};
// Keep previous entries when adding a future guide version.
export const examConfigVersions = { [GUIDE_VERSION]: examConfigs };
export function getConfig(profile) {
  const registry = examConfigVersions[profile?.configVersion];
  const base = registry && Object.hasOwn(registry, profile?.exam) ? registry[profile.exam] : null;
  if (!base) throw Error('Sınav yapılandırma sürümü desteklenmiyor.');
  let subjects = base.subjects;
  if (profile.exam === 'AYT') {
    const ids = {sayisal:['math','physics','chemistry','biology'],ea:['math','literature','history1','geography1'],sozel:['literature','history1','geography1','history2','geography2','philosophy','religion']}[profile.field];
    if (!ids) throw Error('AYT alanını seç.');
    subjects = subjects.filter(s=>ids.includes(s.id));
  }
  if (profile.exam === 'YDT') subjects = subjects.map(s=>({...s,label:languages[profile.language] || 'Yabancı Dil',topics:s.topics.map(x=>({...x,lessons:profile.language==='en'?x.lessons:[]}))}));
  return {...base,subjects};
}
export const totalQuestions = config => config.subjects.reduce((n,s)=>n+s.count,0);
export function profileTopics(profile) {
  return getConfig(profile).subjects.flatMap(s=>s.topics.map(t=>({...t,subject:s.id,subjectLabel:s.label,key:`exam:${profile.id}:${s.id}:${t.id}`})));
}
export function comparisonSignature(profile,kind,rows,version,divisor,topics=[]) {
  const scope=['topic','weak','custom'].includes(kind)?topics.map(t=>t.key).sort():[];
  return [profile.exam,profile.field||'',profile.language||'',version,divisor,kind,...rows.map(r=>r.id+':'+r.total).sort(),...scope].join('|');
}
