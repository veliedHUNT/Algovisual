import { esc as e, answerText, gradeAnswer } from './core.mjs';
import { localDay, shiftDay, daysBetween, topicCatalog, upgradeLearning } from './learning-state.mjs';
import { rebuildPlan, availableMinutes, startTask, settleTask, taskElapsed } from './planner.mjs';
import { getConfig, examConfigs, fields, languages, topicStatuses, mistakeReasons, profileTopics, totalQuestions, guideSources } from './exam-config.mjs';
import { getProfile, saveProfile, setTopicStatus, questionBank, startMock, mockBlueprint, remaining, updateMockClock, pauseMock, resumeMock, answerMock, finishMock, currentSession, addManualResult, manualMistake, retryMistake, queueMistakeReview, analysis, netSummary, comparableResults, weeklyReport, coachContext, deleteProfile, importQuestions, studentAnswerText } from './exam-engine.mjs';
const $=s=>document.querySelector(s);
const card=(title,body)=>`<section class="card"><h2>${e(title)}</h2>${body}</section>`;
const link=(path,label,style='secondary')=>`<a class="btn ${style}" href="#${e(path)}">${e(label)}</a>`;
const btn=(name,label,id='',style='secondary',disabled=false)=>`<button type="button" class="btn ${style}" data-action="ec-${name}" data-id="${e(id)}" ${disabled?'disabled':''}>${e(label)}</button>`;
const option=(id,label,selected)=>`<option value="${e(id)}" ${String(id)===String(selected)?'selected':''}>${e(label)}</option>`;
const select=(name,label,items,value,attrs='')=>`<label class="field">${e(label)}<select name="${name}" ${attrs}>${Object.entries(items).map(([k,v])=>option(k,v,value)).join('')}</select></label>`;
const field=(name,label,value,type='text',attrs='')=>`<label class="field">${e(label)}<input name="${name}" type="${type}" value="${e(value)}" ${attrs}></label>`;
const fmt=n=>n===null||n===undefined?'—':Number(n).toLocaleString('tr-TR',{maximumFractionDigits:2});
const metric=(label,value,note='')=>`<div class="stat"><small>${e(label)}</small><strong>${e(value)}</strong><small>${e(note)}</small></div>`;
const meter=(value,label)=>`<div class="progress" role="progressbar" aria-label="${e(label)}" aria-valuenow="${value}" aria-valuemin="0" aria-valuemax="100"><span style="width:${value}%"></span></div>`;
const empty=text=>`<p class="ec-empty">${e(text)}</p>`;
const tabs={overview:'Genel Bakış',plan:'Çalışma Programım',topics:'Konularım',mocks:'Denemelerim',mistakes:'Yanlışlar Defteri',reports:'Gelişim Raporum'};
const mockKinds={full:'Tam kapsamlı deneme',subject:'Ders denemesi',topic:'Konu denemesi',weak:'Eksik konular denemesi',mini:'Süreli mini deneme',custom:'Özel deneme'};
let signature='',chartSubject='all',selectedPoint=null,busyTick=false,lastCheckpoint=0,aiBusy=false,aiReply='',aiMessage='',aiOwner=null,retryFeedback=null,profileDraft=null,finishConfirmId=null;
export async function prepare(ctx){
  upgradeLearning(ctx.state);
  let changed=false;
  for(const x of ctx.state.examCoach.sessions.filter(x=>x.status==='running'))changed=updateMockClock(ctx.state,x.id)||changed;
  if(!ctx.state.learning.plans.some(p=>p.date===localDay())){rebuildPlan(ctx.state);changed=true;}
  if(changed)await ctx.save();
}
function header(ctx,tab){
  const s=ctx.state.examCoach,p=s.profiles.find(p=>p.id===s.activeProfileId);
  return `<header class="ec-heading"><div><span class="eyebrow">HER HEDEFE BİR YOL</span><h1>SınavKoçu<span class="ec-dot">.</span></h1><p>LGS, TYT, AYT ve YDT yolculuğun; aynı yerde, kendi hızında.</p></div>${link('examcoach/profile/new','+ Sınav profili ekle','')}</header>
    <div class="ec-profile-bar">${s.profiles.map(x=>`<button class="ec-profile ${x.id===p?.id?'selected':''}" data-action="ec-select-profile" data-id="${x.id}" aria-pressed="${x.id===p?.id}"><span>${e(x.exam)}</span><strong>${e(x.title)}</strong><small>${e(x.targetDate)}${x.enabled?'':' · Planlamaya kapalı'}</small></button>`).join('')}</div>
    ${p?`<nav class="ec-tabs" aria-label="SınavKoçu bölümleri">${Object.entries(tabs).map(([k,v])=>`<a href="#examcoach/${k}" ${tab===k?'aria-current="page" class="selected"':''}>${v}</a>`).join('')}</nav>`:''}`;
}
function profileForm(ctx,id){
  const old=ctx.state.examCoach.profiles.find(p=>p.id===id);
  const p=profileDraft||old||{exam:'TYT',field:null,language:null,targetDate:shiftDay(localDay(),180),dailyMinutes:ctx.state.settings.dailyMinutes,workDays:[0,1,2,3,4,5],targetNet:60,level:0,title:'',subjects:[]};
  const c=getConfig({...p,field:p.field||'sayisal',language:p.language||'en',configVersion:examConfigs[p.exam].version});
  return card(old?'Sınav profilini düzenle':'Hedefini seç, ilk adımı birlikte atalım',`<form data-ec="profile" data-id="${e(old?.id||'')}"><div class="form-grid">
    ${field('title','Profil adı',p.title||p.exam,'text','maxlength="100" required')}
    ${select('exam','Hazırlandığın sınav',Object.fromEntries(Object.keys(examConfigs).map(x=>[x,x])),p.exam,`data-ec-change="profile-exam" ${old?'disabled':''}`)}
    ${p.exam==='AYT'?select('field','AYT alanı',fields,p.field||'sayisal',`data-ec-change="profile-exam" ${old?'disabled':''}`):''}
    ${p.exam==='YDT'?select('language','Yabancı dil',languages,p.language||'en',old?'disabled':''):''}
    ${field('targetDate','Hedef sınav tarihin',p.targetDate,'date','required')}
    ${field('targetNet',`Hedef net (en fazla ${totalQuestions(c)})`,Math.min(p.targetNet,totalQuestions(c)),'number',`min="0" max="${totalQuestions(c)}" step="0.25" required`)}
    ${field('dailyMinutes','Ortak günlük boş zamanın (dk)',p.dailyMinutes,'number','min="5" max="480" required')}
    ${field('level','Kendi hazırlık değerlendirmen (%)',p.level,'number','min="0" max="100" required')}</div>
    <p class="input-hint">Hazırlık beyanın ölçülmüş başarı değildir. Tüm profiller tek günlük zaman bütçesini paylaşır; buradaki süre/gün seçimi ortak Çalışma Planım ayarını da günceller.</p>
    <fieldset><legend>Haftalık çalışma günlerin</legend><div class="ec-checks">${['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'].map((d,i)=>`<label class="check"><input type="checkbox" name="workDays" value="${i}" ${p.workDays.includes(i)?'checked':''}>${d}</label>`).join('')}</div></fieldset>
    <fieldset><legend>Çalışmada hedeflediğin dersler</legend><div class="ec-checks">${c.subjects.map(s=>`<label class="check"><input type="checkbox" name="subjects" value="${s.id}" ${!p.subjects.length||p.subjects.includes(s.id)?'checked':''}>${e(s.label)} <small>${s.count} soru</small></label>`).join('')}</div></fieldset>
    <label class="check"><input type="checkbox" name="enabled" ${p.enabled!==false?'checked':''}>Bu profili ortak çalışma planına dahil et</label>
    <div class="notice">${c.year} kılavuz yapısı · ${totalQuestions(c)} soru · ${c.minutes} dk · ${c.wrongDivisor} yanlış 1 doğruyu götürür. ${p.exam==='AYT'?'Seçtiğin alana ait testlerin toplamı gösterilir; AYT kitapçığında dört testte 160 soru bulunur. ':''}Hedef tarihini kendin seçiyorsun; sonraki yıl kuralları doğrulanmış sayılmaz. Din kültürü muafiyetindeki alternatif test uygulamaları bu başlangıç sürümüne dahil değildir. <a class="text-link" href="${c.source}" target="_blank" rel="noopener noreferrer">Resmî kılavuz ↗</a></div>
    <div class="actions"><button class="btn">${old?'Profili güncelle':'Profilimi oluştur'}</button>${link('examcoach','Vazgeç')}${old?btn('delete-profile','Profil ve sınav verilerini sil',old.id,'ghost'):''}</div></form>`);
}
function program(ctx){
  const s=ctx.state,date=localDay(),p=s.learning.plans.find(p=>p.date===date),active=s.learning.activeTask,total=p.tasks.filter(t=>t.status!=='deferred').reduce((n,t)=>n+t.minutes,0);
  const prefix='exam:'+s.examCoach.activeProfileId+':';
  const tasks=p.tasks.map(t=>`<article class="v2-task ${t.status}"><div class="v2-task-header"><div><span class="tag">${t.kind==='break'?'MOLA':t.topic.startsWith(prefix)?'BU SINAV':t.topic.startsWith('exam:')?'DİĞER SINAV':'ORTAK ÇALIŞMA'}</span><h3>${e(t.title)}</h3><small>${t.minutes} dk · ${t.status==='done'?'Tamamlandı':t.status==='deferred'?'Ertelendi':'Bekliyor'}</small></div>${t.status==='done'?'✓':''}</div><details><summary>Neden bu görev?</summary><ul>${t.reasons.map(r=>`<li>${e(r)}</li>`).join('')}</ul></details>${t.status==='pending'?`<div class="actions">${btn('task-start',active?.taskId===t.id&&active.startedAt!==null?'Çalışılıyor':'Başla',t.id,'',active?.taskId===t.id&&active.startedAt!==null)}${btn('task-pause','Duraklat',t.id,'secondary',active?.taskId!==t.id||active?.startedAt===null)}${btn('task-done','Tamamla',t.id)}${link(t.route,'Konuyu aç','ghost')}</div>`:''}</article>`).join('');
  const a=analysis(s,s.examCoach.activeProfileId),days=daysBetween(date,a.p.targetDate),remainingTopics=a.topics.length-a.done,daysAvailable=Math.max(0,days)*a.p.workDays.length/7,estimated=remainingTopics*20,available=daysAvailable*s.settings.dailyMinutes;
  return card('Bugünkü ortak programın',`<div class="stats">${metric('Planlanan',total+' dk','Molalar dahil')}${metric('Süre sınırı',p.capacity+' dk')}${metric('Tamamlanan',p.tasks.filter(t=>t.status==='done').length+' görev')}${metric('Gerçek sayaç',Math.floor(taskElapsed(s)/60)+' dk', 'Görevi işaretlemek süre eklemez')}</div><p id="ecTaskClock" class="v2-clock"></p><p class="input-hint">Profillerin için ikinci bir takvim yok: Çalışma Planım ile aynı görevler ve sayaç kullanılır.</p>${estimated>available&&days>0?'<div class="notice warning">Kalan konu sayısı için başlangıç süre tahmini zaman bütçeni aşıyor. Sistem eksik ve tekrarları önceliklendirir; tüm konuların biteceğini garanti etmez.</div>':''}${tasks||empty('Bugün dinlenme günü veya uygun görev yok.')}<div class="actions">${btn('rebuild','Planı yeniden değerlendir')}${link('coach/'+date,'Süre, erteleme ve manuel görev düzenle')}</div>`);
}
function overview(ctx,p){
  const s=ctx.state,a=analysis(s,p.id),summary=netSummary(s,p.id),last=a.results.at(-1),days=daysBetween(localDay(),p.targetDate),plan=s.learning.plans.find(x=>x.date===localDay()),tasks=plan.tasks.filter(t=>t.topic.startsWith('exam:'+p.id+':')),mistakes=s.examCoach.mistakes.filter(m=>m.profileId===p.id&&!m.history.some(h=>h.correct));
  return `<section class="ec-hero"><div><span class="eyebrow">${e(p.title)} · ${p.exam==='AYT'?e(fields[p.field]):p.exam==='YDT'?e(languages[p.language]):'SANA AİT YOL HARİTASI'}</span><h2>${days<0?'Hedef tarihini yenileyerek devam et.':days===0?'Bugün hedef günün.':'Hedefine '+days+' gün var.'}</h2><p>Her deneme bir ölçüm, her tekrar bir adım. Bugünkü zamanı en çok ihtiyaç duyduğun konulara ayır.</p><div class="actions">${link('examcoach/plan','Bugünkü programım','')}${link('examcoach/profile/'+p.id,'Hedefimi düzenle')}</div></div><div class="ec-hero-number"><strong>${fmt(p.targetNet)}</strong><span>hedef net</span><small>${e(p.targetDate)}</small></div></section>
    <div class="ec-grid">${card('Bugünkü Programım',`<strong class="ec-value">${tasks.filter(t=>t.status==='done').length} / ${tasks.length}</strong><p>Bu sınava ait tamamlanan görev</p>${meter(tasks.length?Math.round(tasks.filter(t=>t.status==='done').length/tasks.length*100):0,'Bu sınavın günlük görevleri')}${link('examcoach/plan','Programa git','ghost')}`)}
    ${card('Son Denemem',last?`<strong class="ec-value">${fmt(last.net)} <small>net</small></strong><p>${e(last.title)} · ${last.subjects.reduce((n,x)=>n+x.total,0)} soru</p><div class="ec-tags">${last.subjects.map(x=>`<span>${e(x.label)} ${fmt(x.net)}</span>`).join('')}</div>${link('examcoach/result/'+last.id,'Sonucu incele','ghost')}`:empty('Henüz ölçüm yok. Mini deneme çözebilir veya dış deneme sonucu girebilirsin.'))}
    ${card('Eksik Konularım',`<strong class="ec-value">${a.weak.length}</strong><p>İşaretlenen veya yeterli gözlemle önceliklendirilen konu</p>${a.recommendations.slice(0,2).map(r=>`<p><strong>${e(r.label)}</strong><br><small>${e(r.reason)} Başlangıç: ${r.questions} soru.</small></p>`).join('')}${link('examcoach/topics','Konuları incele','ghost')}`)}
    ${card('Yanlışlar Defterim',`<strong class="ec-value">${mistakes.length}</strong><p>Henüz doğru yeniden çözülmeyen soru</p>${link('examcoach/mistakes','Yanlışları pekiştir','ghost')}`)}
    ${card('Gelişimim',`<strong class="ec-value">${a.done} / ${a.topics.length}</strong><p>Çalışma listesinde tamamlanan konu</p>${meter(Math.round(a.done/a.topics.length*100),'Konu tamamlama')}<p>${summary.gap===null?'Tam deneme verisi gelince hedef farkın görünür.':'Hedef nete kalan: '+fmt(Math.max(0,summary.gap))}</p>${link('examcoach/reports','Gelişim raporuna git','ghost')}`)}
    ${card('Sınavım',`<p>${e(getConfig(p).subjects.map(s=>s.label).join(' · '))}</p><p>${getConfig(p).year} yapısı · ${totalQuestions(getConfig(p))} soru · ${getConfig(p).minutes} dk</p><small>Resmî sınav puanı ve yerleştirme sıralaması hesaplanmaz.</small>`)}</div>${aiPanel(s,p)}`;
}
function topicsPage(ctx,p,subjectId){
  const a=analysis(ctx.state,p.id),c=getConfig(p),selected=c.subjects.find(s=>s.id===subjectId)?.id||c.subjects[0].id;
  return `<div class="stats">${metric('Tamamlanan konu',a.done)}${metric('Eksik konu',a.weak.length)}${metric('Tekrar gerekli',a.review)}${metric('Tamamlama','%'+Math.round(a.done/a.topics.length*100))}</div><div class="ec-subjects">${a.subjects.map(s=>`<a class="ec-subject ${selected===s.id?'selected':''}" href="#examcoach/topics/${s.id}"><strong>${e(s.label)}</strong><small>${s.done}/${s.topics.length} konu · ${s.total?s.correct+'/'+s.total+' doğru':'Henüz ölçülmedi'}</small>${meter(Math.round(s.done/s.topics.length*100),s.label+' ilerlemesi')}</a>`).join('')}</div><div class="notice">Bu liste çalışma takibi için düzenlenmiş konu başlıklarıdır; resmî kazanımların bire bir ve eksiksiz dökümü değildir. ${c.year} kılavuzu ve okul programıyla birlikte kullan. <a class="text-link" href="${guideSources.curriculum}" target="_blank" rel="noopener noreferrer">MEB öğretim programları ↗</a></div>
    ${card(c.subjects.find(s=>s.id===selected).label+' konuları',`<div class="ec-topic-list">${a.topics.filter(t=>t.subject===selected).map(t=>`<article class="ec-topic"><div><h3>${e(t.label)}</h3><small>${t.mastery===null?'Henüz ölçülmedi':`Hâkimiyet göstergesi %${t.mastery} · tahmin`} · ${fmt(t.observations)} ağırlıklı gözlem</small>${t.lessons.filter(id=>ctx.state.lessons.some(l=>l.id===id)).map(id=>link('lesson/'+id,'İlgili dersi aç','ghost small')).join('')}</div>${select('status','Konu durumu',topicStatuses,t.status,`data-ec-change="topic-status" data-key="${e(t.key)}"`)}</article>`).join('')}</div><p class="input-hint">0–100 gösterge, gerçek test ve tekrar gözlemlerinden ön bilgiyle yumuşatılır. Üç ağırlıklı gözlemden önce gösterilmez; tek yanlışla kesin eksik etiketi konmaz. Konuyu tamamladım seçeneği başarı notu oluşturmaz.</p>`)}`;
}
function mockControls(p,selected='mini'){
  const c=getConfig(p),sub=c.subjects[0];return `${select('kind','Deneme türü',mockKinds,selected,'data-ec-change="mock-settings"')}${select('subject','Ders',Object.fromEntries(c.subjects.map(s=>[s.id,s.label])),sub.id,'data-ec-change="mock-settings"')}${select('topic','Konu',Object.fromEntries(sub.topics.map(t=>[t.id,t.label])),sub.topics[0].id)}${field('count','Soru sayısı',Math.min(5,sub.count),'number','min="1" max="160" required')}${field('minutes','Süre (dk)',10,'number','min="1" max="240" required')}`;
}
function mocksPage(ctx,p){
  const bank=questionBank(ctx.state,p.id),c=getConfig(p),active=ctx.state.examCoach.sessions.find(x=>x.profileId===p.id&&x.status!=='done'),results=ctx.state.examCoach.results.filter(r=>r.profileId===p.id).slice().reverse();
  return `${active?card('Yarım kalan denemen',`<p>${e(active.title)} · ${active.answers.filter(x=>x!==null&&x!=='').length}/${active.questions.length} yanıt</p>${link('examcoach/session/'+active.id,'Denemeye devam et','')}`):''}
    <div class="two-col"><div>${card('Yeni deneme oluştur',`<p><strong>${bank.length}</strong> cevap anahtarlı başlangıç/yerel soru var. Tam denemede her dersin gerekli sayıya ulaşması gerekir; yetersiz bankada soru tekrarıyla doldurulmaz.</p><div class="ec-tags">${c.subjects.map(s=>`<span>${e(s.label)}: ${bank.filter(q=>q.subjectId===s.id).length}/${s.count}</span>`).join('')}</div><form data-ec="mock"><div class="form-grid">${mockControls(p)}</div><p id="ecMockInfo" class="notice"></p><button class="btn" ${active?'disabled':''}>Denemeyi başlat</button></form>`)}
    ${card('Dışarıda çözdüğün denemeyi kaydet',`<form data-ec="manual-result"><div class="form-grid">${field('title','Deneme adı','','text','maxlength="200" required')}${field('date','Çözüm tarihi',localDay(),'date',`max="${localDay()}" required`)}${select('kind','Sonuç türü',mockKinds,'full')}${field('minutes','Kullanılan süre (dk)',c.minutes,'number','min="0" max="480" required')}</div><p class="input-hint">Girmediğin dersleri boş bırak. Boş sayısı, doğru ve yanlışla birlikte toplam soru sayısını belirler.</p><div class="ec-manual-rows"><div class="ec-manual-row ec-table-head"><span>Ders</span><span>Doğru</span><span>Yanlış</span><span>Boş</span></div>${c.subjects.map(s=>`<div class="ec-manual-row"><strong>${e(s.label)}<small>en fazla ${s.count}</small></strong>${['correct','wrong','blank'].map(k=>`<label><span class="sr-only">${e(s.label+' '+({correct:'doğru',wrong:'yanlış',blank:'boş'})[k])}</span><input name="${s.id}-${k}" type="number" min="0" max="${s.count}" placeholder="—"></label>`).join('')}</div>`).join('')}</div><details><summary>Konu bazında ayrıntı ekle (isteğe bağlı)</summary><p class="input-hint">Her satır: dersKodu,konuKodu,doğru,yanlış,boş. Konu toplamları ders sonuçlarını aşamaz. Ayrıntı girilmezse konu başarısı varsayılmaz.</p><textarea name="topics" maxlength="18000" placeholder="math,${p.exam==='AYT'?'functions':p.exam==='LGS'?'powers':'problems'},3,1,0"></textarea></details><button class="btn secondary">Dış deneme sonucunu kaydet</button></form>`)}
    </div><aside>${card('Deneme geçmişin',results.length?results.map(r=>`<a class="row" href="#examcoach/result/${r.id}"><div><strong>${e(r.title)}</strong><small>${r.date} · ${e(mockKinds[r.kind])} · ${r.subjects.reduce((n,s)=>n+s.total,0)} soru</small></div><strong>${fmt(r.net)} net</strong></a>`).join(''):empty('Henüz deneme kaydı yok.'))}
    ${card('Kendi sorularını ekle',`<details><summary>Cevap anahtarlı JSON içe aktar</summary><p>Sorular kendi yazdığın veya kullanma iznin olan içerik olmalı. Anahtarı kontrol et; kullanıcı eklediği anahtarla değerlendirilir, AI doğrulaması yapılmaz.</p><p>Ders ve konu kodları:</p><div class="ec-code-list">${profileTopics(p).map(t=>`<small>${e(t.subject+'/'+t.id+' — '+t.label)}</small>`).join('')}</div><form data-ec="bank"><label class="field">Soru JSON dizisi<textarea name="json" maxlength="400000" required spellcheck="false" placeholder='[{"type":"choice","text":"Özgün sorum","options":["A","B"],"answer":0,"explain":"Açıklamalı çözüm","level":2,"subjectId":"${c.subjects[0].id}","topicId":"${c.subjects[0].topics[0].id}"}]'></textarea></label><p class="input-hint">choice: 0’dan başlayan answer; boolean: true/false answer; short: answers dizisi. level 1–3. Bir seferde en fazla 300 soru.</p><button class="btn secondary">Soruları ekle</button></form></details>`)}</aside></div>`;
}
function questionInputs(q,answer,name='answer',attrs=''){
  if(q.type==='short')return `<label class="field">Cevabın<input name="${name}" maxlength="300" value="${e(answer??'')}" ${attrs}></label>`;
  const choices=q.type==='boolean'?[[true,'Doğru'],[false,'Yanlış']]:q.options.map((v,i)=>[i,v]);
  return `<fieldset class="ec-options"><legend class="sr-only">Cevap seçenekleri</legend>${choices.map(([i,label])=>`<label class="ec-option ${i===answer?'selected':''}"><input name="${name}" type="radio" value="${i}" ${i===answer?'checked':''} ${attrs}><span>${typeof i==='number'?String.fromCharCode(65+i)+'. ':''}${e(label)}</span></label>`).join('')}</fieldset>`;
}
function sessionPage(ctx,id){
  const x=currentSession(ctx.state,id),q=x.questions[x.index],stage=x.stages[x.stageIndex],result=ctx.state.examCoach.results.find(r=>r.id===id);
  if(result)return resultPage(ctx,id);
  return `<div class="ec-session-head"><div><h2>${e(x.title)}</h2><p>${e(stage.label)} · ${x.index+1}/${x.questions.length} soru</p></div><div class="ec-countdown" id="ecCountdown" role="timer" aria-label="Deneme kalan süresi"></div></div>
    <p class="notice">Bu bir çalışma denemesidir; duraklatma desteklenir. Çalışırken sayfa yenilense veya kapansa süre ilerler, duraklatınca durur. LGS tam denemesi iki ayrı oturum sayacı kullanır. Yanıtlar her değişiklikte yerel olarak kaydedilir.</p>
    ${finishConfirmId===x.id?card('Denemeyi bitirmeye hazır mısın?',`<p>${x.answers.filter(a=>a===null||a==='').length} soru boş kalacak. Bitirdikten sonra cevaplar değiştirilemez; boşlar ayrı gösterilir.</p><div class="actions">${btn('confirm-finish','Evet, sonuçları hesapla',x.id,'')}${btn('cancel-finish','Çözmeye devam et',x.id)}</div>`):''}
    ${x.status!=='running'?card(x.status==='between'?'Sıradaki oturum hazır':'Deneme duraklatıldı',`<p>${x.status==='between'?'Önceki oturumun süresi doldu. Önceki bölümün cevapları kilitlendi; hazır olduğunda sonraki oturumu başlat.':'Cevaplarını görmek ve çözmeye devam etmek için sayacı devam ettir.'}</p>${btn('resume','Devam et',x.id,'')}${btn('finish','Denemeyi bitir',x.id,'ghost')}`):`<div class="ec-exam-layout"><aside class="card"><h3>Soru haritası</h3><div class="ec-question-map">${stage.indices.map(i=>`<button class="${i===x.index?'current ':''}${x.answers[i]!==null&&x.answers[i]!==''?'answered ':''}${x.marked.includes(i)?'marked':''}" data-action="ec-question" data-id="${i}" aria-label="Soru ${i+1}${x.marked.includes(i)?', işaretli':''}${x.answers[i]!==null&&x.answers[i]!==''?', yanıtlandı':''}" ${i===x.index?'aria-current="true"':''}>${i+1}</button>`).join('')}</div><p>${stage.indices.filter(i=>x.answers[i]===null||x.answers[i]==='').length} soru boş</p>${btn('pause','Duraklat',x.id)}${btn('finish','Denemeyi bitir',x.id,'ghost')}</aside>
    <section class="card ec-question"><span class="tag">${e(q.tag)}</span><h2>${e(q.text)}</h2><form data-ec="answer" data-id="${x.id}">${questionInputs(q,x.answers[x.index],'answer','data-ec-change="answer"')}<div class="actions">${q.type==='short'?'<button class="btn secondary">Cevabı kaydet</button>':''}${btn('blank','Boş bırak',x.id,'ghost')}${btn('mark',x.marked.includes(x.index)?'★ İşaretli':'☆ İşaretle',x.id,'ghost')}</div></form><div class="ec-question-nav">${btn('previous','← Önceki',x.id,'secondary',stage.indices[0]===x.index)}${btn('next','Sonraki →',x.id,'',stage.indices.at(-1)===x.index)}</div><small>İşaretlemek değerlendirmeyi değiştirmez. Cevabı seçip sonra değiştirebilirsin.</small></section></div>`}`;
}
function resultPage(ctx,id){
  const r=ctx.state.examCoach.results.find(r=>r.id===id);if(!r)return empty('Sonuç bulunamadı.');
  const x=ctx.state.examCoach.sessions.find(x=>x.id===r.id),p=getProfile(ctx.state,r.profileId),comparable=comparableResults(ctx.state,p.id,r.signature),index=comparable.findIndex(x=>x.id===r.id),prior=comparable[index-1];
  return card(r.title,`<div class="stats">${metric('Toplam net',fmt(r.net))}${metric('Kullanılan süre',Math.floor(r.seconds/60)+' dk '+r.seconds%60+' sn')}${metric('Önceki eş kapsamlı denemeye göre',prior?fmt(r.net-prior.net):'Yeterli veri yok')}${metric('İşaretlenen soru',r.marked.length,r.source==='manual'?'Dış denemede kaydedilmedi':'')}</div><p>${r.date} · ${r.configVersion} kuralı: net = doğru − yanlış/${r.wrongDivisor}. Resmî sınav puanı ve sıralaması değildir.</p><div class="table-wrap"><table><thead><tr><th>Ders</th><th>Doğru</th><th>Yanlış</th><th>Boş</th><th>Net</th></tr></thead><tbody>${r.subjects.map(s=>`<tr><td>${e(s.label)}</td><td>${s.correct}</td><td>${s.wrong}</td><td>${s.blank}</td><td>${fmt(s.net)}</td></tr>`).join('')}</tbody></table></div>
    ${r.topics.length?`<h3>Konu bazlı cevaplar</h3><div class="ec-tags">${r.topics.map(t=>`<span>${e(profileTopics(p).find(x=>x.key===t.key)?.label||'Konu')}: ${t.correct}D / ${t.wrong}Y / ${t.blank}B</span>`).join('')}</div>`:'<p>Konu ayrıntısı girilmedi. Ders toplamlarından konu başarısı üretilmedi.</p>'}
    ${x?`<h3>Soru çözümleri</h3>${x.questions.map((q,i)=>{const blank=x.answers[i]===null||x.answers[i]==='',correct=!blank&&gradeAnswer(q,x.answers[i]);return `<details class="ec-solution"><summary>${i+1}. ${blank?'Boş':correct?'Doğru':'Yanlış'} ${r.marked.includes(i)?'★':''} · ${e(q.tag)}</summary><p class="prose">${e(q.text)}</p><p>Cevabın: ${e(studentAnswerText(q,x.answers[i]))}<br>Doğru cevap: <strong>${e(answerText(q))}</strong></p><p class="prose">${e(q.explain)}</p>${!blank&&!correct?btn('save-wrong','Yanlışlar defterine kaydet',x.id+':'+i):''}</details>`;}).join('')}`:''}<div class="actions">${link('examcoach/mocks','Denemelerime dön')}${link('examcoach/reports','Gelişim grafiği','')}</div>`);
}
function mistakesPage(ctx,p){
  const rows=ctx.state.examCoach.mistakes.filter(m=>m.profileId===p.id),topics=profileTopics(p);
  return `${card('Yanlışından öğren, geçmişini koru',`<label class="check"><input type="checkbox" data-ec-change="auto-mistakes" ${ctx.state.examCoach.autoMistakes?'checked':''}>Site içi SınavKoçu denemelerinde yanlışları otomatik kaydet</label><p class="input-hint">Boşlar otomatik yanlış sorusu sayılmaz. Doğru yeniden çözülen soru silinmez; tekrar geçmişi saklanır.</p><p>${rows.length} kayıt · ${rows.reduce((n,m)=>n+m.history.length,0)} yeniden çözüm</p>`)}
    <div class="two-col"><div>${rows.map(m=>card(m.question.tag,`<p class="prose">${e(m.question.text)}</p><p>İlk cevabın: ${e(m.studentAnswer)} · ${m.date}</p>${select('reason','Yanlış yapma nedenin',mistakeReasons,m.reason,`data-ec-change="reason" data-id="${m.id}"`)}<details><summary>Yeniden çöz (${m.history.filter(h=>h.correct).length}/${m.history.length} başarılı)</summary><form data-ec="retry" data-id="${m.id}">${questionInputs(m.question,null)}<button class="btn secondary">Cevabımı kontrol et</button></form>${retryFeedback?.id===m.id?`<p class="notice">${retryFeedback.correct?'Doğru!':'Henüz doğru değil.'} ${e(m.question.explain)}</p>`:''}<p>Doğru cevap: ${e(answerText(m.question))}</p><p class="prose">${e(m.question.explain)}</p></details><details><summary>Tekrar geçmişi</summary>${m.history.length?m.history.slice(-20).reverse().map(h=>`<p>${h.date} · ${h.correct?'✓ Doğru':'Tekrar gerekli'} · ${e(h.answer)}</p>`).join(''):empty('Henüz yeniden çözülmedi.')}</details><div class="actions">${btn('queue-review','Akıllı tekrara ekle',m.id)}${link('review','Tekrar merkezine git','ghost')}</div>`)).join('')||empty('Henüz yanlış kaydın yok. Denemeden veya bu formdan ekleyebilirsin.')}</div>
    <aside>${card('Elle soru ekle',`<form data-ec="manual-mistake">${select('topicKey','Ders / konu',Object.fromEntries(topics.map(t=>[t.key,t.subjectLabel+' — '+t.label])),topics[0].key)}<label class="field">Soru<textarea name="text" maxlength="3000" required></textarea></label>${field('studentAnswer','Verdiğin cevap','','text','maxlength="300"')}${field('answer','Doğru kısa cevap','','text','maxlength="300" required')}<label class="field">Açıklamalı çözüm<textarea name="explain" maxlength="5000" required></textarea></label><button class="btn secondary">Yanlış sorumu kaydet</button></form><p class="input-hint">Metin kaydı desteklenir. Görsel soru yükleme bu sürümde bulunmuyor.</p>`)}</aside></div>`;
}
function lineChart(rows,subject='all'){
  if(!rows.length)return empty('Bu kapsamda henüz deneme yok.');
  const values=rows.map(r=>subject==='all'?r.net:r.subjects.find(s=>s.id===subject)?.net??0),min=Math.min(0,...values),max=Math.max(1,...values),range=max-min||1,coords=values.map((v,i)=>({x:45+(rows.length===1?0:i/(rows.length-1))*610,y:185-(v-min)/range*155}));
  return `<div class="ec-chart"><svg viewBox="0 0 700 225" role="img" aria-label="Eş kapsamlı denemelerin gerçek net değişimi"><path d="M45 20V190H675" fill="none" stroke="var(--line)"/><text x="5" y="30">${fmt(max)}</text><text x="5" y="190">${fmt(min)}</text><polyline points="${coords.map(p=>p.x+','+p.y).join(' ')}" fill="none" stroke="var(--green)" stroke-width="3"/>${coords.map((p,i)=>`<circle cx="${p.x}" cy="${p.y}" r="5" fill="var(--green)"><title>${e(rows[i].date)}: ${fmt(values[i])} net</title></circle>`).join('')}<text x="45" y="215">${rows[0].date}</text><text x="570" y="215">${rows.at(-1).date}</text></svg></div><div class="ec-chart-points" aria-label="Grafik verilerini incele">${rows.map((r,i)=>btn('point',r.date+' · '+fmt(values[i])+' net',r.id,'ghost small')).join('')}</div>`;
}
function reportsPage(ctx,p){
  const s=ctx.state,a=analysis(s,p.id),all=a.results,groups=[...new Map(all.map(r=>[r.signature,r])).values()];
  if(!groups.some(r=>r.signature===signature))signature=groups.at(-1)?.signature||'';
  const summary=netSummary(s,p.id,signature),rows=summary.rows.slice(-40),last=summary.last,subjectOptions={all:'Toplam net',...Object.fromEntries((last?.subjects||[]).map(s=>[s.id,s.label]))};
  if(!Object.hasOwn(subjectOptions,chartSubject))chartSubject='all';
  const report=s.examCoach.weeklyReports.find(r=>r.profileId===p.id&&r.week===shiftDay(localDay(),-((new Date().getDay()+6)%7))),reasons=Object.entries(mistakeReasons).map(([id,label])=>({label,count:s.examCoach.mistakes.filter(m=>m.profileId===p.id&&m.reason===id).length})),point=all.find(r=>r.id===selectedPoint),seven=Array.from({length:7},(_,i)=>{const date=shiftDay(localDay(),i-6);return {date,minutes:s.sessions.filter(x=>x.profileId===p.id&&x.date===date).reduce((n,x)=>n+x.seconds/60,0)};});
  return `<div class="toolbar">${select('signature','Aynı kapsam ve tür',Object.fromEntries(groups.map(r=>[r.signature,`${mockKinds[r.kind]} · ${r.subjects.map(s=>s.label+' '+s.total).join(', ')}`])),signature,'data-ec-change="report-signature"')}${select('subject','Grafikte göster',subjectOptions,chartSubject,'data-ec-change="report-subject"')}</div><p class="input-hint">Farklı soru sayısı, ders bileşimi, dil, alan, kural sürümü veya deneme türü aynı net grafiğine karıştırılmaz.</p>
    <div class="stats">${metric('Son eş kapsamlı net',fmt(last?.net))}${metric('En yüksek net',fmt(summary.best))}${metric('Ortalama net',fmt(summary.average))}${metric('Son 5 ortalaması',fmt(summary.lastFive))}</div>
    ${card('Net yolculuğun',lineChart(rows,chartSubject)+(point?`<p role="status"><strong>${e(point.title)}</strong> · ${point.date} · ${point.subjects.map(s=>e(s.label)+': '+fmt(s.net)).join(' / ')}</p>`:''))}
    <div class="ec-grid">${card('Hedef netin',summary.gap===null?empty('Hedef farkı yalnız tam denemeyle karşılaştırılır. Mini denemeden tam sınav sonucu tahmin edilmez.'):`<strong class="ec-value">${fmt(last.net)} / ${fmt(p.targetNet)}</strong><p>Hedefe kalan ${fmt(Math.max(0,summary.gap))} net</p>${meter(p.targetNet?Math.max(0,Math.min(100,Math.round(last.net/p.targetNet*100))):100,'Hedef net ilerlemesi')}`)}
    ${card('Konu tamamlama',a.subjects.map(x=>`<p>${e(x.label)} · ${x.done}/${x.topics.length}</p>${meter(Math.round(x.done/x.topics.length*100),x.label+' tamamlanma')}`).join(''))}
    ${card('Son 7 gün gerçek çalışma süresi',`<div class="ec-week-bars">${seven.map(x=>`<div><strong>${fmt(x.minutes)} dk</strong><span style="height:${Math.max(2,Math.min(100,x.minutes/Math.max(1,...seven.map(t=>t.minutes))*100))}px"></span><small>${x.date.slice(5)}</small></div>`).join('')}</div><p class="input-hint">Bu profile ait ortak plan sayacından kaydedilen süre. Elle girilen deneme süresi odak süresine eklenmez.</p>`)}
    ${card('Doğru / yanlış / boş',last?`<div class="ec-dist">${['correct','wrong','blank'].map(k=>{const n=last.subjects.reduce((n,x)=>n+x[k],0);return `<div><strong>${n}</strong><small>${({correct:'Doğru',wrong:'Yanlış',blank:'Boş'})[k]}</small>${meter(Math.round(n/last.subjects.reduce((n,x)=>n+x.total,0)*100),k)}</div>`}).join('')}</div>`:empty('Veri yok.'))}
    ${card('Yanlış nedenlerin',reasons.map(r=>`<div class="row"><span>${e(r.label)}</span><strong>${r.count}</strong></div>`).join(''))}
    ${card('Eksik analizi',a.subjects.map(s=>`<div class="row"><div><strong>${e(s.label)}</strong><small>${s.total?s.correct+'/'+s.total+' doğru · '+(s.total<5?'Küçük örneklem':'Kaydedilen gerçek cevap sayısı'):'Henüz ölçülmedi'}</small></div><strong>${s.rate===null?'—':'%'+s.rate}</strong></div>`).join('')+a.recommendations.map(r=>`<p><strong>${e(r.label)}</strong><br>${e(r.reason)} Önerilen başlangıç: ${r.questions} soru.</p>`).join(''))}</div>
    ${card('Haftalık raporun',report?`<p>${report.week} haftası · ${Math.floor(report.seconds/60)} dk gerçek çalışma · ${report.questions} deneme sorusu</p><p>Gelişen konular: ${report.improved.length?report.improved.map(k=>e(a.topics.find(t=>t.key===k)?.label)).join(', '):'Karşılaştırma için iki dönemde de en az 3 gözlem gerekli.'}</p><p>Eş kapsamlı net değişimi: ${report.netChange===null?'Yeterli veri yok':fmt(report.netChange)}</p><p>Gelecek hafta odak: ${report.focus.map(k=>e(a.topics.find(t=>t.key===k)?.label)).join(', ')||'Başlangıç ölçümü'}</p>${btn('weekly','Raporu güncelle')}`:`<p>Bu haftanın gerçek kayıtlarından rapor oluştur. Rapor cihazında saklanır.</p>${btn('weekly','Haftalık raporu oluştur')}`)}${aiPanel(s,p)}`;
}
function aiPanel(state,p){
  const data=JSON.stringify(coachContext(state,p.id),null,2);
  return card('✦ AI Sınav Koçun',`<p>Planının nedenlerini, denemeni veya eksiklerini mevcut Gemini bağlantısıyla konuş. Hesaplamalar ve plan AI olmadan da çalışır.</p><form data-ec="ai"><label class="field">Koçuna sor<textarea name="message" maxlength="6000" required placeholder="Matematik netimi geliştirmek için hangi adımla başlamalıyım?">${e(aiOwner===p.id?aiMessage:'')}</textarea></label><label class="check"><input type="checkbox" name="share">Yalnız aşağıdaki özetimi Gemini’ye gönder</label><details><summary>Paylaşılabilecek özeti incele</summary><pre class="code">${e(data)}</pre></details><p class="input-hint">Paylaşım seçilmezse sadece yazdığın mesaj gönderilir. Ad, okul, API anahtarı, belge ve bütün cevap geçmişi gönderilmez. Yanlış sorunu açıklatmak için soru metnini mesajına kendin ekleyebilirsin.</p><button class="btn secondary" ${aiBusy?'disabled':''}>${aiBusy?'Yanıt hazırlanıyor…':'Koçuma sor'}</button></form>${aiReply&&aiOwner===p.id?`<div class="notice prose" role="status">${e(aiReply)}</div>`:''}`);
}
export function renderPage(ctx){
  const [,tab='overview',id]=ctx.route(),s=ctx.state.examCoach;
  const record=tab==='session'?s.sessions.find(x=>x.id===id):tab==='result'?s.results.find(x=>x.id===id):null;
  const profileId=record?.profileId||(tab==='topics'?ctx.route()[3]:null);
  if(profileId&&s.activeProfileId!==profileId&&s.profiles.some(p=>p.id===profileId)){s.activeProfileId=profileId;ctx.save().catch(err=>ctx.toast(err.message,true));}
  if(tab==='profile')return `<div class="ec-root">${header(ctx,tab)}${profileForm(ctx,id)}</div>`;
  const p=s.profiles.find(p=>p.id===s.activeProfileId);
  if(!p)return `<div class="ec-root">${header(ctx,'overview')}<section class="ec-welcome"><span class="ec-welcome-icon">◎</span><h2>Büyük hedefler, ölçülebilen küçük adımlar.</h2><p>Sınavını seç; konularını, denemelerini ve çalışma programını tek bir yolculukta takip et. Verilerin bu cihazda saklanır.</p>${link('examcoach/profile/new','İlk sınav profilimi oluştur','')}<div class="ec-welcome-exams">LGS <span>·</span> TYT <span>·</span> AYT <span>·</span> YDT</div></section></div>`;
  let body;
  if(tab==='plan')body=program(ctx);else if(tab==='topics')body=topicsPage(ctx,p,id);else if(tab==='mocks')body=mocksPage(ctx,p);else if(tab==='session')body=sessionPage(ctx,id);else if(tab==='result')body=resultPage(ctx,id);else if(tab==='mistakes')body=mistakesPage(ctx,p);else if(tab==='reports')body=reportsPage(ctx,p);else body=overview(ctx,p);
  return `<div class="ec-root">${header(ctx,tabs[tab]?tab:'mocks')}${body}</div>`;
}
export function afterRender(ctx){
  if($('[data-ec="mock"]'))refreshMockInfo(ctx);
  if(ctx.route()[1]==='reports'&&ctx.state.examCoach.activeProfileId){
    const week=shiftDay(localDay(),-((new Date().getDay()+6)%7)),id=ctx.state.examCoach.activeProfileId;
    if(!ctx.state.examCoach.weeklyReports.some(r=>r.profileId===id&&r.week===week)){
      weeklyReport(ctx.state,id);ctx.save().then(()=>{if(ctx.route()[1]==='reports')ctx.render();}).catch(err=>ctx.toast(err.message,true));
    }
  }
  tick(ctx);
}
function refreshMockInfo(ctx){
  const form=$('[data-ec="mock"]');if(!form)return;const d=new FormData(form),p=getProfile(ctx.state),c=getConfig(p),kind=d.get('kind'),sub=c.subjects.find(s=>s.id===d.get('subject'))||c.subjects[0];
  const topicSelect=form.querySelector('[name="topic"]'),old=topicSelect.value;topicSelect.innerHTML=sub.topics.map(t=>option(t.id,t.label,old)).join('');
  for(const key of ['subject','topic','count','minutes'])form.querySelector(`[name="${key}"]`).closest('label').hidden=(key==='subject'&&!['subject','topic'].includes(kind))||(key==='topic'&&kind!=='topic')||(['count','minutes'].includes(key)&&['full','subject'].includes(kind));
  try{const b=mockBlueprint(ctx.state,p.id,{kind,subject:d.get('subject'),topic:topicSelect.value,count:Number(d.get('count')),minutes:Number(d.get('minutes'))});$('#ecMockInfo').textContent=`${b.count} soru · ${b.minutes} dakika. `+(b.shortages.length?'Yetersiz banka: '+b.shortages.map(x=>x.subject+' '+x.available+'/'+x.needed).join(', '):'Bu kapsamda deneme hazır.');}catch(err){$('#ecMockInfo').textContent=err.message;}
}
const saveRender=async(ctx,message)=>{await ctx.save();ctx.render();if(message)ctx.toast(message);};
export async function action(name,id,el,ctx){
  const s=ctx.state,coach=s.examCoach,[,tab,routeId]=ctx.route(),p=coach.profiles.find(p=>p.id===coach.activeProfileId);name=name.slice(3);
  if(name==='select-profile'){if(!coach.profiles.some(p=>p.id===id))throw Error('Profil bulunamadı.');coach.activeProfileId=id;signature='';selectedPoint=null;aiReply='';aiMessage='';profileDraft=null;await ctx.save();await ctx.go('examcoach');return;}
  if(name==='finish'){finishConfirmId=routeId;ctx.render();return;}
  if(name==='cancel-finish'){finishConfirmId=null;ctx.render();return;}
  if(name==='confirm-finish'){if(finishConfirmId!==id)throw Error('Önce denemeyi bitirme seçeneğini aç.');finishMock(s,id);finishConfirmId=null;await ctx.save();await ctx.go('examcoach/result/'+id);return;}
  if(name==='delete-profile'){if(!confirm('Bu sınav profili, deneme cevapları, yanlışlar, tekrar kartları ve konu verileri silinecek. Diğer profiller ve toplam çalışma sürelerin korunur. Önce bir yedek indirilecek. Devam edilsin mi?'))return;ctx.exportBackup();deleteProfile(s,id);await ctx.save();await ctx.go('examcoach');return;}
  if(name==='rebuild'){rebuildPlan(s);await saveRender(ctx,'Plan ortak zaman bütçene göre güncellendi.');return;}
  if(name.startsWith('task-')){const date=localDay();if(name==='task-start')startTask(s,date,id);else {const task=s.learning.plans.find(p=>p.date===date).tasks.find(t=>t.id===id);if(!task||task.status!=='pending')throw Error('Görev bulunamadı.');if(name==='task-pause'){if(s.learning.activeTask?.taskId===id)settleTask(s,'pause');}else{if(s.learning.activeTask?.taskId===id)settleTask(s,'done');else task.status='done';}}await saveRender(ctx);return;}
  if(['pause','resume','finish','blank','mark','previous','next','question'].includes(name)){
    const x=currentSession(s,routeId);updateMockClock(s,x.id);
    if(x.status==='done'){await saveRender(ctx);return;}
    if(name==='pause')pauseMock(s,x.id);else if(name==='resume')resumeMock(s,x.id);else if(name==='finish'){if(!confirm('Denemeyi bitirip sonuçları hesaplayalım mı? Boşlar ayrı gösterilecek.'))return;finishMock(s,x.id);await ctx.save();await ctx.go('examcoach/result/'+x.id);return;}else{
      if(x.status!=='running')throw Error('Önce denemeyi devam ettir.');
      if(name==='blank')answerMock(s,x.id,x.index,null);else if(name==='mark')x.marked=x.marked.includes(x.index)?x.marked.filter(i=>i!==x.index):[...x.marked,x.index];else{const indices=x.stages[x.stageIndex].indices,i=name==='question'?Number(id):indices[indices.indexOf(x.index)+(name==='next'?1:-1)];if(indices.includes(i))x.index=i;}
    }await saveRender(ctx);return;
  }
  if(name==='save-wrong'){const split=id.lastIndexOf(':'),x=currentSession(s,id.slice(0,split)),i=Number(id.slice(split+1));const {addMistake}=await import('./exam-engine.mjs');addMistake(s,x.profileId,x.questions[i],x.answers[i]);await saveRender(ctx,'Yanlışlar defterine kaydedildi.');return;}
  if(name==='queue-review'){queueMistakeReview(s,id);await saveRender(ctx,'Akıllı tekrar kartı hazır; aynı soru ikinci kez eklenmez.');return;}
  if(name==='point'){selectedPoint=id;ctx.render();return;}
  if(name==='weekly'){weeklyReport(s,p.id);await saveRender(ctx,'Haftalık rapor kaydedildi.');return;}
}
function readAnswer(q,value){return value===null?null:q.type==='choice'?Number(value):q.type==='boolean'?value==='true':String(value);}
export async function submit(form,ctx){
  const d=new FormData(form),s=ctx.state,p=s.examCoach.profiles.find(p=>p.id===s.examCoach.activeProfileId),kind=form.dataset.ec;
  if(kind==='profile'){
    const old=s.examCoach.profiles.find(p=>p.id===form.dataset.id),exam=old?.exam||d.get('exam');
    const input={title:String(d.get('title')).trim(),exam,field:exam==='AYT'?(old?.field||d.get('field')):null,language:exam==='YDT'?(old?.language||d.get('language')):null,targetDate:d.get('targetDate'),dailyMinutes:Number(d.get('dailyMinutes')),workDays:d.getAll('workDays').map(Number),targetNet:Number(d.get('targetNet')),subjects:d.getAll('subjects'),level:Number(d.get('level')),enabled:d.has('enabled')};
    saveProfile(s,input,old?.id);profileDraft=null;await ctx.save();await ctx.go('examcoach');ctx.toast('Sınav profilin ve ortak programın hazır.');return;
  }
  if(kind==='mock'){const x=startMock(s,p.id,{kind:d.get('kind'),subject:d.get('subject'),topic:d.get('topic'),count:Number(d.get('count')),minutes:Number(d.get('minutes'))});await ctx.save();await ctx.go('examcoach/session/'+x.id);return;}
  if(kind==='answer'){const x=currentSession(s,form.dataset.id);answerMock(s,x.id,x.index,readAnswer(x.questions[x.index],d.get('answer')));await ctx.save();ctx.toast('Cevabın kaydedildi.');return;}
  if(kind==='manual-result'){
    const subjects=getConfig(p).subjects.filter(sub=>['correct','wrong','blank'].some(k=>String(d.get(sub.id+'-'+k)).trim()!=='')).map(sub=>({id:sub.id,correct:Number(d.get(sub.id+'-correct')),wrong:Number(d.get(sub.id+'-wrong')),blank:Number(d.get(sub.id+'-blank'))}));
    const topics=String(d.get('topics')).trim().split('\n').filter(Boolean).map(line=>{const [subject,topic,correct,wrong,blank,...extra]=line.split(',').map(x=>x.trim());if(extra.length||[correct,wrong,blank].some(x=>x===undefined||x===''))throw Error('Konu satırı ders,konu,doğru,yanlış,boş biçiminde olmalı.');return {key:`exam:${p.id}:${subject}:${topic}`,correct:Number(correct),wrong:Number(wrong),blank:Number(blank)};});
    const r=addManualResult(s,p.id,{title:d.get('title'),date:d.get('date'),minutes:Number(d.get('minutes')),kind:d.get('kind'),subjects,topics});await ctx.save();await ctx.go('examcoach/result/'+r.id);return;
  }
  if(kind==='bank'){let rows;try{rows=JSON.parse(d.get('json'));}catch{throw Error('Geçerli bir JSON soru dizisi gir.');}const count=importQuestions(s,p.id,rows);await saveRender(ctx,count+' soru bankaya eklendi.');return;}
  if(kind==='manual-mistake'){manualMistake(s,p.id,Object.fromEntries(d));await saveRender(ctx,'Yanlış sorusu kaydedildi.');return;}
  if(kind==='retry'){const m=s.examCoach.mistakes.find(m=>m.id===form.dataset.id);if(d.get('answer')===null||d.get('answer')==='')throw Error('Önce cevabını gir.');const correct=retryMistake(s,m.id,readAnswer(m.question,d.get('answer')));retryFeedback={id:m.id,correct};await saveRender(ctx,correct?'Doğru, tekrar geçmişine işlendi.':'Tekrar gerekli; açıklamayı inceleyebilirsin.');return;}
  if(kind==='ai'){
    if(aiBusy)return;const message=String(d.get('message')).trim();if(!message||message.length>6000)throw Error('Mesaj 1–6000 karakter olmalı.');aiMessage=message;aiReply='';aiBusy=true;aiOwner=p.id;
    const payload={message,mode:'examcoach',...(d.has('share')?{studyConsent:true,studyContext:coachContext(s,p.id)}:{})};ctx.render();
    try{const res=await fetch('/api/ai/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(45000)}),data=await res.json();if(!res.ok)throw Error(data.error||'AI yanıtı alınamadı.');aiReply=data.reply;aiMessage='';}catch(err){aiReply='AI şu an kullanılamıyor: '+err.message+' Planın, denemelerin ve raporların çalışmaya devam ediyor.';}finally{aiBusy=false;if(ctx.route()[0]==='examcoach')ctx.render();}return;
  }
}
export async function change(el,ctx){
  const type=el.dataset.ecChange,s=ctx.state,p=s.examCoach.profiles.find(p=>p.id===s.examCoach.activeProfileId);
  if(type==='profile-exam'){
    const form=el.closest('form'),d=new FormData(form),old=s.examCoach.profiles.find(p=>p.id===form.dataset.id),exam=old?.exam||d.get('exam');
    profileDraft={exam,title:d.get('title')===(profileDraft?.exam||old?.exam||'TYT')?exam:d.get('title'),targetDate:d.get('targetDate'),dailyMinutes:Number(d.get('dailyMinutes')),targetNet:Number(d.get('targetNet')),level:Number(d.get('level')),workDays:d.getAll('workDays').map(Number),subjects:[],field:exam==='AYT'?(d.get('field')||'sayisal'):null,language:exam==='YDT'?(d.get('language')||'en'):null,enabled:d.has('enabled')};ctx.render();return;
  }
  if(type==='mock-settings'){refreshMockInfo(ctx);return;}
  if(type==='topic-status'){const key=el.dataset.key;setTopicStatus(s,p.id,key,el.value);await saveRender(ctx);$('[data-key="'+key+'"]')?.focus();return;}
  if(type==='auto-mistakes'){s.examCoach.autoMistakes=el.checked;await ctx.save();return;}
  if(type==='reason'){const m=s.examCoach.mistakes.find(m=>m.id===el.dataset.id);if(!m||!Object.hasOwn(mistakeReasons,el.value))throw Error('Yanlış nedeni geçersiz.');m.reason=el.value;await ctx.save();return;}
  if(type==='report-signature'){signature=el.value;selectedPoint=null;ctx.render();return;}
  if(type==='report-subject'){chartSubject=el.value;ctx.render();return;}
  if(type==='answer'){
    const x=currentSession(s,ctx.route()[2]);answerMock(s,x.id,x.index,readAnswer(x.questions[x.index],el.value));await ctx.save();if(el.type!=='text')ctx.render();return;
  }
}
export function tick(ctx){
  const s=ctx.state;if(!s.examCoach||busyTick)return;
  const running=s.examCoach.sessions.filter(x=>x.status==='running'),now=Date.now(),needsCheckpoint=running.length&&now-lastCheckpoint>15000;
  let changed=false;for(const x of running)changed=updateMockClock(s,x.id,now)||changed;
  const active=s.learning.activeTask,task=active?s.learning.plans.find(p=>p.date===active.date)?.tasks.find(t=>t.id===active.taskId):null;
  if(task&&active.startedAt!==null&&taskElapsed(s,now)>=task.minutes*60){settleTask(s,'pause',now);changed=true;ctx.toast('Göreve ayırdığın süre doldu; sayaç duraklatıldı.');}
  const id=ctx.route()[1]==='session'?ctx.route()[2]:null,x=s.examCoach.sessions.find(x=>x.id===id);
  if($('#ecCountdown')&&x){const left=Math.ceil(remaining(x,now)/1000);$('#ecCountdown').textContent=String(Math.floor(left/60)).padStart(2,'0')+':'+String(left%60).padStart(2,'0');}
  if($('#ecTaskClock')){const n=taskElapsed(s,now);$('#ecTaskClock').textContent=s.learning.activeTask?'Aktif görev sayacı: '+Math.floor(n/60)+' dk '+n%60+' sn':'';}
  if(changed||needsCheckpoint){lastCheckpoint=now;busyTick=true;ctx.save().then(()=>{if(changed&&ctx.route()[0]==='examcoach')ctx.render();}).catch(err=>ctx.toast(err.message,true)).finally(()=>busyTick=false);}
}
