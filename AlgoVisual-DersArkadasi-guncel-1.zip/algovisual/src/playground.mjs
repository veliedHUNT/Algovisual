import { localDay, recordEvidence } from "./learning-state.mjs";
const item = (name, group, time, space, input, code) => ({
  name,
  group,
  time,
  space,
  input,
  code,
});
export const algorithms = {
  bubble: item(
    "Bubble Sort",
    "Sıralama",
    "En iyi O(n), ortalama/en kötü O(n²)",
    "O(1)",
    "8, 3, 6, 1",
    [
      "for end = n-1 down to 1:",
      "  changed = false",
      "  for i = 0 to end-1:",
      "    compare a[i], a[i+1]",
      "    if a[i] > a[i+1]: swap; changed = true",
      "  if not changed: break",
      "return a",
    ],
  ),
  selection: item("Selection Sort", "Sıralama", "O(n²)", "O(1)", "8, 3, 6, 1", [
    "for i = 0 to n-2:",
    "  minimum = i",
    "  for j = i+1 to n-1:",
    "    compare a[j], a[minimum]",
    "    if smaller: minimum = j",
    "  if minimum != i: swap a[i], a[minimum]",
    "return a",
  ]),
  insertion: item(
    "Insertion Sort",
    "Sıralama",
    "En iyi O(n), ortalama/en kötü O(n²)",
    "O(1)",
    "8, 3, 6, 1",
    [
      "for i = 1 to n-1:",
      "  key = a[i]; j = i-1",
      "  while j >= 0:",
      "    compare a[j], key; if a[j] <= key: break",
      "    a[j+1] = a[j]; j -= 1",
      "  a[j+1] = key",
      "return a",
    ],
  ),
  merge: item(
    "Merge Sort",
    "Sıralama",
    "O(n log n)",
    "O(n) + O(log n) çağrı yığını",
    "8, 3, 6, 1",
    [
      "sort(left, right):",
      "  if right-left < 2: return",
      "  mid = floor((left+right)/2)",
      "  sort(left, mid); sort(mid, right)",
      "  copy halves into temporary arrays",
      "  compare first remaining items",
      "  copy smaller item back",
      "  copy remaining items",
      "return a",
    ],
  ),
  quick: item(
    "Quick Sort",
    "Sıralama",
    "Ortalama O(n log n), en kötü O(n²)",
    "Ortalama O(log n), en kötü O(n) çağrı yığını",
    "8, 3, 6, 1",
    [
      "sort(low, high):",
      "  if low >= high: return",
      "  pivot = a[high]; i = low",
      "  for j = low to high-1:",
      "    compare a[j], pivot",
      "    if a[j] < pivot: swap a[i], a[j]; i += 1",
      "  swap a[i], a[high]",
      "  sort(low, i-1); sort(i+1, high)",
      "return a",
    ],
  ),
  linear: item(
    "Linear Search",
    "Arama",
    "En iyi O(1), en kötü O(n)",
    "O(1)",
    "1, 3, 5, 7, 9",
    [
      "for i = 0 to n-1:",
      "  compare a[i], target",
      "  if equal: return i",
      "return -1",
    ],
  ),
  binary: item(
    "Binary Search",
    "Arama",
    "En iyi O(1), en kötü O(log n)",
    "O(1)",
    "1, 3, 5, 7, 9",
    [
      "low = 0; high = n-1",
      "while low <= high:",
      "  mid = floor((low+high)/2)",
      "  compare a[mid], target",
      "  if equal: return mid",
      "  if a[mid] < target: low = mid+1",
      "  else: high = mid-1",
      "return -1",
    ],
  ),
  stack: item(
    "Stack",
    "Veri yapısı",
    "Push/pop O(1)",
    "O(n)",
    "push 4; push 8; peek; pop",
    [
      "for operation in operations:",
      "  if push: append value to top",
      "  if pop: remove top (if present)",
      "  if peek: read top (if present)",
      "return stack",
    ],
  ),
  queue: item(
    "Queue",
    "Veri yapısı",
    "Mantıksal enqueue/dequeue O(1)",
    "O(n)",
    "enqueue 4; enqueue 8; peek; dequeue",
    [
      "for operation in operations:",
      "  if enqueue: append value at tail",
      "  if dequeue: advance head (if present)",
      "  if peek: read head (if present)",
      "return queue[head:]",
    ],
  ),
  linked: item(
    "Linked List",
    "Veri yapısı",
    "Sona ekleme O(1), bulma/silme O(n)",
    "O(n)",
    "add 4; add 8; add 2; find 8; remove 4",
    [
      "for operation in operations:",
      "  if add: link new node after tail",
      "  walk nodes to find value",
      "  if remove and found: reconnect neighbours",
      "return linked list",
    ],
  ),
  bst: item(
    "Binary Search Tree",
    "Veri yapısı",
    "Ekleme/arama O(h); dengeli O(log n), en kötü O(n)",
    "O(n)",
    "insert 5; insert 2; insert 8; find 2",
    [
      "for operation in operations:",
      "  current = root",
      "  compare value, current.value",
      "  follow left if smaller, right if larger",
      "  if insert and empty: attach new node",
      "  if find and equal: report found",
      "return tree",
    ],
  ),
  bfs: item("BFS", "Graf", "O(V + E)", "O(V)", "", [
    "enqueue start; mark discovered",
    "while queue is not empty:",
    "  node = dequeue; visit node",
    "  for neighbour in adjacency[node]:",
    "    if not discovered: mark and enqueue",
    "return visited",
  ]),
  dfs: item("DFS", "Graf", "O(V + E)", "O(V)", "", [
    "push start; mark discovered",
    "while stack is not empty:",
    "  node = pop; visit node",
    "  for neighbour in reverse(adjacency[node]):",
    "    if not discovered: mark and push",
    "return visited",
  ]),
  dijkstra: item(
    "Dijkstra",
    "Graf",
    "Bu doğrusal seçim uygulamasında O(V² + E)",
    "O(V + E)",
    "",
    [
      "distance[start] = 0; others = infinity",
      "while unvisited reachable node exists:",
      "  node = unvisited node with minimum distance",
      "  mark node visited",
      "  for edge from node to neighbour:",
      "    compare new distance with old distance",
      "    if shorter: update distance and predecessor",
      "return distances and predecessors",
    ],
  ),
};
export const graphExample = JSON.stringify({
  nodes: ["A", "B", "C", "D", "E"],
  edges: [
    ["A", "B", 2],
    ["A", "C", 5],
    ["B", "C", 1],
    ["B", "D", 4],
    ["C", "E", 2],
    ["D", "E", 1],
  ],
  directed: false,
});
for (const key of ["bfs", "dfs", "dijkstra"])
  algorithms[key].input = graphExample;
export function parseNumbers(input) {
  if (typeof input !== "string" || input.length > 1000)
    throw Error("Girdi en fazla 1.000 karakter olabilir.");
  if (!input.trim()) return [];
  const values = input
    .split(",")
    .map((x) => x.trim())
    .map((x) => (x === "" ? NaN : Number(x)));
  if (
    values.length > 24 ||
    values.some((x) => !Number.isFinite(x) || Math.abs(x) > 1000000)
  )
    throw Error(
      "Virgülle ayrılmış en fazla 24 sayı gir (−1.000.000 ile 1.000.000).",
    );
  return values;
}
export function parseGraph(input, start) {
  let g;
  try {
    g = JSON.parse(input);
  } catch {
    throw Error("Graf geçerli JSON olmalı.");
  }
  if (
    !g ||
    !Array.isArray(g.nodes) ||
    !g.nodes.length ||
    g.nodes.length > 12 ||
    g.nodes.some(
      (x) =>
        typeof x !== "string" ||
        !/^[A-Za-z0-9]{1,12}$/.test(x) ||
        ["constructor", "prototype", "__proto__"].includes(x),
    ) ||
    new Set(g.nodes).size !== g.nodes.length ||
    !g.nodes.includes(start) ||
    !Array.isArray(g.edges) ||
    g.edges.length > 40 ||
    typeof g.directed !== "boolean" ||
    g.edges.some(
      (e) =>
        !Array.isArray(e) ||
        e.length !== 3 ||
        !g.nodes.includes(e[0]) ||
        !g.nodes.includes(e[1]) ||
        !Number.isFinite(e[2]) ||
        e[2] < 0 ||
        e[2] > 1000000,
    )
  )
    throw Error(
      "Graf: 1–12 benzersiz düğüm, en fazla 40 kenar, negatif olmayan ağırlıklar ve geçerli başlangıç düğümü gerekli.",
    );
  return g;
}
const operations = {
  compare: "Karşılaştır",
  swap: "Takas et",
  write: "Değer yaz / güncelle",
  visit: "Düğümü ziyaret et",
  push: "Yapıya eleman ekle",
  pop: "Yapıdan eleman çıkar",
  inspect: "Durumu incele",
  done: "Sonucu döndür",
};
const hashInput = (s) => {
  let h = 0;
  for (const c of s) h = (Math.imul(h, 31) + c.codePointAt(0)) | 0;
  return (h >>> 0).toString(16);
};
export function buildSimulation(
  kind,
  input = algorithms[kind]?.input,
  parameter = "5",
) {
  const meta = algorithms[kind];
  if (!meta) throw Error("Algoritma bulunamadı.");
  if (typeof input !== "string" || input.length > 6000)
    throw Error("Simülasyon girdisi çok uzun.");
  const steps = [],
    metrics = { comparisons: 0, swaps: 0, writes: 0, visits: 0 };
  const emit = (
    line,
    vars,
    explain,
    visual = {},
    operation = "inspect",
    output = "",
  ) => {
    if (steps.length >= 5000)
      throw Error("5.000 adımlık simülasyon sınırı aşıldı.");
    steps.push(
      structuredClone({
        line,
        vars,
        explain,
        visual,
        operation,
        output,
        metrics,
      }),
    );
  };
  if (meta.group === "Sıralama") {
    const a = parseNumbers(input),
      visual = (active = []) => ({ array: a, active });
    emit(1, { n: a.length }, "Başlangıç dizisi.", visual());
    const swap = (i, j, line, vars = {}) => {
      if (i !== j) {
        [a[i], a[j]] = [a[j], a[i]];
        metrics.swaps++;
        metrics.writes += 2;
      }
      emit(
        line,
        { ...vars, i, j },
        "İndis " +
          i +
          " ve " +
          j +
          (i === j ? " aynı; fiziksel takas gerekmedi." : " yer değiştirdi."),
        visual([i, j]),
        i === j ? "inspect" : "swap",
      );
    };
    if (kind === "bubble") {
      for (let end = a.length - 1; end > 0; end--) {
        let changed = false;
        emit(
          2,
          { end, changed },
          "Bu tur için takas işareti sıfırlandı.",
          visual(),
        );
        for (let i = 0; i < end; i++) {
          metrics.comparisons++;
          emit(
            4,
            { i, end, left: a[i], right: a[i + 1] },
            "Komşu değerler karşılaştırılıyor.",
            visual([i, i + 1]),
            "compare",
          );
          if (a[i] > a[i + 1]) {
            swap(i, i + 1, 5, { end });
            changed = true;
          }
        }
        emit(
          6,
          { end, changed },
          changed
            ? "Tur tamamlandı; bir sonraki tur başlıyor."
            : "Takas yok; dizi sıralı, erken dur.",
          visual(),
        );
        if (!changed) break;
      }
    } else if (kind === "selection") {
      for (let i = 0; i < a.length - 1; i++) {
        let minimum = i;
        emit(
          2,
          { i, minimum },
          "Sıralanmamış bölümün ilk elemanı aday minimum.",
          visual([i]),
        );
        for (let j = i + 1; j < a.length; j++) {
          metrics.comparisons++;
          emit(
            4,
            { i, j, minimum },
            "Aday minimum ile sıradaki değer karşılaştırıldı.",
            visual([j, minimum]),
            "compare",
          );
          if (a[j] < a[minimum]) {
            minimum = j;
            emit(
              5,
              { i, j, minimum },
              "Daha küçük eleman bulundu.",
              visual([minimum]),
              "write",
            );
          }
        }
        if (minimum !== i) swap(i, minimum, 6);
      }
    } else if (kind === "insertion") {
      for (let i = 1; i < a.length; i++) {
        const key = a[i];
        let j = i - 1;
        emit(
          2,
          { i, j, key },
          "Yerleştirilecek değer geçici olarak saklandı.",
          visual([i]),
        );
        while (j >= 0) {
          metrics.comparisons++;
          emit(
            4,
            { i, j, key },
            "Soldaki değer ile anahtar karşılaştırılıyor.",
            visual([j]),
            "compare",
          );
          if (a[j] <= key) break;
          a[j + 1] = a[j];
          metrics.writes++;
          emit(
            5,
            { i, j, key },
            "Büyük değer bir konum sağa kaydırıldı.",
            visual([j, j + 1]),
            "write",
          );
          j--;
        }
        a[j + 1] = key;
        metrics.writes++;
        emit(
          6,
          { i, j, key },
          "Anahtar doğru konuma yerleştirildi.",
          visual([j + 1]),
          "write",
        );
      }
    } else if (kind === "merge") {
      const sort = (left, right) => {
        emit(2, { left, right }, "Alt aralık kontrol ediliyor.", visual());
        if (right - left < 2) return;
        const mid = Math.floor((left + right) / 2);
        emit(
          3,
          { left, mid, right },
          "Aralık ikiye bölündü.",
          visual([left, mid, right - 1]),
        );
        sort(left, mid);
        sort(mid, right);
        const l = a.slice(left, mid),
          r = a.slice(mid, right);
        let i = 0,
          j = 0,
          k = left;
        emit(
          5,
          { left, mid, right, leftHalf: l, rightHalf: r },
          "İki sıralı yarı geçici belleğe alındı.",
          visual(),
        );
        while (i < l.length && j < r.length) {
          metrics.comparisons++;
          emit(
            6,
            { i, j, k, left: l[i], right: r[j] },
            "İki yarının başındaki değerler karşılaştırılıyor.",
            visual([k]),
            "compare",
          );
          a[k] = l[i] <= r[j] ? l[i++] : r[j++];
          metrics.writes++;
          emit(
            7,
            { i, j, k },
            "Küçük olan değer ana diziye yazıldı.",
            visual([k]),
            "write",
          );
          k++;
        }
        while (i < l.length) {
          a[k] = l[i++];
          metrics.writes++;
          emit(
            8,
            { i, j, k },
            "Sol yarının kalanı yazıldı.",
            visual([k++]),
            "write",
          );
        }
        while (j < r.length) {
          a[k] = r[j++];
          metrics.writes++;
          emit(
            8,
            { i, j, k },
            "Sağ yarının kalanı yazıldı.",
            visual([k++]),
            "write",
          );
        }
      };
      sort(0, a.length);
    } else {
      const sort = (low, high) => {
        emit(
          2,
          { low, high },
          "Alt aralığın boyutu kontrol ediliyor.",
          visual(),
        );
        if (low >= high) return;
        const pivot = a[high];
        let i = low;
        emit(
          3,
          { low, high, pivot, i },
          "Son eleman pivot seçildi (Lomuto bölme).",
          visual([high]),
        );
        for (let j = low; j < high; j++) {
          metrics.comparisons++;
          emit(
            5,
            { low, high, pivot, i, j },
            "Değer pivotla karşılaştırılıyor.",
            visual([j, high]),
            "compare",
          );
          if (a[j] < pivot) {
            swap(i, j, 6, { pivot });
            i++;
          }
        }
        swap(i, high, 7, { pivot });
        emit(
          8,
          { low, high, pivot, index: i },
          "Pivotun sol ve sağ alt aralıkları işlenecek.",
          visual([i]),
        );
        sort(low, i - 1);
        sort(i + 1, high);
      };
      sort(0, a.length - 1);
    }
    emit(
      meta.code.length,
      { result: a },
      "Sıralama tamamlandı.",
      { array: a, sorted: a.map((_, i) => i) },
      "done",
      JSON.stringify(a),
    );
  } else if (meta.group === "Arama") {
    const a = parseNumbers(input),
      target = Number(parameter);
    if (
      !String(parameter).trim() ||
      !Number.isFinite(target) ||
      Math.abs(target) > 1000000
    )
      throw Error("Geçerli hedef sayı gir.");
    if (kind === "binary" && a.some((n, i) => i > 0 && n < a[i - 1]))
      throw Error(
        "Binary Search için dizinin küçükten büyüğe sıralı olması gerekir.",
      );
    let result = -1;
    if (kind === "linear") {
      emit(1, { target, n: a.length }, "Doğrusal arama başlıyor.", {
        array: a,
      });
      for (let i = 0; i < a.length; i++) {
        metrics.comparisons++;
        emit(
          2,
          { i, target, value: a[i] },
          "Eleman hedefle karşılaştırılıyor.",
          { array: a, active: [i] },
          "compare",
        );
        if (a[i] === target) {
          result = i;
          emit(
            3,
            { i, target },
            "Hedef bulundu.",
            { array: a, active: [i] },
            "done",
            String(i),
          );
          break;
        }
      }
      if (result < 0)
        emit(
          4,
          { result, target },
          "Hedef dizide yok.",
          { array: a },
          "done",
          "-1",
        );
    } else {
      let low = 0,
        high = a.length - 1;
      emit(1, { low, high, target }, "Başlangıç arama aralığı.", { array: a });
      while (low <= high) {
        const mid = Math.floor((low + high) / 2);
        emit(3, { low, high, mid, target }, "Orta indis hesaplandı.", {
          array: a,
          active: [mid],
        });
        metrics.comparisons++;
        emit(
          4,
          { low, high, mid, target, value: a[mid] },
          "Orta değer hedefle karşılaştırılıyor.",
          { array: a, active: [mid] },
          "compare",
        );
        if (a[mid] === target) {
          result = mid;
          emit(
            5,
            { result },
            "Hedef bulundu.",
            { array: a, active: [mid] },
            "done",
            String(mid),
          );
          break;
        }
        if (a[mid] < target) {
          low = mid + 1;
          emit(
            6,
            { low, high, mid, target },
            "Sol yarı elendi.",
            { array: a, active: [low, high] },
            "write",
          );
        } else {
          high = mid - 1;
          emit(
            7,
            { low, high, mid, target },
            "Sağ yarı elendi.",
            { array: a, active: [low, high] },
            "write",
          );
        }
      }
      if (result < 0)
        emit(
          8,
          { result, target },
          "Arama aralığı boş; hedef yok.",
          { array: a },
          "done",
          "-1",
        );
    }
  } else if (meta.group === "Veri yapısı") {
    const parts = input
      .split(";")
      .map((x) => x.trim())
      .filter(Boolean);
    if (parts.length > 60) throw Error("En fazla 60 işlem kullan.");
    const a = [],
      nodes = [],
      root = { value: null },
      queue = [];
    let head = 0;
    emit(1, { size: 0 }, "Boş veri yapısı oluşturuldu.", { array: [] });
    for (const part of parts) {
      const m = part.match(/^([a-z]+)(?:\s+(-?\d+(?:\.\d+)?))?$/);
      if (!m) throw Error("İşlemleri noktalı virgülle ayır: push 4; pop gibi.");
      const command = m[1],
        value = m[2] === undefined ? null : Number(m[2]);
      if (value !== null && Math.abs(value) > 1000000)
        throw Error("İşlem değeri çok büyük.");
      if (kind === "stack" || kind === "queue") {
        const add = kind === "stack" ? "push" : "enqueue",
          remove = kind === "stack" ? "pop" : "dequeue";
        if (command === add && value !== null) {
          if (kind === "stack") a.push(value);
          else queue.push(value);
          metrics.writes++;
          emit(
            2,
            { value, size: kind === "stack" ? a.length : queue.length - head },
            "Eleman " +
              (kind === "stack" ? "tepeye" : "kuyruğun sonuna") +
              " eklendi.",
            { array: kind === "stack" ? a : queue.slice(head) },
            "push",
          );
        } else if (command === remove && value === null) {
          const result =
            kind === "stack"
              ? a.pop()
              : head < queue.length
                ? queue[head++]
                : undefined;
          emit(
            3,
            {
              removed: result ?? "boş",
              size: kind === "stack" ? a.length : queue.length - head,
            },
            result === undefined
              ? "Yapı boş; eleman çıkarılamadı."
              : "Çıkarılan eleman: " + result,
            { array: kind === "stack" ? a : queue.slice(head) },
            "pop",
            result === undefined ? "Boş" : String(result),
          );
        } else if (command === "peek" && value === null) {
          const result = kind === "stack" ? a.at(-1) : queue[head];
          emit(
            4,
            { peek: result ?? "boş" },
            "Eleman çıkarılmadan okundu.",
            { array: kind === "stack" ? a : queue.slice(head) },
            "inspect",
            result === undefined ? "Boş" : String(result),
          );
        } else
          throw Error(
            "Bu yapı için " +
              add +
              " SAYI; " +
              remove +
              "; peek işlemlerini kullan.",
          );
      } else if (kind === "linked") {
        if (!["add", "find", "remove"].includes(command) || value === null)
          throw Error("Linked List: add SAYI; find SAYI; remove SAYI.");
        if (command === "add") {
          a.push(value);
          metrics.writes++;
          emit(
            2,
            { value, size: a.length },
            "Yeni düğüm listenin sonuna bağlandı.",
            { array: a, linked: true },
            "push",
          );
        } else {
          let index = -1;
          for (let i = 0; i < a.length; i++) {
            metrics.comparisons++;
            emit(
              3,
              { i, value, current: a[i] },
              "Düğüm değeri kontrol ediliyor.",
              { array: a, active: [i], linked: true },
              "compare",
            );
            if (a[i] === value) {
              index = i;
              break;
            }
          }
          if (command === "remove" && index >= 0) {
            a.splice(index, 1);
            metrics.writes++;
            emit(
              4,
              { value, index },
              "İlk eşleşen düğüm çıkarıldı, bağlantılar güncellendi.",
              { array: a, linked: true },
              "pop",
            );
          } else
            emit(
              3,
              { value, index },
              index < 0 ? "Değer bulunamadı." : "Değer bulundu.",
              { array: a, linked: true },
              "inspect",
              String(index),
            );
        }
      } else {
        if (!["insert", "find"].includes(command) || value === null)
          throw Error("BST: insert SAYI; find SAYI.");
        let node = root,
          parent = null,
          side = "",
          found = false;
        while (node.value !== null) {
          metrics.comparisons++;
          emit(
            3,
            { value, current: node.value },
            "Aranan/eklenecek değer düğümle karşılaştırılıyor.",
            { tree: root },
            "compare",
          );
          if (value === node.value) {
            found = true;
            break;
          }
          side = value < node.value ? "left" : "right";
          parent = node;
          if (!node[side]) node[side] = { value: null };
          node = node[side];
          emit(4, { value, direction: side }, "Uygun alt dala gidildi.", {
            tree: root,
          });
        }
        if (command === "insert" && !found) {
          node.value = value;
          nodes.push(value);
          metrics.writes++;
          emit(
            5,
            { value, parent: parent?.value ?? null },
            "Değer boş konuma eklendi.",
            { tree: root },
            "push",
          );
        } else
          emit(
            6,
            { value, found },
            found
              ? "Değer bulundu; yinelenen ekleme yapılmaz."
              : "Değer bulunamadı.",
            { tree: root },
            "inspect",
            String(found),
          );
      }
      if (Math.max(a.length, queue.length - head, nodes.length) > 24)
        throw Error("Görsel yapıda en fazla 24 eleman bulunabilir.");
    }
    const final =
      kind === "bst" ? root : kind === "queue" ? queue.slice(head) : a;
    emit(
      meta.code.length,
      { result: final },
      "İşlemler tamamlandı.",
      kind === "bst"
        ? { tree: root }
        : { array: final, linked: kind === "linked" },
      "done",
      JSON.stringify(final),
    );
  } else {
    const graph = parseGraph(input, String(parameter)),
      adj = new Map(graph.nodes.map((n) => [n, []]));
    for (const [a, b, w] of graph.edges) {
      adj.get(a).push([b, w]);
      if (!graph.directed && a !== b) adj.get(b).push([a, w]);
    }
    const start = String(parameter),
      visited = [],
      discovered = new Set([start]);
    const visual = (current = null, frontier = []) => ({
      graph,
      visited,
      current,
      frontier,
    });
    if (kind === "dijkstra") {
      const dist = new Map(graph.nodes.map((n) => [n, Infinity])),
        previous = new Map();
      dist.set(start, 0);
      const distances = () =>
        Object.fromEntries(
          [...dist].map(([n, d]) => [n, Number.isFinite(d) ? d : "∞"]),
        );
      emit(
        1,
        { distances: distances() },
        "Başlangıcın uzaklığı 0, diğerleri sonsuz.",
        visual(),
      );
      while (visited.length < graph.nodes.length) {
        let u = null;
        for (const n of graph.nodes) {
          if (visited.includes(n)) continue;
          metrics.comparisons++;
          if (
            Number.isFinite(dist.get(n)) &&
            (u === null || dist.get(n) < dist.get(u))
          )
            u = n;
        }
        if (u === null) break;
        emit(
          3,
          { node: u, distances: distances() },
          "En yakın ulaşılabilir ziyaret edilmemiş düğüm seçildi.",
          visual(u),
          "compare",
        );
        visited.push(u);
        metrics.visits++;
        emit(
          4,
          { node: u, distances: distances() },
          "En kısa uzaklık kesinleştirildi.",
          visual(u),
          "visit",
        );
        for (const [v, w] of adj.get(u)) {
          if (visited.includes(v)) continue;
          const candidate = dist.get(u) + w;
          metrics.comparisons++;
          emit(
            6,
            {
              from: u,
              to: v,
              weight: w,
              newDistance: candidate,
              oldDistance: Number.isFinite(dist.get(v)) ? dist.get(v) : "∞",
            },
            "Kenar gevşetme karşılaştırması.",
            visual(u),
            "compare",
          );
          if (candidate < dist.get(v)) {
            dist.set(v, candidate);
            previous.set(v, u);
            metrics.writes++;
            emit(
              7,
              {
                distances: distances(),
                predecessor: Object.fromEntries(previous),
              },
              "Daha kısa yol bulundu.",
              visual(v),
              "write",
            );
          }
        }
      }
      emit(
        8,
        { distances: distances(), predecessor: Object.fromEntries(previous) },
        "Ulaşılamayan düğümler ∞ olarak kalır.",
        visual(),
        "done",
        JSON.stringify(distances()),
      );
    } else {
      const frontier = [start];
      emit(
        1,
        { frontier, visited },
        "Başlangıç keşfedildi ve yapıya eklendi.",
        visual(null, frontier),
        "push",
      );
      while (frontier.length) {
        const u = kind === "bfs" ? frontier.shift() : frontier.pop();
        visited.push(u);
        metrics.visits++;
        emit(
          3,
          { node: u, frontier, visited },
          "Düğüm " +
            (kind === "bfs" ? "kuyruktan" : "yığından") +
            " alındı ve ziyaret edildi.",
          visual(u, frontier),
          "visit",
        );
        const neighbours =
          kind === "dfs" ? [...adj.get(u)].reverse() : adj.get(u);
        for (const [v] of neighbours) {
          metrics.comparisons++;
          emit(
            4,
            { node: u, neighbour: v, discovered: [...discovered] },
            "Komşunun daha önce keşfedilip keşfedilmediği kontrol edildi.",
            visual(u, frontier),
            "compare",
          );
          if (!discovered.has(v)) {
            discovered.add(v);
            frontier.push(v);
            metrics.writes++;
            emit(
              5,
              { node: u, neighbour: v, frontier },
              "Yeni komşu yapıya eklendi.",
              visual(v, frontier),
              "push",
            );
          }
        }
      }
      emit(
        6,
        { visited },
        "Başlangıçtan erişilebilen tüm düğümler dolaşıldı.",
        visual(),
        "done",
        visited.join(" → "),
      );
    }
  }
  return {
    kind,
    input,
    parameter,
    code: meta.code,
    steps,
    metrics: structuredClone(metrics),
    signature: hashInput(kind + "|" + input + "|" + parameter),
  };
}
export function predictionQuestion(trace, index) {
  const next = trace.steps[index + 1];
  if (!next) return null;
  const keys = Object.keys(operations),
    wrong = keys.filter((x) => x !== next.operation);
  const choices = [
    next.operation,
    wrong[index % wrong.length],
    wrong[(index + 3) % wrong.length],
  ];
  const offset = index % 3,
    ordered = choices.slice(offset).concat(choices.slice(0, offset));
  return {
    id: "predict:" + trace.kind + ":" + trace.signature + ":" + index,
    type: "choice",
    text:
      algorithms[trace.kind].name +
      " — " +
      (index + 1) +
      ". adımdan sonra hangi temel işlem gelir?",
    options: ordered.map((x) => operations[x]),
    answer: ordered.indexOf(next.operation),
    explain: next.explain,
    tag: algorithms[trace.kind].name,
  };
}
export function recordPrediction(state, trace, index, answer) {
  const q = predictionQuestion(trace, index);
  if (
    !q ||
    !Number.isInteger(answer) ||
    answer < 0 ||
    answer >= q.options.length
  )
    throw Error("Geçerli bir tahmin seç.");
  const existing = state.learning.algorithms.answers.find((x) => x.id === q.id);
  if (existing)
    return { correct: existing.correct, duplicate: true, question: q };
  const correct = answer === q.answer;
  state.learning.algorithms.answers.push({
    id: q.id,
    kind: trace.kind,
    step: index,
    correct,
    date: localDay(),
  });
  state.learning.algorithms.answers =
    state.learning.algorithms.answers.slice(-5000);
  recordEvidence(state, {
    id: q.id,
    topic: "algo:" + trace.kind,
    correct,
    source: "algorithm",
    weight: correct ? 1 : 0.5,
    question: q,
  });
  return { correct, duplicate: false, question: q };
}
export const challenges = [
  {
    id: "sort-count",
    topic: "algo:merge",
    text: "[4, 3, 2, 1] için bu simülatörde en az değer karşılaştırmasını hangi sıralama yapar?",
    options: ["Bubble Sort", "Selection Sort", "Merge Sort", "Quick Sort"],
    answer: 2,
    explain:
      "Bu uygulamada Merge Sort 4; diğer üçü 6 değer karşılaştırması yapar. Bu küçük veri kümesine ait sonuçtur.",
  },
  {
    id: "binary-mid",
    topic: "algo:binary",
    text: "[1, 3, 5, 7, 9], low=0, high=4. Binary Search ilk hangi indise bakar?",
    options: ["0", "2", "4"],
    answer: 1,
    explain: "floor((0+4)/2) = 2; bu indisteki değer 5'tir.",
  },
  {
    id: "loop-count",
    topic: "algo:linear",
    text: "for x in [2, 4, 6, 8]: gövdesi kaç kez çalışır?",
    options: ["3", "4", "8"],
    answer: 1,
    explain: "Dört eleman için gövde dört kez çalışır.",
  },
  {
    id: "fix-search",
    topic: "algo:binary",
    text: "Hedef orta değerden büyükken low = mid sonsuz döngü oluşturabilir. Doğru güncelleme nedir?",
    options: ["low = mid + 1", "high = mid + 1", "low = 0"],
    answer: 0,
    explain: "Orta eleman elenir; yeni aralık mid + 1'den başlar.",
  },
  {
    id: "function-return",
    topic: "algo:linear",
    text: "def iki_kati(x): return x * 2 — iki_kati(7) ne döndürür?",
    options: ["7", "9", "14"],
    answer: 2,
    explain: "7 × 2 = 14; return değeri çağırana aktarır.",
  },
];
export function answerChallenge(state, id, answer) {
  const c = challenges.find((x) => x.id === id);
  if (
    !c ||
    !Number.isInteger(answer) ||
    answer < 0 ||
    answer >= c.options.length
  )
    throw Error("Görev cevabı geçersiz.");
  const correct = answer === c.answer;
  if (state.learning.algorithms.challenges.some((x) => x.challenge === id))
    return { correct, explain: c.explain, already: true };
  recordEvidence(state, {
    id: "challenge-attempt:" + crypto.randomUUID(),
    topic: c.topic,
    source: "algorithm-challenge",
    correct,
    weight: 0.25,
    question: { ...c, id: "challenge:" + c.id, type: "choice", tag: c.topic },
  });
  if (
    correct &&
    !state.learning.algorithms.challenges.some((x) => x.challenge === id)
  )
    state.learning.algorithms.challenges.push({
      id: crypto.randomUUID(),
      challenge: id,
      date: localDay(),
    });
  return { correct, explain: c.explain };
}
