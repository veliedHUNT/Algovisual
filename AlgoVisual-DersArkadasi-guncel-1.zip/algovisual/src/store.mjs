import { initialState, validateState, migrateLegacy } from "./core.mjs";
import { upgradeLearning } from "./learning-state.mjs";
let database;
export async function openStore() {
  database = await new Promise((resolve, reject) => {
    const r = indexedDB.open("algovisual-v3", 1);
    r.onupgradeneeded = () => {
      r.result.createObjectStore("state");
      r.result.createObjectStore("blobs");
    };
    r.onsuccess = () => resolve(r.result);
    r.onerror = () =>
      reject(
        Error(
          "Yerel veritabanı açılamadı. Özel mod veya depolama izinlerini kontrol et.",
        ),
      );
  });
  let state = await get("state", "main");
  if (!state) {
    const old = localStorage.getItem("algovisual-dersarkadasi-v1");
    state = old ? migrateLegacy(JSON.parse(old)) : initialState();
    state.settings.theme =
      localStorage.getItem("av-theme") === "light" ? "light" : "dark";
    for (const lang of ["python", "c"]) {
      try {
        const draft = JSON.parse(
          localStorage.getItem("av-code-draft-" + lang) || "null",
        );
        if (draft)
          state.files.push({
            id: crypto.randomUUID(),
            name: draft.filename || "main." + (lang === "c" ? "c" : "py"),
            lang,
            code: String(draft.code || "").slice(0, 100000),
          });
      } catch {}
    }
    await writeState(state, 0);
  }
  validateState(state);
  if (upgradeLearning(state)) await writeState(state, state.rev);
  return validateState(state);
}
function get(store, key) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction(store, "readonly"),
      r = tx.objectStore(store).get(key);
    r.onsuccess = () => resolve(r.result);
    r.onerror = () => reject(r.error);
  });
}
export function writeState(next, expectedRev) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction("state", "readwrite"),
      store = tx.objectStore("state"),
      r = store.get("main");
    let conflict = false;
    r.onsuccess = () => {
      if (r.result && r.result.rev !== expectedRev) {
        conflict = true;
        tx.abort();
        return;
      }
      next.rev = expectedRev + 1;
      next.updatedAt = Date.now();
      store.put(structuredClone(next), "main");
    };
    tx.oncomplete = () => resolve();
    tx.onabort = tx.onerror = () =>
      reject(
        Error(
          conflict
            ? "Başka bir sekme veriyi güncelledi. Değişikliğini kopyalayıp sayfayı yenile; kayıt üzerine yazılmadı."
            : "Kayıt tamamlanamadı. Depolama alanını kontrol et ve yedeğini indir.",
        ),
      );
  });
}
export function saveBlob(id, blob) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction("blobs", "readwrite");
    tx.objectStore("blobs").put(blob, id);
    tx.oncomplete = resolve;
    tx.onerror = () =>
      reject(Error("PDF saklanamadı; cihaz depolama alanını kontrol et."));
  });
}
export const getBlob = (id) => get("blobs", id);
export function removeBlob(id) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction("blobs", "readwrite");
    tx.objectStore("blobs").delete(id);
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}
export function clearBlobs() {
  return new Promise((resolve, reject) => {
    const tx = database.transaction("blobs", "readwrite");
    tx.objectStore("blobs").clear();
    tx.oncomplete = resolve;
    tx.onerror = () => reject(tx.error);
  });
}
