import { newLearning, validateLearning, validDay } from "./learning-state.mjs";
import { newExamCoach, validateExamCoach } from './exam-state.mjs';
export const uid = () => globalThis.crypto.randomUUID();
export const day = (date = new Date()) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
export function addDays(date, count) {
  const d = new Date(date + "T12:00:00");
  d.setDate(d.getDate() + count);
  return day(d);
}
export const normalize = (value) =>
  String(value ?? "")
    .normalize("NFKC")
    .trim()
    .toLocaleLowerCase("tr-TR")
    .replace(/\s+/g, " ");
export const esc = (value) =>
  String(value ?? "").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
export function initialState() {
  return {
    schema: 3,
    rev: 0,
    updatedAt: 0,
    lessons: [],
    tests: [],
    attempts: [],
    review: [],
    sessions: [],
    notes: [],
    documents: [],
    files: [],
    favorites: [],
    recent: [],
    completed: [],
    exercises: [],
    activeAttempt: null,
    chat: [],
    settings: {
      theme: "dark",
      dailyMinutes: 30,
      weeklyPlan: ["", "", "", "", "", "", ""],
      saveChat: false,
    },
    timer: null,
    learning: newLearning(),
    examCoach: newExamCoach(),
  };
}
const string = (v, n = 20000) => typeof v === "string" && v.length <= n;
const safeId = (v) => string(v, 100) && /^[\w:.-]+$/.test(v);
export function validateQuestion(q) {
  if (
    q?.source &&
    (!Number.isInteger(q.source.page) ||
      q.source.page < 1 ||
      q.source.page > 200 ||
      !string(q.source.text, 10000))
  )
    return false;
  if (q?.tag !== undefined && !string(q.tag, 200)) return false;
  if (
    !q ||
    !safeId(q.id) ||
    !string(q.text, 3000) ||
    !q.text.trim() ||
    !["choice", "boolean", "short"].includes(q.type) ||
    !string(q.explain ?? "", 5000)
  )
    return false;
  if (q.type === "choice")
    return (
      Array.isArray(q.options) &&
      q.options.length >= 2 &&
      q.options.length <= 6 &&
      q.options.every((x) => string(x, 1000) && x.trim()) &&
      Number.isInteger(q.answer) &&
      q.answer >= 0 &&
      q.answer < q.options.length
    );
  if (q.type === "boolean") return typeof q.answer === "boolean";
  return (
    Array.isArray(q.answers) &&
    q.answers.length > 0 &&
    q.answers.length <= 20 &&
    q.answers.every((x) => string(x, 300) && x.trim())
  );
}
export function validateTest(t) {
  return (
    t &&
    safeId(t.id) &&
    string(t.title, 200) &&
    t.title.trim() &&
    string(t.subject ?? "", 100) &&
    Array.isArray(t.questions) &&
    t.questions.length > 0 &&
    t.questions.length <= 100 &&
    t.questions.every(validateQuestion) &&
    new Set(t.questions.map((q) => q.id)).size === t.questions.length &&
    (!t.minutes ||
      (Number.isFinite(t.minutes) && t.minutes > 0 && t.minutes <= 240))
  );
}
export function validateState(s) {
  if (!s || s.schema !== 3 || !Number.isInteger(s.rev) || s.rev < 0)
    throw Error("Yedek biçimi veya sürümü desteklenmiyor.");
  for (const key of [
    "lessons",
    "tests",
    "attempts",
    "review",
    "sessions",
    "notes",
    "documents",
    "files",
    "favorites",
    "recent",
    "completed",
    "exercises",
    "chat",
  ])
    if (!Array.isArray(s[key]) || s[key].length > 10000)
      throw Error("Geçersiz veri alanı: " + key);
  if (!s.tests.every(validateTest))
    throw Error("Yedekte geçersiz test veya cevap anahtarı var.");
  for (const key of [
    "lessons",
    "tests",
    "documents",
    "files",
    "notes",
    "review",
    "attempts",
    "sessions",
  ])
    if (
      new Set(s[key].map((x) => x.id)).size !== s[key].length ||
      s[key].some((x) => !x || !safeId(x.id))
    )
      throw Error("Geçersiz veya yinelenen kimlik: " + key);
  if (
    !s.lessons.every(
      (l) =>
        string(l.title, 200) &&
        string(l.body, 30000) &&
        string(l.subject, 100) &&
        string(l.area, 30) &&
        string(l.grade, 30) &&
        string(l.unit, 100) &&
        Array.isArray(l.quiz) &&
        l.quiz.every(validateQuestion),
    )
  )
    throw Error("Ders içerikleri geçersiz.");
  if (!s.notes.every((n) => string(n.text, 20000) && string(n.target, 150)))
    throw Error("Not biçimi geçersiz.");
  if (
    !s.files.every(
      (f) =>
        string(f.name, 100) &&
        string(f.code, 100000) &&
        ["python", "c"].includes(f.lang),
    )
  )
    throw Error("Kod dosyaları geçersiz.");
  if (
    !s.documents.every(
      (d) =>
        string(d.name, 200) &&
        Array.isArray(d.pages) &&
        d.pages.length <= 200 &&
        d.pages.every((p) => string(p, 100000)) &&
        d.pages.join("").length <= 1500000 &&
        Array.isArray(d.bookmarks) &&
        d.bookmarks.every(
          (n) => Number.isInteger(n) && n >= 1 && n <= d.pages.length,
        ),
    )
  )
    throw Error("Belge verileri geçersiz.");
  if (
    !s.attempts.every(
      (a) =>
        string(a.title, 200) &&
        Number.isFinite(a.correct) &&
        Number.isFinite(a.total) &&
        a.total > 0 &&
        a.correct >= 0 &&
        a.correct <= a.total &&
        Number.isFinite(new Date(a.date).getTime()) &&
        Array.isArray(a.results ?? []) &&
        (a.results ?? []).every(
          (r) => validateQuestion(r.question) && typeof r.correct === "boolean",
        ),
    )
  )
    throw Error("Test sonuçları geçersiz.");
  if (
    !s.review.every(
      (r) =>
        validateQuestion(r.question) &&
        validDay(r.due) &&
        Number.isFinite(r.interval) &&
        r.interval >= 0,
    )
  )
    throw Error("Tekrar verisi geçersiz.");
  if (
    s.review.some(
      (r) =>
        (r.topic !== undefined &&
          !(string(r.topic, 200) && /^[\w:.-]+$/.test(r.topic))) ||
        (r.srs &&
          (r.srs.version !== 1 ||
            !Number.isFinite(r.srs.ease) ||
            r.srs.ease < 1.3 ||
            r.srs.ease > 3.2 ||
            !["streak", "lapses", "successes", "failures"].every(
              (k) =>
                Number.isInteger(r.srs[k]) &&
                r.srs[k] >= 0 &&
                r.srs[k] <= 1000000,
            ) ||
            !(r.srs.last === null || validDay(r.srs.last)) ||
            !(
              r.srs.againAt === null ||
              (Number.isSafeInteger(r.srs.againAt) && r.srs.againAt >= 0)
            ))),
    )
  )
    throw Error("Tekrar algoritması verisi geçersiz.");
  if (
    !s.sessions.every(
      (x) =>
        string(x.date, 10) &&
        Number.isFinite(x.seconds) &&
        x.seconds >= 0 &&
        x.seconds <= 86400,
    )
  )
    throw Error("Çalışma oturumu geçersiz.");
  for (const key of ["favorites", "recent", "completed", "exercises"])
    if (
      !s[key].every((x) => safeId(x)) ||
      new Set(s[key]).size !== s[key].length
    )
      throw Error("Geçersiz ilerleme verisi.");
  if (
    !s.chat.every(
      (x) => ["user", "assistant"].includes(x.role) && string(x.content, 20000),
    )
  )
    throw Error("Sohbet verisi geçersiz.");
  if (
    !s.settings ||
    !["dark", "light"].includes(s.settings.theme) ||
    !Number.isFinite(s.settings.dailyMinutes) ||
    s.settings.dailyMinutes < 5 ||
    s.settings.dailyMinutes > 480 ||
    !Array.isArray(s.settings.weeklyPlan) ||
    s.settings.weeklyPlan.length !== 7 ||
    !s.settings.weeklyPlan.every((x) => string(x, 200))
  )
    throw Error("Ayarlar geçersiz.");
  if (s.activeAttempt) {
    const a = s.activeAttempt;
    if (
      !validateTest(a.test) ||
      !Array.isArray(a.answers) ||
      a.answers.length > a.test.questions.length ||
      !Number.isInteger(a.index) ||
      a.index < 0 ||
      a.index >= a.test.questions.length ||
      !Number.isFinite(a.startedAt) ||
      (a.deadline !== null && !Number.isFinite(a.deadline))
    )
      throw Error("Yarım kalan test geçersiz.");
  }
  if (
    s.timer &&
    (!Number.isFinite(s.timer.startedAt) ||
      !Number.isFinite(s.timer.duration) ||
      s.timer.duration < 60 ||
      s.timer.duration > 14400)
  )
    throw Error("Zamanlayıcı verisi geçersiz.");
  validateLearning(s.learning);
  validateExamCoach(s.examCoach, validateQuestion);
  return s;
}
export function migrateLegacy(old) {
  if (!old || !Array.isArray(old.tests) || !Array.isArray(old.lessons))
    throw Error("Bu dosya geçerli bir AlgoVisual yedeği değil.");
  const s = initialState();
  for (const t of old.tests ?? []) {
    const test = {
      id: uid(),
      title: String(t.title || "Eski test").slice(0, 200),
      subject: String(t.subject || "Genel").slice(0, 100),
      questions: (t.questions ?? []).map((q) => ({
        id: uid(),
        type: "choice",
        text: q.text,
        options: q.options,
        answer: "ABCD".indexOf(q.correct),
        explain: q.explain || "",
        difficulty: "Başlangıç",
        tag: t.subject || "Genel",
      })),
      minutes: 0,
    };
    if (validateTest(test)) s.tests.push(test);
  }
  for (const a of old.attempts ?? [])
    if (
      Number.isFinite(a.correct) &&
      Number.isFinite(a.total) &&
      a.total > 0 &&
      a.correct >= 0 &&
      a.correct <= a.total &&
      Number.isFinite(new Date(a.date).getTime())
    )
      s.attempts.push({
        id: uid(),
        title: String(a.title || "Eski test").slice(0, 200),
        correct: a.correct,
        total: a.total,
        date: new Date(a.date).toISOString(),
        results: [],
        seconds: 0,
        legacy: true,
      });
  for (const r of old.review ?? [])
    if (string(r.question) && string(r.answer) && r.answer.trim())
      s.review.push({
        id: uid(),
        question: {
          id: uid(),
          type: "short",
          text: r.question,
          answers: [r.answer],
          explain: r.explain || "",
          tag: "Eski sürüm",
        },
        due: /^\d{4}-\d{2}-\d{2}$/.test(r.due) ? r.due : day(),
        interval: Math.max(0, Number(r.interval) || 0),
      });
  for (const l of old.lessons ?? [])
    if (l.title) {
      const id = uid();
      s.lessons.push({
        id,
        title: String(l.title).slice(0, 200),
        area:
          l.subject === "Yazılım"
            ? "software"
            : l.subject === "Siber güvenlik"
              ? "cyber"
              : "school",
        subject: String(l.subject || "Genel"),
        grade: String(l.level || "Başlangıç"),
        unit: "Eski sürüm",
        body: String(l.desc || "Aktarılan ders kaydı."),
        goal: "İçeriği tamamla.",
        example: "",
        exercise: "",
        quiz: [],
        prerequisites: [],
        status: "Eski sürümden aktarıldı",
      });
      if (l.done) s.completed.push(id);
    }
  return validateState(s);
}
export function answerText(q) {
  return q.type === "choice"
    ? q.options[q.answer]
    : q.type === "boolean"
      ? q.answer
        ? "Doğru"
        : "Yanlış"
      : q.answers.join(" / ");
}
export function gradeAnswer(q, answer) {
  if (answer === null || answer === undefined || answer === "") return false;
  if (q.type === "short")
    return q.answers.some((x) => normalize(x) === normalize(answer));
  return answer === q.answer;
}
export function shuffle(items, random = Math.random) {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
export function startAttempt(test, randomize = false, now = Date.now()) {
  return {
    id: uid(),
    test: {
      ...structuredClone(test),
      questions: randomize
        ? shuffle(structuredClone(test.questions))
        : structuredClone(test.questions),
    },
    index: 0,
    answers: [],
    startedAt: now,
    deadline: test.minutes ? now + test.minutes * 60000 : null,
  };
}
export function finalizeAttempt(a, now = Date.now()) {
  const results = a.test.questions.map((question, i) => ({
    question,
    answer: a.answers[i] ?? null,
    correct: gradeAnswer(question, a.answers[i]),
  }));
  return {
    id: a.id,
    title: a.test.title,
    lessonId: a.test.lessonId || null,
    date: new Date(now).toISOString(),
    results,
    correct: results.filter((x) => x.correct).length,
    total: results.length,
    seconds: Math.max(0, Math.round((now - a.startedAt) / 1000)),
  };
}
export function reschedule(item, remembered, date = day()) {
  const interval = remembered
    ? Math.min(180, item.interval ? Math.round(item.interval * 2.2) : 1)
    : 0;
  return {
    ...item,
    interval,
    due: addDays(date, interval),
    repetitions: (item.repetitions || 0) + 1,
  };
}
export function stats(s) {
  const total = s.attempts.reduce((n, a) => n + a.total, 0),
    correct = s.attempts.reduce((n, a) => n + a.correct, 0);
  const topics = Object.create(null);
  for (const a of s.attempts)
    for (const r of a.results || []) {
      const tag = r.question.tag || "Genel";
      topics[tag] ??= { total: 0, correct: 0 };
      topics[tag].total++;
      topics[tag].correct += Number(r.correct);
    }
  return {
    total,
    correct,
    rate: total ? Math.round((correct / total) * 100) : null,
    topics,
    seconds: s.sessions.reduce((n, x) => n + x.seconds, 0),
  };
}
export function documentTools(pages) {
  const sentences = pages
    .flatMap((text, i) =>
      (text.match(/[^.!?\n]+[.!?]?/g) || []).map((text) => ({
        text: text.trim(),
        page: i + 1,
      })),
    )
    .filter((s) => s.text.length >= 35 && s.text.length <= 400);
  const questions = sentences
    .slice(0, 12)
    .map((s) => {
      const word = (s.text.match(/[\p{L}]{5,}/gu) || []).sort(
        (a, b) => b.length - a.length,
      )[0];
      if (!word) return null;
      return {
        id: uid(),
        type: "short",
        text:
          s.text.replace(word, "_____") +
          "\nBoşluğu kaynak metindeki sözcükle doldur.",
        answers: [word],
        explain: s.text,
        source: { page: s.page, text: s.text },
        tag: "Belge",
        difficulty: "Başlangıç",
      };
    })
    .filter(Boolean);
  const frequency = Object.create(null);
  for (const text of pages)
    for (const word of text.match(/[\p{L}]{5,}/gu) || []) {
      const w = normalize(word);
      if (
        ![
          "olarak",
          "bunun",
          "ancak",
          "kadar",
          "sonra",
          "içinde",
          "birlikte",
          "üzerine",
        ].includes(w)
      )
        frequency[w] = (frequency[w] || 0) + 1;
    }
  return {
    questions,
    summary: sentences.slice(0, 5),
    concepts: Object.entries(frequency)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 15),
  };
}
export function syntaxCheck(code, lang) {
  const issues = [],
    stack = [];
  let quote = null,
    block = false,
    lineComment = false,
    escaped = false,
    line = 1;
  for (let i = 0; i < code.length; i++) {
    const c = code[i],
      n = code[i + 1];
    if (c === "\n") {
      if (quote && quote !== "triple" && !escaped) {
        issues.push({ line, message: "Kapatılmamış metin tırnağı." });
        quote = null;
      }
      line++;
      lineComment = false;
    }
    if (lineComment) continue;
    if (block) {
      if (c === "*" && n === "/") {
        block = false;
        i++;
      }
      continue;
    }
    if (quote) {
      if (quote === "triple") {
        if (code.slice(i, i + 3) === '"""' || code.slice(i, i + 3) === "'''") {
          quote = null;
          i += 2;
        }
        continue;
      }
      if (!escaped && c === quote) quote = null;
      escaped = !escaped && c === "\\";
      continue;
    }
    if (
      (lang === "python" && c === "#") ||
      (lang === "c" && c === "/" && n === "/")
    ) {
      lineComment = true;
      continue;
    }
    if (lang === "c" && c === "/" && n === "*") {
      block = true;
      i++;
      continue;
    }
    if (
      lang === "python" &&
      (code.slice(i, i + 3) === '"""' || code.slice(i, i + 3) === "'''")
    ) {
      quote = "triple";
      i += 2;
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      continue;
    }
    if ("([{".includes(c)) stack.push({ c, line });
    if (")]}".includes(c)) {
      const p = stack.pop();
      if (!p || "([{".indexOf(p.c) !== ")]}".indexOf(c))
        issues.push({ line, message: "Eşleşmeyen parantez: " + c });
    }
  }
  if (quote || block)
    issues.push({ line, message: "Kapatılmamış metin veya yorum." });
  for (const p of stack)
    issues.push({ line: p.line, message: "Kapatılmamış parantez: " + p.c });
  if (lang === "python")
    code.split("\n").forEach((s, i) => {
      if (
        /^\s*(if |elif |else\s*$|for |while |def |class |try\s*$|except |finally\s*$)/.test(
          s,
        ) &&
        !s.split("#")[0].trimEnd().endsWith(":")
      )
        issues.push({
          line: i + 1,
          message: "Blok başlığının sonunda : bekleniyor.",
        });
    });
  return issues;
}
