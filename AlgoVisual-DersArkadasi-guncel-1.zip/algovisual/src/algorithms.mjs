export const algorithmNames = {
  loop: "Döngü ve liste toplamı",
  condition: "Koşul ve karşılaştırma",
  variables: "Değişkenler ve aritmetik",
  function: "Fonksiyon çağrısı",
};
export function buildTrace(kind, input) {
  const steps = [];
  const emit = (line, vars, explain, output = "") =>
    steps.push({ line, vars: structuredClone(vars), explain, output });
  let code;
  if (kind === "loop") {
    const values =
      String(input).trim() === ""
        ? []
        : String(input)
            .split(",")
            .map((x) => Number(x.trim()));
    if (
      values.length > 12 ||
      values.some((x) => !Number.isFinite(x) || Math.abs(x) > 1000000)
    )
      throw Error("En fazla 12 sayı gir; sayıları virgülle ayır.");
    code = [
      "sayilar = " + JSON.stringify(values),
      "toplam = 0",
      "for sayi in sayilar:",
      "    toplam = toplam + sayi",
      "print(toplam)",
    ];
    const v = { sayilar: values };
    emit(1, v, "Liste oluşturuldu.");
    v.toplam = 0;
    emit(2, v, "Toplam 0 ile başlar.");
    for (const n of values) {
      v.sayi = n;
      emit(3, v, "Sıradaki eleman: " + n);
      const before = v.toplam;
      v.toplam += n;
      emit(4, v, `${before} + ${n} = ${v.toplam}`);
    }
    emit(
      5,
      v,
      values.length
        ? "Tüm elemanlar toplandı."
        : "Boş listede döngü gövdesi çalışmaz; toplam 0 kalır.",
      String(v.toplam),
    );
  } else if (kind === "condition") {
    const n = Number(input);
    if (!Number.isFinite(n) || n < 0 || n > 130)
      throw Error("0–130 arasında bir yaş gir.");
    code = [
      "yas = " + n,
      "if yas >= 18:",
      '    print("Reşit")',
      "else:",
      '    print("Reşit değil")',
    ];
    emit(1, { yas: n }, "Yaş değişkenine değer atandı.");
    emit(
      2,
      { yas: n, kosul: n >= 18 },
      `${n} >= 18 karşılaştırması ${n >= 18 ? "doğru" : "yanlış"}.`,
    );
    emit(
      n >= 18 ? 3 : 5,
      { yas: n },
      "Koşula uygun dal çalışır.",
      n >= 18 ? "Reşit" : "Reşit değil",
    );
  } else if (kind === "variables") {
    const n = Number(input);
    if (!Number.isFinite(n) || Math.abs(n) > 1000000)
      throw Error("Geçerli bir sayı gir.");
    code = ["x = " + n, "y = x * 2", "x = x + 1", "print(x, y)"];
    emit(1, { x: n }, "x değeri saklandı.");
    emit(2, { x: n, y: n * 2 }, "y, x’in o anki değerinin iki katını alır.");
    emit(3, { x: n + 1, y: n * 2 }, "x değişince y kendiliğinden değişmez.");
    emit(
      4,
      { x: n + 1, y: n * 2 },
      "İki değişken yazdırılır.",
      `${n + 1} ${n * 2}`,
    );
  } else if (kind === "function") {
    const n = Number(input);
    if (!Number.isFinite(n) || Math.abs(n) > 1000000)
      throw Error("Geçerli bir sayı gir.");
    code = [
      "def iki_kati(sayi):",
      "    return sayi * 2",
      "sonuc = iki_kati(" + n + ")",
      "print(sonuc)",
    ];
    emit(1, {}, "Fonksiyon tanımlandı; gövdesi henüz çalışmadı.");
    emit(3, {}, "Fonksiyon çağrısı başlar.");
    emit(1, { "yerel sayi": n }, "Argüman yerel sayi parametresine bağlanır.");
    emit(
      2,
      { "yerel sayi": n, "dönen değer": n * 2 },
      "return sonucu çağırana gönderir.",
    );
    emit(3, { sonuc: n * 2 }, "Sonuç değişkenine dönen değer atanır.");
    emit(4, { sonuc: n * 2 }, "Sonuç yazdırılır.", String(n * 2));
  } else throw Error("Desteklenmeyen simülasyon.");
  return { code, steps };
}
