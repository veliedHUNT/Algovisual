import { getConfig, profileTopics, totalQuestions, examConfigs, comparisonSignature } from './exam-config.mjs';
import { validateProfile, topicProgress, newExamCoach } from './exam-state.mjs';
import { starterQuestions } from './exam-bank.mjs';
import { validateQuestion, gradeAnswer, answerText, normalize } from './core.mjs';
import { localDay, validDay, shiftDay, daysBetween, recordEvidence, mastery } from './learning-state.mjs';
import { rebuildPlan, configureStudyTime } from './planner.mjs';
import { rateCard, isDue } from './review-engine.mjs';
const uid=()=>crypto.randomUUID();
export const studentAnswerText=(q,a)=>a===null||a===undefined||a===''?'Boş':q.type==='choice'?(q.options[a]??String(a)):q.type==='boolean'?(a?'Doğru':'Yanlış'):String(a);
export function getProfile(state,id=state.examCoach.activeProfileId){const p=state.examCoach.profiles.find(p=>p.id===id);if(!p)throw Error('Önce bir sınav profili oluştur.');return p;}
export function saveProfile(state,input,id=null){
  const old=state.examCoach.profiles.find(p=>p.id===id);
  if(old&&(old.exam!==input.exam||old.field!==input.field||old.language!==input.language))throw Error('Sınav, alan ve dil geçmişi korumak için değiştirilemez; yeni profil oluştur.');
  const p=validateProfile({...input,id:old?.id||uid(),configVersion:examConfigs[input.exam]?.version,enabled:input.enabled!==false});
  if(!old&&state.examCoach.profiles.length>=12)throw Error('En fazla 12 profil tutulabilir.');
  // All profiles share one time budget, rather than multiplying available minutes.
  configureStudyTime(state,p.dailyMinutes,Array.from({length:7},(_,i)=>p.workDays.includes(i)?null:0));
  if(old)Object.assign(old,p);else state.examCoach.profiles.push(p);
  state.examCoach.activeProfileId=p.id;
  rebuildPlan(state);
  return p;
}
export function setTopicStatus(state,profileId,key,status,date=localDay()){
  const p=getProfile(state,profileId);
  if(!profileTopics(p).some(t=>t.key===key)||!['new','studying','done','review','weak'].includes(status))throw Error('Geçersiz konu durumu.');
  let row=topicProgress(state,key);
  if(!row){row={key,status,updated:date,lastStudy:null};state.examCoach.progress.push(row);}
  row.status=status;row.updated=date;
  if(['studying','done'].includes(status))row.lastStudy=date;
  return row;
}
function decorate(q,p,t){
  return {...structuredClone(q),id:'ec:'+p.id+':'+q.id,profileId:p.id,subjectId:t.subject,topicId:t.id,topicKey:t.key,tag:t.subjectLabel+' — '+t.label,difficulty:q.difficulty||['Başlangıç','Orta','İleri'][(q.level||2)-1],level:q.level||2};
}
export function questionBank(state,profileId){
  const p=getProfile(state,profileId), topics=profileTopics(p), questions=[];
  for(const t of topics){
    for(const q of starterQuestions.filter(q=>q.exams.includes(p.exam)&&q.subjectId===t.subject&&q.topicId===t.id&&(!q.language||q.language===(p.exam==='YDT'?p.language:'en'))))questions.push(decorate(q,p,t));
    for(const l of state.lessons.filter(l=>t.lessons.includes(l.id)))for(const q of l.quiz.filter(validateQuestion))questions.push(decorate(q,p,t));
  }
  questions.push(...state.examCoach.bank.filter(q=>q.profileId===p.id));
  for(const test of state.tests)for(const q of test.questions){
    if(!validateQuestion(q)||!q.examMapping)continue;
    const m=q.examMapping;
    if(m.exam!==p.exam||(p.exam==='YDT'&&m.language!==p.language))continue;
    const t=topics.find(t=>t.subject===m.subject&&t.id===m.topic);
    if(t)questions.push(decorate(q,p,t));
  }
  return [...new Map(questions.map(q=>[q.id,q])).values()];
}
export function importQuestions(state,profileId,rows){
  const p=getProfile(state,profileId),topics=profileTopics(p);
  if(!Array.isArray(rows)||!rows.length||rows.length>300||state.examCoach.bank.length+rows.length>2000)throw Error('Bir seferde 1–300, toplam en fazla 2000 özel soru eklenebilir.');
  const added=rows.map(row=>{
    const topic=topics.find(t=>t.subject===row.subjectId&&t.id===row.topicId);
    if(!topic||!validateQuestion({...row,id:'preview'})||!row.explain?.trim()||![1,2,3].includes(row.level))throw Error('Her soruda geçerli ders/konu, tür, cevap anahtarı, açıklama ve 1–3 zorluk gerekli.');
    const q={id:uid(),type:row.type,text:row.text,explain:row.explain,level:row.level};
    if(row.type==='choice'){q.options=[...row.options];q.answer=row.answer;}else if(row.type==='boolean')q.answer=row.answer;else q.answers=[...row.answers];
    return decorate(q,p,topic);
  });
  const existing=new Set(questionBank(state,p.id).map(q=>normalize(q.text)));
  if(added.some(q=>{const duplicate=existing.has(normalize(q.text));existing.add(normalize(q.text));return duplicate;}))throw Error('Aynı soru metni bankada zaten var veya dosyada yineleniyor.');
  state.examCoach.bank.push(...added);return added.length;
}
export function mockBlueprint(state,profileId,options={}){
  const p=getProfile(state,profileId),config=getConfig(p),kind=options.kind||'mini',bank=questionBank(state,p.id);
  if(!['full','subject','topic','weak','mini','custom'].includes(kind))throw Error('Deneme türü geçersiz.');
  let subjects=config.subjects;
  if(['subject','topic'].includes(kind)){subjects=subjects.filter(s=>s.id===options.subject);if(!subjects.length)throw Error('Ders seç.');}
  if(kind==='mini'||kind==='weak')subjects=subjects.filter(s=>p.subjects.includes(s.id));
  let pool=bank.filter(q=>subjects.some(s=>s.id===q.subjectId));
  if(kind==='topic'){if(!subjects[0].topics.some(t=>t.id===options.topic))throw Error('Konu seç.');pool=pool.filter(q=>q.topicId===options.topic);}
  if(kind==='weak')pool=pool.filter(q=>['weak','review'].includes(topicProgress(state,q.topicKey)?.status)||((mastery(state,q.topicKey).observations>=5)&&mastery(state,q.topicKey).score<60));
  const seen=new Set();pool=pool.filter(q=>{const key=normalize(q.text);if(seen.has(key))return false;seen.add(key);return true;});
  const full=kind==='full';
  const count=full?totalQuestions(config):kind==='subject'?subjects[0].count:Number(options.count??10);
  if(!Number.isInteger(count)||count<1||count>160)throw Error('Soru sayısı 1–160 olmalı.');
  const shortages=full||kind==='subject'?subjects.map(s=>({subject:s.label,available:pool.filter(q=>q.subjectId===s.id).length,needed:s.count})).filter(s=>s.available<s.needed):pool.length<count?[{subject:'Seçilen kapsam',available:pool.length,needed:count}]:[];
  const minutes=full?config.minutes:kind==='subject'?Math.ceil(config.minutes*count/totalQuestions(config)):Number(options.minutes??Math.ceil(config.minutes*count/totalQuestions(config)));
  if(!Number.isInteger(minutes)||minutes<1||minutes>240)throw Error('Süre 1–240 dakika olmalı.');
  return {p,config,kind,pool,count,minutes,shortages};
}
function shuffled(xs){const a=[...xs];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
export function startMock(state,profileId,options={},now=Date.now()){
  if(state.examCoach.sessions.length>=500)throw Error('500 oturum sınırına ulaşıldı. Yedeğini indirip eski profil verilerini silebilirsin.');
  if(state.examCoach.sessions.some(x=>x.profileId===profileId&&x.status!=='done'))throw Error('Bu profilde yarım kalan denemen var; önce devam et veya bitir.');
  const b=mockBlueprint(state,profileId,options);
  if(b.shortages.length)throw Error('Yeterli soru yok: '+b.shortages.map(x=>`${x.subject} ${x.available}/${x.needed}`).join(', ')+'. Küçük bir konu/mini deneme seç, kendi cevap anahtarlı sorularını ekle veya dış deneme sonucu gir.');
  let questions=b.kind==='full'||b.kind==='subject'?b.config.subjects.flatMap(s=>shuffled(b.pool.filter(q=>q.subjectId===s.id)).slice(0,s.count)):shuffled(b.pool).slice(0,b.count);
  const stages=b.kind==='full'&&b.p.exam==='LGS'?b.config.sections.map(s=>({...s,seconds:s.minutes*60,indices:questions.map((q,i)=>b.config.subjects.find(x=>x.id===q.subjectId).section===s.id?i:null).filter(i=>i!==null)})):[{id:'all',label:b.kind==='full'?b.p.exam:'Çalışma denemesi',seconds:b.minutes*60,indices:questions.map((_,i)=>i)}];
  const x={id:uid(),profileId,kind:b.kind,title:String(options.title||`${b.p.title} · ${({full:'Tam deneme',subject:'Ders denemesi',topic:'Konu denemesi',weak:'Eksik konular',mini:'Süreli mini deneme',custom:'Özel deneme'})[b.kind]}`).slice(0,200),questions:structuredClone(questions),answers:questions.map(()=>null),marked:[],index:0,stages,stageIndex:0,remainingMs:stages[0].seconds*1000,resumedAt:now,elapsedMs:0,status:'running',startedAt:now,updatedAt:now,configVersion:b.config.version,wrongDivisor:b.config.wrongDivisor};
  state.examCoach.sessions.push(x);return x;
}
export const remaining = (x,now=Date.now())=>Math.max(0,x.remainingMs-(x.resumedAt===null?0:Math.max(0,now-x.resumedAt)));
export function settleMock(x,now=Date.now()){
  if(x.status!=='running')return;
  const spent=Math.min(x.remainingMs,Math.max(0,now-x.resumedAt));
  x.remainingMs-=spent;x.elapsedMs+=spent;x.resumedAt=now;x.updatedAt=now;
}
export function currentSession(state,id){const x=state.examCoach.sessions.find(s=>s.id===id);if(!x)throw Error('Deneme bulunamadı.');return x;}
export function updateMockClock(state,id,now=Date.now()){
  const x=currentSession(state,id);if(x.status!=='running')return false;
  settleMock(x,now);if(x.remainingMs>0)return false;
  if(x.stageIndex<x.stages.length-1){x.stageIndex++;x.status='between';x.resumedAt=null;x.remainingMs=x.stages[x.stageIndex].seconds*1000;x.index=x.stages[x.stageIndex].indices[0];}
  else finishMock(state,id,now);
  return true;
}
export function pauseMock(state,id,now=Date.now()){
  const x=currentSession(state,id);updateMockClock(state,id,now);
  if(x.status==='running'){x.status='paused';x.resumedAt=null;}return x;
}
export function resumeMock(state,id,now=Date.now()){
  const x=currentSession(state,id);if(!['paused','between'].includes(x.status))throw Error('Deneme devam ettirilemiyor.');
  x.resumedAt=now;x.updatedAt=now;x.status='running';return x;
}
export function answerMock(state,id,index,answer,now=Date.now()){
  const x=currentSession(state,id);updateMockClock(state,id,now);
  if(x.status!=='running'||!x.stages[x.stageIndex].indices.includes(index))throw Error('Cevap vermek için geçerli oturumu devam ettir.');
  const q=x.questions[index];
  if(answer!==null&&(q.type==='choice'?(!Number.isInteger(answer)||answer<0||answer>=q.options.length):q.type==='boolean'?typeof answer!=='boolean':typeof answer!=='string'||answer.length>300))throw Error('Cevap geçersiz.');
  x.answers[index]=answer;x.updatedAt=now;
}
export function netCounts(correct,wrong,blank,divisor){
  if(![correct,wrong,blank].every(x=>Number.isInteger(x)&&x>=0)||![3,4].includes(divisor)||correct+wrong+blank>160)throw Error('Doğru, yanlış ve boş sayıları geçersiz.');
  return {correct,wrong,blank,total:correct+wrong+blank,net:correct-wrong/divisor};
}
export const resultSignature=comparisonSignature;
function addResult(state,p,result){
  if(state.examCoach.results.some(r=>r.id===result.id))return result;
  result.signature=resultSignature(p,result.kind,result.subjects,result.configVersion,result.wrongDivisor,result.topics);
  state.examCoach.results.push(result);
  for(const date of state.learning.plans.filter(p=>p.date>=localDay()).map(p=>p.date))rebuildPlan(state,date);
  return result;
}
export function finishMock(state,id,now=Date.now()){
  const x=currentSession(state,id),old=state.examCoach.results.find(r=>r.id===id);if(old)return old;
  settleMock(x,now);x.status='done';x.resumedAt=null;x.updatedAt=now;
  const p=getProfile(state,x.profileId),config=getConfig(p),subjects=[],topics=[],date=localDay(new Date(now));
  x.questions.forEach((q,i)=>{
    const answer=x.answers[i],blank=answer===null||answer==='';const correct=!blank&&gradeAnswer(q,answer);
    let s=subjects.find(s=>s.id===q.subjectId);if(!s){s={id:q.subjectId,label:config.subjects.find(s=>s.id===q.subjectId).label,correct:0,wrong:0,blank:0,total:0,net:0};subjects.push(s);}
    let t=topics.find(t=>t.key===q.topicKey);if(!t){t={key:q.topicKey,correct:0,wrong:0,blank:0};topics.push(t);}
    s[blank?'blank':correct?'correct':'wrong']++;t[blank?'blank':correct?'correct':'wrong']++;
    recordEvidence(state,{id:'exam:'+id+':'+i,topic:q.topicKey,source:'exam',correct,date,question:q,createReview:false,weight:blank?.5:1});
    if(!blank&&!correct&&state.examCoach.autoMistakes)addMistake(state,p.id,q,answer,date);
  });
  subjects.forEach(s=>Object.assign(s,netCounts(s.correct,s.wrong,s.blank,x.wrongDivisor)));
  return addResult(state,p,{id:x.id,profileId:p.id,source:'internal',kind:x.kind,title:x.title,date,finishedAt:now,seconds:Math.floor(x.elapsedMs/1000),subjects,topics,marked:[...x.marked],net:subjects.reduce((n,s)=>n+s.net,0),wrongDivisor:x.wrongDivisor,configVersion:x.configVersion});
}
export function addManualResult(state,profileId,input,now=Date.now()){
  const p=getProfile(state,profileId),c=getConfig(p);
  if(!validDay(input.date)||input.date>localDay(new Date(now))||!input.title?.trim()||input.title.length>200||!['full','subject','topic','weak','mini','custom'].includes(input.kind)||!Number.isInteger(input.minutes)||input.minutes<0||input.minutes>480||!Array.isArray(input.subjects)||!input.subjects.length)throw Error('Deneme adı, tarihi, süresi ve sonuçlarını kontrol et.');
  const subjects=input.subjects.map(row=>{
    const sub=c.subjects.find(s=>s.id===row.id);if(!sub)throw Error('Bu ders seçilen sınavda yok.');
    const counts=netCounts(row.correct,row.wrong,row.blank,c.wrongDivisor);
    if(!counts.total||counts.total>sub.count)throw Error(sub.label+' soru sayısı 1–'+sub.count+' olmalı.');
    return {id:row.id,label:sub.label,...counts};
  });
  if(new Set(subjects.map(s=>s.id)).size!==subjects.length||subjects.reduce((n,s)=>n+s.total,0)>160)throw Error('Dersler yinelenemez ve toplam en fazla 160 soru olabilir.');
  if(input.kind==='full'&&(subjects.length!==c.subjects.length||subjects.some(s=>s.total!==c.subjects.find(t=>t.id===s.id).count)))throw Error('Tam denemede yapılandırmadaki tüm derslerin soru sayıları gerekli.');
  if(input.kind==='subject'&&subjects.length!==1)throw Error('Ders denemesinde tek ders gir.');
  const topics=(input.topics||[]).map(row=>{
    if(!profileTopics(p).some(t=>t.key===row.key))throw Error('Konu eşleşmesi geçersiz.');
    netCounts(row.correct,row.wrong,row.blank,c.wrongDivisor);return {key:row.key,correct:row.correct,wrong:row.wrong,blank:row.blank};
  });
  if(new Set(topics.map(t=>t.key)).size!==topics.length)throw Error('Konu sonucu yinelenemez.');
  for(const s of subjects){const ts=topics.filter(t=>t.key.startsWith('exam:'+p.id+':'+s.id+':'));for(const k of ['correct','wrong','blank'])if(ts.reduce((n,t)=>n+t[k],0)>s[k])throw Error('Konu sayıları ders toplamını aşamaz.');}
  if(topics.some(t=>!subjects.some(s=>t.key.startsWith('exam:'+p.id+':'+s.id+':'))))throw Error('Konu sonucu için ders toplamını da gir.');
  const r={id:uid(),profileId:p.id,source:'manual',kind:input.kind,title:input.title.trim(),date:input.date,finishedAt:now,seconds:input.minutes*60,subjects,topics,marked:[],net:subjects.reduce((n,s)=>n+s.net,0),wrongDivisor:c.wrongDivisor,configVersion:c.version};
  // Aggregate subject-only entries must not invent topic-level evidence.
  for(const t of topics)for(const [key,correct] of [['correct',true],['wrong',false],['blank',false]])for(let i=0;i<t[key];i++)recordEvidence(state,{id:'manual:'+r.id+':'+t.key+':'+key+':'+i,topic:t.key,source:'external',correct,date:input.date,weight:key==='blank'?.5:1,createReview:false});
  return addResult(state,p,r);
}
export function addMistake(state,profileId,question,answer,date=localDay()){
  const p=getProfile(state,profileId);
  if(!validateQuestion(question)||!profileTopics(p).some(t=>t.key===question.topicKey))throw Error('Yanlış sorusunun dersini, konusunu ve cevap anahtarını kontrol et.');
  const old=state.examCoach.mistakes.find(m=>m.profileId===profileId&&m.question.id===question.id);if(old)return old;
  if(state.examCoach.mistakes.length>=3000)throw Error('Yanlışlar defteri 3000 kayıt sınırına ulaştı.');
  const m={id:uid(),profileId,question:structuredClone(question),topicKey:question.topicKey,studentAnswer:studentAnswerText(question,answer).slice(0,1000),date,reason:'unset',history:[]};
  state.examCoach.mistakes.push(m);return m;
}
export function manualMistake(state,profileId,input,date=localDay()){
  const p=getProfile(state,profileId),t=profileTopics(p).find(t=>t.key===input.topicKey);
  if(!t||!input.answer?.trim()||input.answer.length>300||!input.text?.trim()||input.text.length>3000||!input.explain?.trim()||input.explain.length>5000)throw Error('Soru, konu, doğru cevap ve açıklamalı çözüm gerekli.');
  const old=state.examCoach.mistakes.find(m=>m.profileId===profileId&&normalize(m.question.text)===normalize(input.text));if(old)return old;
  const question=decorate({id:uid(),type:'short',text:input.text.trim(),answers:[input.answer.trim()],explain:input.explain.trim(),level:2},p,t);
  return addMistake(state,profileId,question,String(input.studentAnswer||'').slice(0,1000),date);
}
export function queueMistakeReview(state,id,date=localDay()){
  const m=state.examCoach.mistakes.find(m=>m.id===id);if(!m)throw Error('Yanlış kaydı bulunamadı.');
  let card=state.review.find(c=>c.question.id===m.question.id);
  if(!card){card={id:uid(),question:structuredClone(m.question),topic:m.topicKey,due:date,interval:0,repetitions:0};state.review.push(card);}
  return card;
}
export function retryMistake(state,id,answer,now=Date.now()){
  const m=state.examCoach.mistakes.find(m=>m.id===id);if(!m)throw Error('Yanlış kaydı bulunamadı.');
  const date=localDay(new Date(now)),correct=gradeAnswer(m.question,answer),eventId=uid();
  if(m.history.length>=1000)throw Error('Bu soru için tekrar geçmişi sınırına ulaşıldı.');
  m.history.push({id:eventId,date,correct,answer:studentAnswerText(m.question,answer).slice(0,1000)});
  const card=queueMistakeReview(state,id,date);
  if(isDue(card,now))rateCard(state,card.id,correct?3:1,now);
  else recordEvidence(state,{id:'retry:'+eventId,topic:m.topicKey,source:'retry',correct,date,weight:.5,createReview:false});
  return correct;
}
export function analysis(state,profileId){
  const p=getProfile(state,profileId),results=state.examCoach.results.filter(r=>r.profileId===p.id),topics=profileTopics(p).map(t=>{
    const m=mastery(state,t.key),row=topicProgress(state,t.key),sample=results.flatMap(r=>r.topics.filter(x=>x.key===t.key));
    return {...t,status:row?.status||'new',mastery:m.observations>=3?m.score:null,observations:m.observations,correct:sample.reduce((n,x)=>n+x.correct,0),wrong:sample.reduce((n,x)=>n+x.wrong,0),blank:sample.reduce((n,x)=>n+x.blank,0)};
  });
  const subjects=getConfig(p).subjects.map(s=>{
    const rows=results.flatMap(r=>r.subjects.filter(x=>x.id===s.id)),total=rows.reduce((n,x)=>n+x.total,0),correct=rows.reduce((n,x)=>n+x.correct,0);
    const ts=topics.filter(t=>t.subject===s.id);return {...s,total,correct,rate:total?Math.round(correct*100/total):null,done:ts.filter(t=>t.status==='done').length};
  });
  const weak=topics.filter(t=>['weak','review'].includes(t.status)||(t.observations>=5&&t.mastery<60)).sort((a,b)=>(a.mastery??-1)-(b.mastery??-1));
  const recommendations=weak.slice(0,4).map(t=>({key:t.key,label:t.label,reason:t.observations>=5?`${t.observations.toFixed(1)} ağırlıklı gözlemde hâkimiyet göstergesi %${t.mastery}.`:'Kendi işaretlediğin konu durumu; ölçüm henüz yeterli değil.',questions:t.observations>=10?15:5}));
  if(!recommendations.length){const t=topics.find(t=>p.subjects.includes(t.subject)&&t.status!=='done');if(t)recommendations.push({key:t.key,label:t.label,reason:'Eksik olduğuna dair yeterli ölçüm yok. Başlangıç için kısa bir konu denemesi öneriliyor.',questions:5});}
  return {p,results,topics,subjects,weak,recommendations,done:topics.filter(t=>t.status==='done').length,review:topics.filter(t=>t.status==='review').length};
}
export function comparableResults(state,profileId,signature=null){const all=state.examCoach.results.filter(r=>r.profileId===profileId).sort((a,b)=>a.date.localeCompare(b.date)||a.finishedAt-b.finishedAt);const key=signature||all.at(-1)?.signature;return all.filter(r=>r.signature===key);}
export function netSummary(state,profileId,signature=null){const rows=comparableResults(state,profileId,signature),p=getProfile(state,profileId),last=rows.at(-1),average=rs=>rs.length?rs.reduce((n,r)=>n+r.net,0)/rs.length:null;return {rows,last,best:rows.length?Math.max(...rows.map(r=>r.net)):null,average:average(rows),lastFive:average(rows.slice(-5)),gap:last?.kind==='full'?p.targetNet-last.net:null,change:rows.length>1?last.net-rows.at(-2).net:null};}
export function weeklyReport(state,profileId,date=localDay()){
  const p=getProfile(state,profileId),weekday=(new Date(date+'T12:00:00').getDay()+6)%7,week=shiftDay(date,-weekday),end=shiftDay(week,7),a=analysis(state,profileId);
  const rs=a.results.filter(r=>r.date>=week&&r.date<end),seconds=state.sessions.filter(s=>s.profileId===p.id&&s.date>=week&&s.date<end).reduce((n,s)=>n+s.seconds,0),improved=[];
  for(const t of a.topics){const events=state.learning.events.filter(e=>e.topic===t.key),recent=events.filter(e=>e.date>=week&&e.date<end),past=events.filter(e=>e.date<week);if(recent.length>=3&&past.length>=3&&recent.filter(e=>e.correct).length/recent.length>past.filter(e=>e.correct).length/past.length)improved.push(t.key);}
  const comparables=comparableResults(state,profileId);const current=comparables.filter(r=>r.date>=week&&r.date<end),prior=comparables.filter(r=>r.date<week).at(-1);
  const report={profileId:p.id,week,generatedAt:Date.now(),seconds,questions:rs.reduce((n,r)=>n+r.subjects.reduce((n,s)=>n+s.total,0),0),improved,focus:a.recommendations.map(r=>r.key),netChange:current.length&&prior?current.at(-1).net-prior.net:null};
  const old=state.examCoach.weeklyReports.find(r=>r.profileId===p.id&&r.week===week);if(old)Object.assign(old,report);else if(state.examCoach.weeklyReports.length<500)state.examCoach.weeklyReports.push(report);
  return report;
}
export function coachContext(state,profileId){
  const a=analysis(state,profileId),s=netSummary(state,profileId),plan=state.learning.plans.find(p=>p.date===localDay());
  const context={exam:a.p.exam,field:a.p.field||null,language:a.p.language||null,targetDate:a.p.targetDate,targetNet:a.p.targetNet,availableMinutes:state.settings.dailyMinutes,measurementNote:a.results.length?'Yalnız mevcut kayıtlar; kesin sıralama veya puan tahmini yok.':'Henüz deneme verisi yok; eksik veya net uydurma.',comparableMocks:s.rows.slice(-4).map(r=>({date:r.date,net:r.net,total:r.subjects.reduce((n,s)=>n+s.total,0),kind:r.kind,subjects:r.subjects.map(s=>({subject:s.label,correct:s.correct,wrong:s.wrong,blank:s.blank,net:s.net}))})),topics:a.weak.slice(0,5).map(t=>({topic:t.label,observations:t.observations,indicator:t.mastery,status:t.status})),plan:(plan?.tasks||[]).filter(t=>t.topic.startsWith('exam:'+a.p.id+':')).slice(0,5).map(t=>({title:t.title,minutes:t.minutes,reasons:t.reasons.slice(0,2).map(r=>r.slice(0,120))})),mistakeReasons:Object.fromEntries(['unknown','attention','time','calculation','reading','unset'].map(k=>[k,state.examCoach.mistakes.filter(m=>m.profileId===a.p.id&&m.reason===k).length]))};
  while(JSON.stringify(context).length>4800&&context.comparableMocks.length>1)context.comparableMocks.shift();
  while(JSON.stringify(context).length>4800&&context.plan.length)context.plan.pop();
  return context;
}
export function deleteProfile(state,profileId){
  getProfile(state,profileId);const prefix='exam:'+profileId+':';
  if(state.learning.activeTask){const a=state.learning.activeTask,t=state.learning.plans.find(p=>p.date===a.date)?.tasks.find(t=>t.id===a.taskId);if(t?.topic.startsWith(prefix))throw Error('Önce bu profilin çalışan görev sayacını durdur.');}
  for(const key of ['sessions','results','mistakes','bank','weeklyReports'])state.examCoach[key]=state.examCoach[key].filter(x=>x.profileId!==profileId);
  state.examCoach.progress=state.examCoach.progress.filter(x=>!x.key.startsWith(prefix));
  state.examCoach.profiles=state.examCoach.profiles.filter(p=>p.id!==profileId);
  state.examCoach.activeProfileId=state.examCoach.profiles[0]?.id||null;
  state.review=state.review.filter(c=>!c.topic?.startsWith(prefix));
  for(const key of ['topics','events','reviewLog'])state.learning[key]=state.learning[key].filter(x=>!(x.topic||x.id).startsWith(prefix));
  for(const plan of state.learning.plans)plan.tasks=plan.tasks.filter(t=>!t.topic.startsWith(prefix));
}
