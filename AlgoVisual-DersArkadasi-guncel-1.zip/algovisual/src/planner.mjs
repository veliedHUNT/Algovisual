import {
  localDay,
  shiftDay,
  daysBetween,
  validDay,
  topicCatalog,
  mastery,
} from "./learning-state.mjs";
import { coachPriority, topicProgress } from './exam-state.mjs';
export function availableMinutes(state, date = localDay()) {
  const index = (new Date(date + "T12:00:00").getDay() + 6) % 7;
  return state.learning.availability[index] ?? state.settings.dailyMinutes;
}
export function validateExam(exam, state) {
  if (
    !exam.title?.trim() ||
    exam.title.length > 200 ||
    !exam.subject?.trim() ||
    exam.subject.length > 100 ||
    !validDay(exam.date) ||
    ![1, 2, 3].includes(exam.importance) ||
    !Number.isFinite(exam.prepared) ||
    exam.prepared < 0 ||
    exam.prepared > 100 ||
    !Array.isArray(exam.topics) ||
    exam.topics.length > 100 ||
    exam.topics.some((id) => !topicCatalog(state).some((t) => t.id === id))
  )
    throw Error(
      "Sınav adı, ders, geçerli tarih, konu ve hazırlık bilgilerini kontrol et.",
    );
  return exam;
}
function learned(state, topic) {
  if (topic.startsWith('exam:')) return topicProgress(state, topic)?.status === 'done';
  return topic.startsWith("lesson:")
    ? state.completed.includes(topic.slice(7))
    : mastery(state, topic).successes >= 2 ||
        (topic.startsWith("linux:") &&
          state.learning.lab?.completed.includes("path-" + topic.slice(6)));
}
export function rankTopics(state, date = localDay()) {
  const catalog = topicCatalog(state);
  const history = state.sessions.filter(
    (s) => s.seconds > 0 && s.date >= shiftDay(date, -7),
  );
  const average = history.length
    ? history.reduce((n, s) => n + s.seconds / 60, 0) / history.length
    : 20;
  return catalog
    .map((topic) => {
      const m = mastery(state, topic.id),
        reasons = [],
        scoreParts = [];
      const completed = learned(state, topic.id);
      const missingPrerequisite = topic.prerequisites.find(
        (id) => !learned(state, id),
      );
      const dueCards = state.review.filter(
        (r) => r.topic === topic.id && r.due <= date,
      );
      if (missingPrerequisite && !dueCards.length) return null;
      let score = completed ? 5 : 20;
      if (topic.examProfile) {
        const profile = state.examCoach.profiles.find(p => p.id === topic.examProfile);
        const priority = coachPriority(state, topic, date, daysBetween(date, profile.targetDate));
        score += priority.points;
        reasons.push(...priority.reasons);
      }
      if (!completed) reasons.push("Konu veya uygulama henüz tamamlanmadı.");
      if (m.observations) {
        const points = Math.round((100 - m.score) * 0.6);
        score += points;
        scoreParts.push("Eksik: +" + points);
        reasons.push(
          m.observations +
            " ağırlıklı gözlemde hâkimiyet göstergesi %" +
            m.score +
            " (tahmin).",
        );
      } else reasons.push("Henüz ölçüm yok; başlangıç çalışması öneriliyor.");
      const due = dueCards;
      if (due.length) {
        const overdue = Math.max(
          ...due.map((r) => Math.max(0, daysBetween(r.due, date))),
        );
        const points = 25 + Math.min(20, overdue * 2);
        score += points;
        scoreParts.push("Tekrar: +" + points);
        reasons.push(
          due.length +
            " kartın tekrar tarihi geldi" +
            (overdue ? "; en fazla " + overdue + " gün gecikti." : "."),
        );
      }
      for (const exam of state.learning.exams) {
        const days = daysBetween(date, exam.date);
        if (
          days < 0 ||
          days > 60 ||
          !(
            exam.topics.includes(topic.id) ||
            (!exam.topics.length && exam.subject === topic.subject)
          )
        )
          continue;
        const points = Math.round(
          (70 / (days + 2) + exam.importance * 8) * (1 - exam.prepared / 150),
        );
        score += points;
        scoreParts.push("Sınav: +" + points);
        reasons.push(
          exam.title +
            ": " +
            (days === 0 ? "bugün" : days + " gün kaldı") +
            ", hazırlık %" +
            exam.prepared +
            ".",
        );
      }
      if (
        state.lessons.some(
          (l) =>
            l.prerequisites?.includes(topic.id.slice(7)) &&
            !state.completed.includes(l.id),
        )
      ) {
        score += 6;
        reasons.push("Sonraki konular için ön koşul.");
      }
      if (completed && !due.length && !m.observations) return null;
      const minutes = Math.max(
        5,
        Math.min(topic.minutes, Math.round(Math.max(10, average) / 5) * 5),
      );
      return {
        ...topic,
        score,
        reasons: reasons.concat(scoreParts),
        minutes,
        kind: due.length
          ? "review"
          : topic.id.startsWith("lesson:")
            ? "lesson"
            : "practice",
        route: due.length ? "review" : topic.route,
      };
    })
    .filter(Boolean)
    .sort((a, b) => b.score - a.score || a.id.localeCompare(b.id));
}
export function rebuildPlan(state, date = localDay()) {
  if (!validDay(date)) throw Error("Geçersiz plan tarihi.");
  let plan = state.learning.plans.find((p) => p.date === date);
  const capacity = availableMinutes(state, date);
  if (!plan) {
    plan = { date, capacity, tasks: [] };
    state.learning.plans.push(plan);
  }
  plan.capacity = capacity;
  // Preserve completed, edited, deferred and running tasks; only replace automatic pending work.
  const keep = plan.tasks.filter(
    (t) =>
      t.status !== "pending" ||
      t.manual ||
      (state.learning.activeTask?.date === date &&
        state.learning.activeTask?.taskId === t.id),
  );
  let reserved = keep
    .filter((t) => t.status !== "deferred")
    .reduce((n, t) => n + t.minutes, 0);
  for (const past of state.learning.plans
    .filter((p) => p.date < date)
    .sort((a, b) => a.date.localeCompare(b.date))) {
    for (const task of past.tasks) {
      if (
        task.status !== "deferred" ||
        !task.deferUntil ||
        task.deferUntil > date ||
        task.carriedTo
      )
        continue;
      if (reserved + task.minutes > capacity) continue; // Keep in the deferred backlog until it fits.
      const carried = {
        ...task,
        id: "carry:" + past.date + ":" + task.id,
        status: "pending",
        deferUntil: null,
        manual: true,
        loggedSeconds: 0,
      };
      keep.push(carried);
      task.carriedTo = date;
      reserved += task.minutes;
    }
  }
  let remaining = Math.max(0, capacity - reserved),
    work = 0;
  const tasks = [...keep];
  const occupied = new Set(keep.map((t) => t.topic));
  const candidates = rankTopics(state, date), profilePicks = new Map();
  // A modest diminishing bonus prevents equally urgent profiles monopolizing a day.
  const ordered = [];
  while (candidates.length) {
    candidates.sort((a,b) => (b.score - (profilePicks.get(b.examProfile)||0)*15) - (a.score - (profilePicks.get(a.examProfile)||0)*15));
    const next = candidates.shift();
    ordered.push(next);
    if (next.examProfile) profilePicks.set(next.examProfile,(profilePicks.get(next.examProfile)||0)+1);
  }
  for (const topic of ordered) {
    if (remaining < 5 || occupied.has(topic.id)) continue;
    if (work >= 40 && remaining >= 10) {
      let breakIndex = tasks.length;
      while (tasks.some((t) => t.id === "break:" + breakIndex)) breakIndex++;
      tasks.push({
        id: "break:" + breakIndex,
        topic: "break",
        title: "Kısa mola",
        kind: "break",
        route: "coach",
        minutes: 5,
        status: "pending",
        manual: false,
        deferUntil: null,
        loggedSeconds: 0,
        score: 0,
        reasons: ["Odak blokları arasında dinlenme."],
      });
      remaining -= 5;
      work = 0;
    }
    const minutes = Math.min(topic.minutes, remaining);
    tasks.push({
      id: topic.kind + ":" + topic.id,
      topic: topic.id,
      title: topic.label,
      kind: topic.kind,
      route: topic.route,
      minutes,
      status: "pending",
      manual: false,
      deferUntil: null,
      loggedSeconds: 0,
      score: topic.score,
      reasons: topic.reasons,
    });
    remaining -= minutes;
    work += minutes;
    occupied.add(topic.id);
  }
  plan.tasks = tasks;
  state.learning.plans = state.learning.plans
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(-90);
  return plan;
}
export function deferTask(state, date, id, until = shiftDay(date, 1)) {
  if (!validDay(until) || until <= date)
    throw Error("Erteleme tarihi plan tarihinden sonra olmalı.");
  const task = state.learning.plans
    .find((p) => p.date === date)
    ?.tasks.find((t) => t.id === id);
  if (!task || task.status === "done")
    throw Error("Ertelenebilecek görev bulunamadı.");
  if (
    state.learning.activeTask?.date === date &&
    state.learning.activeTask?.taskId === id
  ) {
    settleTask(state, "pause");
    state.learning.activeTask = null;
  }
  task.status = "deferred";
  task.deferUntil = until;
  return rebuildPlan(state, date);
}
export function taskElapsed(state, now = Date.now()) {
  const active = state.learning.activeTask;
  if (!active) return 0;
  const task = state.learning.plans
    .find((p) => p.date === active.date)
    ?.tasks.find((t) => t.id === active.taskId);
  return task
    ? Math.min(
        task.minutes * 60,
        task.loggedSeconds +
          (active.startedAt === null
            ? 0
            : Math.max(0, Math.floor((now - active.startedAt) / 1000))),
      )
    : 0;
}
export function startTask(state, date, id, now = Date.now()) {
  const task = state.learning.plans
    .find((p) => p.date === date)
    ?.tasks.find((t) => t.id === id);
  if (!task || task.status !== "pending") throw Error("Görev başlatılamıyor.");
  if (task.loggedSeconds >= task.minutes * 60)
    throw Error("Ayrılan süre dolmuş. Görevi tamamla veya süresini artır.");
  if (state.timer) throw Error("Önce mevcut odak sayacını bitir.");
  if (state.learning.activeTask) settleTask(state, "pause", now);
  state.learning.activeTask = { date, taskId: id, startedAt: now };
}
export function settleTask(state, action, now = Date.now()) {
  const active = state.learning.activeTask;
  if (!active) return;
  const task = state.learning.plans
    .find((p) => p.date === active.date)
    ?.tasks.find((t) => t.id === active.taskId);
  if (!task) {
    state.learning.activeTask = null;
    return;
  }
  const total = taskElapsed(state, now),
    seconds = Math.max(0, total - task.loggedSeconds);
  if (seconds && task.kind !== "break") {
    // Split actual elapsed time by local calendar day, including midnight/DST boundaries.
    let cursor = active.startedAt;
    const segmentEnd = cursor + seconds * 1000;
    while (cursor < segmentEnd) {
      const next = new Date(cursor);
      next.setHours(24, 0, 0, 0);
      const end = Math.min(segmentEnd, next.getTime());
      state.sessions.push({
        id: crypto.randomUUID(),
        date: localDay(new Date(cursor)),
        seconds: Math.round((end - cursor) / 1000),
        title: task.title,
        ...(task.topic.startsWith('exam:') ? { profileId: task.topic.split(':')[1], topicKey: task.topic } : {}),
      });
      cursor = end;
    }
  }
  task.loggedSeconds = total;
  if (action === "done") {
    task.status = "done";
    const topicRow = state.examCoach?.progress.find(p => p.key === task.topic);
    if (topicRow && task.loggedSeconds > 0) topicRow.lastStudy = localDay(new Date(now));
    state.learning.activeTask = null;
  } else state.learning.activeTask = { ...active, startedAt: null };
}
export function editTask(state, date, id, changes) {
  const plan = state.learning.plans.find((p) => p.date === date),
    task = plan?.tasks.find((t) => t.id === id);
  if (!task || task.status === "done") throw Error("Görev düzenlenemiyor.");
  const minutes = Number(changes.minutes);
  if (
    !changes.title?.trim() ||
    changes.title.length > 200 ||
    !Number.isInteger(minutes) ||
    minutes < 1 ||
    minutes > 480
  )
    throw Error("Görev başlığı ve süresi geçersiz.");
  const fixed = plan.tasks
    .filter(
      (t) =>
        t.id !== id &&
        t.status !== "deferred" &&
        (t.manual ||
          t.status === "done" ||
          (state.learning.activeTask?.date === date &&
            state.learning.activeTask?.taskId === t.id)),
    )
    .reduce((n, t) => n + t.minutes, 0);
  if (fixed + minutes > plan.capacity)
    throw Error("Elle düzenlenen ve tamamlanan görevler günlük süreyi aşıyor.");
  const spent =
    state.learning.activeTask?.date === date &&
    state.learning.activeTask?.taskId === id
      ? taskElapsed(state)
      : task.loggedSeconds;
  if (minutes * 60 < spent)
    throw Error("Görev süresi kaydedilen gerçek süreden kısa olamaz.");
  if (state.learning.activeTask?.taskId === id) settleTask(state, "pause");
  Object.assign(task, { title: changes.title.trim(), minutes, manual: true });
  return rebuildPlan(state, date);
}
export function configureStudyTime(
  state,
  daily,
  availability,
  from = localDay(),
) {
  if (
    !Number.isInteger(daily) ||
    daily < 5 ||
    daily > 480 ||
    !Array.isArray(availability) ||
    availability.length !== 7 ||
    availability.some(
      (n) => n !== null && (!Number.isInteger(n) || n < 0 || n > 480),
    )
  )
    throw Error(
      "Günlük süre 5–480, haftalık özel süreler 0–480 tam dakika olmalı.",
    );
  const candidate = {
    ...state,
    settings: { ...state.settings, dailyMinutes: daily },
    learning: { ...state.learning, availability },
  };
  for (const plan of state.learning.plans.filter((p) => p.date >= from)) {
    const committed = plan.tasks
      .filter(
        (t) =>
          t.status !== "deferred" &&
          (t.manual ||
            t.status === "done" ||
            (state.learning.activeTask?.date === plan.date &&
              state.learning.activeTask?.taskId === t.id)),
      )
      .reduce((n, t) => n + t.minutes, 0);
    if (committed > availableMinutes(candidate, plan.date))
      throw Error(
        plan.date +
          " için tamamlanan, çalışan veya elle korunan görevler yeni süreyi aşıyor. Önce düzenlenebilir görevlerini azalt veya bu güne özel süre ayır.",
      );
  }
  state.settings.dailyMinutes = daily;
  state.learning.availability = [...availability];
  for (const date of state.learning.plans
    .filter((p) => p.date >= from)
    .map((p) => p.date))
    rebuildPlan(state, date);
}
