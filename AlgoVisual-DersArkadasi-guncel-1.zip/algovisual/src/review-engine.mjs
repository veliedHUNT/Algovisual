import {
  localDay,
  shiftDay,
  daysBetween,
  recordEvidence,
  topicForQuestion,
} from "./learning-state.mjs";
import { validateQuestion } from "./core.mjs";
export const ratings = [
  "Tekrar öğrenmeliyim",
  "Zor hatırladım",
  "Hatırladım",
  "Çok kolaydı",
];
// SM-2 inspired four-grade scheduler. This is not FSRS or a fitted recall probability.
export function scheduleReview(card, rating, now = Date.now()) {
  if (![1, 2, 3, 4].includes(rating))
    throw Error("Tekrar değerlendirmesi 1–4 olmalı.");
  const date = localDay(new Date(now));
  const old = card.srs || {
    ease: 2.5,
    streak: 0,
    lapses: 0,
    successes: 0,
    failures: 0,
  };
  const q = [0, 1, 3, 4, 5][rating];
  const ease = Math.max(
    1.3,
    Math.min(3.2, old.ease + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02))),
  );
  let interval;
  if (rating === 1) interval = 0;
  else if (rating === 2)
    interval = Math.max(1, Math.round(Math.max(1, card.interval) * 0.6));
  else if (!old.streak)
    interval =
      rating === 4
        ? Math.max(3, card.interval + 1)
        : Math.max(1, card.interval);
  else if (old.streak === 1)
    interval = Math.max(rating === 4 ? 8 : 6, card.interval + 1);
  else
    interval = Math.max(
      card.interval + 1,
      Math.round(Math.max(1, card.interval) * ease * (rating === 4 ? 1.3 : 1)),
    );
  interval = Math.min(365, interval);
  return {
    ...card,
    interval,
    due: shiftDay(date, interval),
    repetitions: (card.repetitions || 0) + 1,
    srs: {
      version: 1,
      ease,
      streak: rating < 3 ? 0 : old.streak + 1,
      lapses: old.lapses + Number(rating === 1),
      successes: old.successes + Number(rating >= 3),
      failures: old.failures + Number(rating < 3),
      last: date,
      againAt: rating === 1 ? now + 600000 : null,
    },
  };
}
export const isDue = (card, now = Date.now()) =>
  card.due <= localDay(new Date(now)) &&
  (!card.srs?.againAt || card.srs.againAt <= now);
export function rateCard(state, cardId, rating, now = Date.now()) {
  const index = state.review.findIndex((c) => c.id === cardId);
  if (index < 0 || !isDue(state.review[index], now))
    throw Error("Bu kartın tekrar zamanı henüz gelmedi.");
  const card = state.review[index],
    next = scheduleReview(card, rating, now);
  state.review[index] = next;
  const event = {
    id: crypto.randomUUID(),
    cardId,
    topic: card.topic || topicForQuestion(state, card.question),
    rating,
    date: localDay(new Date(now)),
    interval: next.interval,
  };
  state.learning.reviewLog.push(event);
  state.learning.reviewLog = state.learning.reviewLog.slice(-10000);
  recordEvidence(state, {
    id: "review:" + event.id,
    topic: event.topic,
    source: "review",
    correct: rating >= 3,
    date: event.date,
    createReview: false,
    weight: 0.5,
  });
  return next;
}
export function addBankReviews(state, limit = 12, date = localDay()) {
  const seen = new Set(state.review.map((c) => c.question.id));
  const wrong = new Set(
    state.attempts.flatMap((a) =>
      (a.results || []).filter((r) => !r.correct).map((r) => r.question.id),
    ),
  );
  const all = state.lessons
    .flatMap((l) =>
      l.quiz.map((q) => ({ question: q, topic: "lesson:" + l.id })),
    )
    .concat(
      state.tests.flatMap((t) =>
        t.questions.map((q) => ({
          question: q,
          topic: topicForQuestion(state, q, t.lessonId),
        })),
      ),
    );
  all.sort(
    (a, b) =>
      Number(wrong.has(b.question.id)) - Number(wrong.has(a.question.id)),
  );
  let added = 0;
  const perTopic = new Map();
  // Round-robin topics before taking a second question from the same topic.
  for (let round = 0; round < 4 && added < limit; round++)
    for (const { question, topic } of all) {
      if (added >= limit) break;
      if (
        seen.has(question.id) ||
        !validateQuestion(question) ||
        (perTopic.get(topic) || 0) > round
      )
        continue;
      state.review.push({
        id: crypto.randomUUID(),
        question: structuredClone(question),
        topic,
        due: date,
        interval: 0,
        repetitions: 0,
      });
      seen.add(question.id);
      perTopic.set(topic, (perTopic.get(topic) || 0) + 1);
      added++;
    }
  return {
    added,
    available: new Set(
      all.filter((x) => validateQuestion(x.question)).map((x) => x.question.id),
    ).size,
  };
}
export function reviewSummary(state, date = localDay(), now = Date.now()) {
  const due = state.review.filter((c) => isDue(c, now));
  const topics = [
    ...new Set(
      state.review.map((c) => c.topic || topicForQuestion(state, c.question)),
    ),
  ]
    .map((id) => {
      const cards = state.review.filter(
        (c) => (c.topic || topicForQuestion(state, c.question)) === id,
      );
      const logs = state.learning.reviewLog.filter((x) => x.topic === id);
      const successes = logs.filter((x) => x.rating >= 3).length,
        failures = logs.length - successes;
      const last =
        logs
          .map((x) => x.date)
          .sort()
          .at(-1) || null;
      const next = cards.map((x) => x.due).sort()[0] || null;
      const late = next ? Math.max(0, daysBetween(next, date)) : 0;
      const typical = Math.max(
        1,
        cards.reduce((n, c) => n + c.interval, 0) / Math.max(1, cards.length),
      );
      // Coarse, labelled heuristic; no exact forgetting percentage is claimed.
      const memory =
        logs.length < 3
          ? "Yeterli veri yok"
          : late > typical || failures > successes
            ? "Destek gerekiyor (tahmin)"
            : late > 0
              ? "Tekrar zamanı (tahmin)"
              : "Pekişiyor (tahmin)";
      return { id, last, next, successes, failures, memory, late };
    })
    .sort((a, b) => b.failures - a.failures || b.late - a.late);
  return {
    due,
    late: due.filter((c) => c.due < date),
    tomorrow: state.review.filter((c) => c.due === shiftDay(date, 1)),
    calendar: Array.from({ length: 7 }, (_, i) => ({
      date: shiftDay(date, i),
      count: state.review.filter((c) => c.due === shiftDay(date, i)).length,
    })),
    topics,
    performance: Array.from({ length: 7 }, (_, i) => {
      const d = shiftDay(date, i - 6),
        logs = state.learning.reviewLog.filter((x) => x.date === d);
      return {
        date: d,
        total: logs.length,
        correct: logs.filter((x) => x.rating >= 3).length,
      };
    }),
  };
}
