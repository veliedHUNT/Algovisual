import { localDay, recordEvidence } from "./learning-state.mjs";
const HOME = "/home/ogrenci";
const forbidden = new Set(["__proto__", "prototype", "constructor"]);
export function resolvePath(cwd, input = ".") {
  if (
    typeof input !== "string" ||
    input.length > 300 ||
    !/^\/?[\w/.-]*$/.test(input)
  )
    throw Error("Sanal yolda yalnız harf, sayı, _, -, . ve / kullan.");
  const parts = input.startsWith("/") ? [] : cwd.split("/").filter(Boolean);
  for (const part of input.split("/")) {
    if (!part || part === ".") continue;
    if (part === "..") {
      if (!parts.length) throw Error("Sanal kök dizinin üstüne çıkılamaz.");
      parts.pop();
    } else {
      if (forbidden.has(part)) throw Error("Bu dosya adı desteklenmiyor.");
      parts.push(part);
    }
  }
  return "/" + parts.join("/");
}
const parent = (p) => p.slice(0, p.lastIndexOf("/")) || "/";
const basename = (p) => p.slice(p.lastIndexOf("/") + 1);
const get = (lab, path) => lab.fs.find((f) => f.path === path);
function directory(lab, path) {
  const f = get(lab, path);
  if (f?.type !== "dir") throw Error("Klasör bulunamadı: " + path);
  return f;
}
function writeable(lab, path) {
  const d = directory(lab, path);
  if (!(Number(d.mode[0]) & 2)) throw Error("Sanal klasörde yazma izni yok.");
}
function file(lab, path) {
  const f = get(lab, path);
  if (f?.type !== "file") throw Error("Dosya bulunamadı: " + path);
  if (!(Number(f.mode[0]) & 4)) throw Error("Sanal dosyada okuma izni yok.");
  return f;
}
function put(lab, path, content, append = false) {
  writeable(lab, parent(path));
  let f = get(lab, path);
  if (f?.type === "dir") throw Error("Bir klasöre dosya metni yazılamaz.");
  if (f && !(Number(f.mode[0]) & 2))
    throw Error("Sanal dosyada yazma izni yok.");
  if (!f) {
    f = { path, type: "file", content: "", mode: "644" };
    lab.fs.push(f);
  }
  f.content = (append ? f.content : "") + content;
  if (f.content.length > 32000)
    throw Error("Sanal dosya 32.000 karakter sınırını aşıyor.");
}
export function createLab() {
  const lab = {
    cwd: HOME,
    fs: [{ path: "/", type: "dir", content: "", mode: "755" }],
    history: [],
    completed: [],
    ctf: [],
    hints: [],
    evidence: [],
  };
  for (const path of [
    "/home",
    HOME,
    HOME + "/.arsiv",
    HOME + "/paylasim",
    "/var",
    "/var/log",
    "/egitim",
  ])
    lab.fs.push({ path, type: "dir", content: "", mode: "755" });
  const fixtures = [
    [
      HOME + "/hosgeldin.txt",
      "AlgoVisual sanal Linux laboratuvarı.\nBütün dosyalar ve kişiler kurgusaldır.\nhelp ile komutları gör.\n",
    ],
    [
      HOME + "/rapor.txt",
      "Egitim raporu: sanal dosyalar uzerinde calisildi.\n",
    ],
    [
      HOME + "/.arsiv/mesaj.txt",
      "Eski egitim notu\nGizli mesaj: FLAG{DOSYAYI_BULDUN}\n",
    ],
    [
      "/var/log/app.log",
      "INFO uygulama basladi\nERROR E42: ornek veritabani baglantisi yok\nINFO yeniden denendi\n",
    ],
    [
      "/var/log/auth.log",
      "10:00 login OK ogrenci 192.0.2.10\n10:01 login FAIL demo 192.0.2.44\n10:02 login FAIL demo 192.0.2.44\n10:03 login FAIL demo 192.0.2.44\n10:04 login OK ogrenci 192.0.2.10\n",
    ],
    [
      HOME + "/paylasim/gizli.txt",
      "Kurgusal ozel ders notu.\nFLAG{OZEL_DOSYA}\n",
      "777",
    ],
    [
      "/egitim/dns.txt",
      "DNS adlari IP adreslerine esler.\ncalisma.example A 198.51.100.20\nposta.example A 192.0.2.25\n",
    ],
    [
      "/egitim/http.txt",
      "HTTP/1.1 403 Forbidden\nIstek kimligi dogrulanmis olsa bile yetki yetersiz olabilir.\nBu egitim yanitinin durum kodunu incele.\n",
    ],
    [
      "/egitim/hash.txt",
      "Hash butunluk kontrolunde kullanilan tek yonlu bir ozettir.\nSifreleme anahtarla geri cozulmek icin tasarlanir; hash ayni sey degildir.\nBu farki anlatan flag: FLAG{HASH_GERI_DONMEZ}\n",
    ],
    [
      "/egitim/parola.txt",
      "Kurgusal parola ilkesi: Her hesap icin benzersiz, uzun bir parola cumlesi kullan.\nParola yoneticisi ve uygun cok faktorlu dogrulama kullan.\nGercek parolani bu laboratuvara yazma.\nFLAG{UZUN_VE_BENZERSIZ}\n",
    ],
    [
      "/egitim/yetki.json",
      JSON.stringify(
        {
          user: "ornek_ogrenci",
          authenticated: true,
          role: "ogrenci",
          request: "yonetici_paneli",
          result: "403",
          lesson:
            "Kimlik dogrulama kim oldugunu, yetkilendirme ne yapabilecegini belirler.",
          flag: "FLAG{YETKILENDIRME}",
        },
        null,
        2,
      ),
    ],
    [
      "/egitim/ag.txt",
      "Ozel ag ornegi: 192.168.1.10\nDokumantasyon icin ayrilmis ornek IP: 192.0.2.10\nIP agdaki mantiksal adresi belirtir. Gercek hedefe baglanti yoktur.\n",
    ],
    [
      "/egitim/web.txt",
      "Kullanici girdisi veri olarak gosterilmelidir.\nTehlikeli ornek: <img src=x onerror=alert('kurgusal')>\nGuvenli metin: &lt;img src=x&gt;\nDers: HTML kacisi / XSS farkindaligi.\nFLAG{XSS_KACIS}\n",
    ],
  ];
  for (const [path, content, mode = "644"] of fixtures)
    lab.fs.push({ path, type: "file", content, mode });
  return lab;
}
function tokenize(line) {
  const tokens = [];
  let word = "",
    quote = null,
    started = false;
  const flush = () => {
    if (started) {
      tokens.push({ value: word, operator: false });
      word = "";
      started = false;
    }
  };
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quote) {
      if (c === quote) quote = null;
      else word += c;
      started = true;
      continue;
    }
    if (c === "'" || c === '"') {
      quote = c;
      started = true;
      continue;
    }
    if (c === "\\") {
      if (i + 1 >= line.length) throw Error("Eksik kaçış karakteri.");
      word += line[++i];
      started = true;
      continue;
    }
    if (/\s/.test(c)) {
      flush();
      continue;
    }
    if (c === "|" || c === ">") {
      flush();
      if (c === ">" && line[i + 1] === ">") {
        tokens.push({ value: ">>", operator: true });
        i++;
      } else tokens.push({ value: c, operator: true });
      continue;
    }
    if (
      [";", "&", "<", String.fromCharCode(96)].includes(c) ||
      (c === "$" && line[i + 1] === "(")
    )
      throw Error(
        "Shell betiği/komut zinciri desteklenmiyor; yalnız sanal komutları kullan.",
      );
    word += c;
    started = true;
  }
  if (quote) throw Error("Tırnak kapatılmamış.");
  flush();
  if (tokens.length > 200) throw Error("Çok fazla komut parametresi.");
  return tokens;
}
const modes = (mode) =>
  [...mode]
    .map((n) =>
      [
        Number(n) & 4 ? "r" : "-",
        Number(n) & 2 ? "w" : "-",
        Number(n) & 1 ? "x" : "-",
      ].join(""),
    )
    .join("");
function globMatch(pattern, value) {
  let previous = Array(value.length + 1).fill(false);
  previous[0] = true;
  for (const character of pattern) {
    const current = Array(value.length + 1).fill(false);
    if (character === "*") current[0] = previous[0];
    for (let j = 1; j <= value.length; j++)
      current[j] =
        character === "*"
          ? previous[j] || current[j - 1]
          : previous[j - 1] &&
            (character === "?" || character === value[j - 1]);
    previous = current;
  }
  return previous[value.length];
}
function execute(lab, args, stdin, evidence) {
  const command = args.shift(),
    path = (value) => resolvePath(lab.cwd, value);
  const note = (type, p, detail = "") =>
    evidence.push({ type, path: p, detail: String(detail).slice(0, 1000) });
  if (command === "pwd") {
    if (args.length) throw Error("pwd parametre almaz.");
    note("pwd", lab.cwd);
    return lab.cwd;
  }
  if (command === "help")
    return "Sanal komutlar: pwd, ls [-a] [-l], cd, mkdir [-p], touch, cat, echo [-n], cp [-r], mv, rm [-r], grep [-i] [-n], find [-name], head [-n], tail [-n], wc [-l|-w|-c], chmod, stat, clear, help.\nEn fazla 4 okuma komutu | ile bağlanabilir. > ve >> yalnız sanal dosyalara yazar. grep düz metin eşleştirir. Gerçek shell, program ve ağ çalıştırılmaz.";
  if (command === "clear") {
    if (args.length) throw Error("clear parametre almaz.");
    return "";
  }
  if (command === "echo") {
    const newline = args[0] !== "-n";
    if (!newline) args.shift();
    return args.join(" ") + (newline ? "\n" : "");
  }
  if (command === "cd") {
    if (args.length > 1) throw Error("cd tek klasör alır.");
    const p = path(args[0] || HOME);
    directory(lab, p);
    lab.cwd = p;
    note("cd", p);
    return "";
  }
  if (command === "ls") {
    const all =
        args.includes("-a") || args.includes("-la") || args.includes("-al"),
      long =
        args.includes("-l") || args.includes("-la") || args.includes("-al");
    const paths = args.filter((a) => !a.startsWith("-"));
    if (
      args.some(
        (a) => a.startsWith("-") && !["-a", "-l", "-la", "-al"].includes(a),
      ) ||
      paths.length > 1
    )
      throw Error("ls [-a] [-l] [klasör] kullan.");
    const p = path(paths[0] || ".");
    directory(lab, p);
    note("list", p, all ? "all" : "visible");
    return lab.fs
      .filter(
        (f) =>
          f.path !== p &&
          parent(f.path) === p &&
          (all || !basename(f.path).startsWith(".")),
      )
      .sort((a, b) => a.path.localeCompare(b.path))
      .map(
        (f) =>
          (long ? (f.type === "dir" ? "d" : "-") + modes(f.mode) + " " : "") +
          basename(f.path) +
          (f.type === "dir" ? "/" : ""),
      )
      .join("\n");
  }
  if (command === "mkdir") {
    const recursive = args.includes("-p"),
      paths = args.filter((x) => x !== "-p");
    if (!paths.length || paths.some((x) => x.startsWith("-")))
      throw Error("mkdir [-p] klasör kullan.");
    for (const value of paths) {
      const p = path(value),
        parts = p.split("/").filter(Boolean);
      let current = "";
      for (let i = 0; i < parts.length; i++) {
        current += "/" + parts[i];
        const exists = get(lab, current);
        if (exists) {
          if (exists.type !== "dir" || (!recursive && i === parts.length - 1))
            throw Error("Bu yol zaten var: " + current);
          continue;
        }
        if (!recursive && i !== parts.length - 1)
          throw Error("Üst klasör yok; mkdir -p kullan.");
        writeable(lab, parent(current));
        lab.fs.push({ path: current, type: "dir", content: "", mode: "755" });
        note("mkdir", current);
      }
    }
    return "";
  }
  if (command === "touch") {
    if (!args.length || args.some((x) => x.startsWith("-")))
      throw Error("touch dosya kullan.");
    for (const value of args) {
      const p = path(value);
      if (get(lab, p)?.type === "dir") throw Error("Bu yol bir klasör.");
      if (!get(lab, p)) put(lab, p, "");
      note("touch", p);
    }
    return "";
  }
  if (command === "cat") {
    if (!args.length) return stdin ?? "";
    return args
      .map((value) => {
        const p = path(value),
          f = file(lab, p);
        note("read", p);
        return f.content;
      })
      .join("");
  }
  if (["cp", "mv"].includes(command)) {
    const recursive = args.includes("-r"),
      values = args.filter((x) => x !== "-r");
    if (values.length !== 2 || values.some((x) => x.startsWith("-")))
      throw Error(command + " [-r] kaynak hedef kullan.");
    const source = path(values[0]),
      f = get(lab, source);
    if (!f || source === "/") throw Error("Kaynak bulunamadı veya korunuyor.");
    let destination = path(values[1]);
    if (get(lab, destination)?.type === "dir")
      destination = resolvePath(destination, basename(source));
    if (destination === source) throw Error("Kaynak ve hedef aynı.");
    if (
      f.type === "dir" &&
      (destination.startsWith(source + "/") || (!recursive && command === "cp"))
    )
      throw Error("Klasör için cp -r kullan; kendisinin içine kopyalanamaz.");
    writeable(lab, parent(destination));
    if (command === "mv") writeable(lab, parent(source));
    if (get(lab, destination) && get(lab, destination).type !== f.type)
      throw Error("Hedef türü kaynakla uyumsuz.");
    if (f.type === "dir" && get(lab, destination))
      throw Error("Hedef klasör zaten var.");
    const sources = lab.fs.filter(
      (x) => x.path === source || x.path.startsWith(source + "/"),
    );
    for (const sourceFile of sources) {
      const copy = {
          ...sourceFile,
          path: destination + sourceFile.path.slice(source.length),
        },
        old = get(lab, copy.path);
      if (old) lab.fs = lab.fs.filter((x) => x.path !== old.path);
      lab.fs.push(copy);
    }
    if (command === "mv") {
      lab.fs = lab.fs.filter(
        (x) => !(x.path === source || x.path.startsWith(source + "/")),
      );
      if (lab.cwd === source || lab.cwd.startsWith(source + "/"))
        lab.cwd = destination + lab.cwd.slice(source.length);
    }
    note(command, destination, source);
    return "";
  }
  if (command === "rm") {
    const recursive = args.includes("-r") || args.includes("-rf"),
      force = args.includes("-f") || args.includes("-rf");
    const values = args.filter((x) => !["-r", "-f", "-rf"].includes(x));
    if (!values.length || values.some((x) => x.startsWith("-")))
      throw Error("rm [-r] dosya/klasör kullan.");
    for (const value of values) {
      const p = path(value),
        f = get(lab, p);
      if (
        p === "/" ||
        p === HOME ||
        lab.cwd === p ||
        lab.cwd.startsWith(p + "/")
      )
        throw Error("Sanal kök, ev veya çalışılan klasör silinemez.");
      if (!f) {
        if (force) continue;
        throw Error("Silinecek sanal yol yok.");
      }
      if (f.type === "dir" && !recursive)
        throw Error("Klasör için rm -r kullan.");
      writeable(lab, parent(p));
      lab.fs = lab.fs.filter(
        (x) => x.path !== p && !x.path.startsWith(p + "/"),
      );
      note("rm", p);
    }
    return "";
  }
  if (command === "grep") {
    const insensitive = args.includes("-i"),
      numbers = args.includes("-n"),
      rest = args.filter((x) => !["-i", "-n"].includes(x));
    if (!rest.length || rest[0].length > 200)
      throw Error("grep [-i] [-n] metin [dosya] kullan.");
    const needle = rest.shift(),
      inputs = rest.length
        ? rest.map((x) => ({ path: path(x), text: file(lab, path(x)).content }))
        : [{ path: "stdin", text: stdin || "" }];
    return inputs
      .map((input) => {
        const matches = input.text
          .split("\n")
          .map((line, i) => ({ line, index: i + 1 }))
          .filter((x) =>
            (insensitive ? x.line.toLocaleLowerCase("tr") : x.line).includes(
              insensitive ? needle.toLocaleLowerCase("tr") : needle,
            ),
          );
        const output = matches
          .map(
            (x) =>
              (inputs.length > 1 ? input.path + ":" : "") +
              (numbers ? x.index + ":" : "") +
              x.line,
          )
          .join("\n");
        if (matches.length) note("grep", input.path, output);
        return output ? output + "\n" : "";
      })
      .filter(Boolean)
      .join("\n");
  }
  if (command === "find") {
    const start = path(
      args[0] && !args[0].startsWith("-") ? args.shift() : ".",
    );
    directory(lab, start);
    let pattern = "*";
    if (args.length) {
      if (args.length !== 2 || args[0] !== "-name")
        throw Error("find [klasör] [-name desen] kullan.");
      pattern = args[1];
    }
    if (pattern.length > 100) throw Error("Arama deseni çok uzun.");
    const output = lab.fs
      .filter(
        (f) =>
          (f.path === start ||
            f.path.startsWith(start === "/" ? "/" : start + "/")) &&
          globMatch(pattern, basename(f.path)),
      )
      .map((f) => f.path)
      .sort()
      .join("\n");
    note("find", start, output);
    return output ? output + "\n" : "";
  }
  if (command === "head" || command === "tail") {
    let count = 10;
    if (args[0] === "-n") {
      args.shift();
      count = Number(args.shift());
    }
    if (!Number.isInteger(count) || count < 0 || count > 100 || args.length > 1)
      throw Error(command + " [-n 0..100] [dosya] kullan.");
    const p = args.length ? path(args[0]) : null,
      text = p ? file(lab, p).content : stdin || "";
    if (p) note("read", p);
    const lines = text.match(/[^\n]*\n|[^\n]+$/g) || [];
    return count
      ? (command === "head" ? lines.slice(0, count) : lines.slice(-count)).join(
          "",
        )
      : "";
  }
  if (command === "wc") {
    const flags = args.filter((x) => x.startsWith("-")),
      paths = args.filter((x) => !x.startsWith("-"));
    if (
      flags.some((x) => !["-l", "-w", "-c"].includes(x)) ||
      flags.length > 1 ||
      paths.length > 1
    )
      throw Error("wc [-l|-w|-c] [dosya] kullan.");
    const p = paths.length ? path(paths[0]) : null,
      text = p ? file(lab, p).content : stdin || "";
    if (p) note("read", p);
    const counts = [
      (text.match(/\n/g) || []).length,
      text.trim() ? text.trim().split(/\s+/).length : 0,
      new TextEncoder().encode(text).length,
    ];
    return String(
      flags.length
        ? counts[["-l", "-w", "-c"].indexOf(flags[0])]
        : counts.join(" "),
    );
  }
  if (command === "chmod") {
    if (args.length !== 2 || !/^[0-7]{3}$/.test(args[0]))
      throw Error("chmod 600 dosya gibi üç basamaklı kip kullan.");
    const p = path(args[1]),
      f = get(lab, p);
    if (!f) throw Error("Sanal dosya yok.");
    f.mode = args[0];
    note("chmod", p, f.mode);
    return "";
  }
  if (command === "stat") {
    if (args.length !== 1) throw Error("stat dosya kullan.");
    const p = path(args[0]),
      f = get(lab, p);
    if (!f) throw Error("Sanal yol yok.");
    note("stat", p);
    return f.type + " " + f.mode + " " + modes(f.mode) + " " + f.path;
  }
  throw Error(
    "Desteklenmeyen sanal komut: " +
      command +
      ". help ile listeyi gör. Gerçek program veya ağ bağlantısı çalıştırılmaz.",
  );
}
function limits(lab) {
  if (
    lab.fs.length > 128 ||
    lab.fs.reduce((n, f) => n + f.content.length, 0) > 200000 ||
    lab.fs.some((f) => f.content.length > 32000)
  )
    throw Error(
      "Sanal dosya sistemi sınırı: 128 öğe, dosya başına 32.000 ve toplam 200.000 karakter.",
    );
}
export function runCommand(lab, line) {
  if (typeof line !== "string" || !line.trim() || line.length > 1000)
    return { lab, output: "Komut 1–1.000 karakter olmalı.", error: true };
  const next = structuredClone(lab),
    evidence = [];
  try {
    let tokens = tokenize(line),
      destination = null,
      append = false;
    const redirection = tokens.findIndex(
      (t) => t.operator && (t.value === ">" || t.value === ">>"),
    );
    if (redirection >= 0) {
      if (redirection !== tokens.length - 2)
        throw Error("Yönlendirme sonda tek sanal dosya almalı.");
      if (tokens.at(-1).operator)
        throw Error("Yönlendirme için dosya adı gerekli.");
      destination = resolvePath(next.cwd, tokens.at(-1).value);
      append = tokens[redirection].value === ">>";
      tokens = tokens.slice(0, redirection);
    }
    const groups = [[]];
    for (const token of tokens) {
      if (token.operator && token.value === "|") groups.push([]);
      else if (token.operator) throw Error("Geçersiz sanal operatör.");
      else groups.at(-1).push(token.value);
    }
    if (groups.length > 4 || groups.some((g) => !g.length))
      throw Error("En fazla 4 geçerli komut bağlanabilir.");
    if (
      groups.length > 1 &&
      groups.some(
        (g) =>
          ![
            "pwd",
            "ls",
            "cat",
            "echo",
            "grep",
            "find",
            "head",
            "tail",
            "wc",
          ].includes(g[0]),
      )
    )
      throw Error("Boru hattında yalnız okuma komutları kullanılabilir.");
    let output = "";
    for (const group of groups) {
      output = execute(next, [...group], output, evidence);
      if (output.length > 8000)
        throw Error(
          "Çıktı 8.000 karakteri aşıyor; grep, head veya tail ile sınırla.",
        );
    }
    if (destination) {
      put(next, destination, output, append);
      evidence.push({
        type: "write",
        path: destination,
        detail: output.slice(0, 1000),
      });
      output = "";
    }
    limits(next);
    next.evidence = next.evidence.concat(evidence).slice(-200);
    if (line.trim() === "clear") next.history = [];
    else next.history.push({ command: line, output, error: false });
    next.history = next.history.slice(-100);
    return { lab: next, output, error: false };
  } catch (error) {
    const failed = structuredClone(lab),
      output = error.message.slice(0, 8000);
    failed.history = failed.history
      .concat({ command: line, output, error: true })
      .slice(-100);
    return { lab: failed, output, error: true };
  }
}
const saw = (l, type, path, text = "") =>
  l.evidence.some(
    (e) => e.type === type && e.path === path && e.detail.includes(text),
  );
export const missions = [
  {
    id: "m-pwd",
    stage: 0,
    title: "Nerede olduğunu öğren",
    description: "pwd ile /home/ogrenci konumunu doğrula.",
    check: (l) => l.cwd === HOME && saw(l, "pwd", HOME),
  },
  {
    id: "m-list",
    stage: 1,
    title: "Dosyaları keşfet",
    description: "Ev klasörünün gizli öğeler dahil listesini incele (ls -a).",
    check: (l) => saw(l, "list", HOME, "all"),
  },
  {
    id: "m-create",
    stage: 2,
    title: "Proje klasörü oluştur",
    description:
      "/home/ogrenci/proje klasörü ve içinde README.txt dosyası oluştur.",
    check: (l) =>
      get(l, HOME + "/proje")?.type === "dir" &&
      get(l, HOME + "/proje/README.txt")?.type === "file",
  },
  {
    id: "m-find",
    stage: 2,
    title: "Gizli dosyayı bul",
    description: "find ile mesaj.txt dosyasının yolunu bul.",
    check: (l) =>
      l.evidence.some(
        (e) =>
          e.type === "find" && e.detail.includes(HOME + "/.arsiv/mesaj.txt"),
      ),
  },
  {
    id: "m-log",
    stage: 2,
    title: "Günlüğü filtrele",
    description: "/var/log/app.log içinde ERROR satırını grep ile bul.",
    check: (l) => saw(l, "grep", "/var/log/app.log", "ERROR E42"),
  },
  {
    id: "m-move",
    stage: 2,
    title: "Raporu düzenle",
    description:
      "Ev klasöründeki rapor.txt dosyasını proje klasörüne taşı. İçeriği koru.",
    check: (l) =>
      !get(l, HOME + "/rapor.txt") &&
      get(l, HOME + "/proje/rapor.txt")?.content ===
        "Egitim raporu: sanal dosyalar uzerinde calisildi.\n",
  },
  {
    id: "m-network",
    stage: 3,
    title: "Ağ belgelerini oku",
    description:
      "/egitim/dns.txt ve /egitim/http.txt dosyalarını cat ile incele.",
    check: (l) =>
      saw(l, "read", "/egitim/dns.txt") && saw(l, "read", "/egitim/http.txt"),
  },
  {
    id: "m-permissions",
    stage: 4,
    title: "Özel dosyayı koru",
    description:
      "/home/ogrenci/paylasim/gizli.txt için yalnız sahibine okuma/yazma izni (600) ver.",
    check: (l) => get(l, HOME + "/paylasim/gizli.txt")?.mode === "600",
  },
];
export const stages = [
  "Başlangıç",
  "Temel Komutlar",
  "Dosya Sistemi",
  "Ağ Temelleri",
  "Güvenlik Temelleri",
  "CTF Görevleri",
];
export const stageKeys = [
  "intro",
  "commands",
  "files",
  "network",
  "security",
  "ctf",
];
export function stageUnlocked(lab, index) {
  return index === 0 || lab.completed.includes("path-" + stageKeys[index - 1]);
}
export function checkMissions(state) {
  const lab = state.learning.lab,
    added = [];
  for (let stage = 0; stage < 5; stage++) {
    if (!stageUnlocked(lab, stage)) continue;
    for (const m of missions.filter((m) => m.stage === stage))
      if (!lab.completed.includes(m.id) && m.check(lab)) {
        lab.completed.push(m.id);
        added.push(m.id);
        recordEvidence(state, {
          id: "linux-mission:" + m.id,
          topic: "linux:" + stageKeys[stage],
          source: "linux",
          correct: true,
        });
      }
    if (
      missions
        .filter((m) => m.stage === stage)
        .every((m) => lab.completed.includes(m.id)) &&
      !lab.completed.includes("path-" + stageKeys[stage])
    )
      lab.completed.push("path-" + stageKeys[stage]);
  }
  return added;
}
const read = (path) => (l) => saw(l, "read", path) || saw(l, "grep", path);
export const ctfs = [
  {
    id: "hidden",
    title: "Gizli mesaj",
    topic: "linux:files",
    path: HOME + "/.arsiv/mesaj.txt",
    description: "Arşivdeki mesajdan flag'i bul ve gönder.",
    flag: "FLAG{DOSYAYI_BULDUN}",
    hint: "ls -a ve find komutları gizli klasörü bulmana yardım eder.",
    check: read(HOME + "/.arsiv/mesaj.txt"),
  },
  {
    id: "auth-log",
    title: "Şüpheli günlük",
    topic: "linux:security",
    path: "/var/log/auth.log",
    description:
      "Başarısız girişleri tekrarlayan IP'yi bul. FLAG{IP_ADRESI} biçiminde gönder.",
    flag: "FLAG{192.0.2.44}",
    hint: "grep FAIL /var/log/auth.log",
    check: read("/var/log/auth.log"),
  },
  {
    id: "permission",
    title: "Dosya izinleri",
    topic: "linux:security",
    path: HOME + "/paylasim/gizli.txt",
    description: "Dosyayı 600 kipine getir ve içindeki flag'i oku.",
    flag: "FLAG{OZEL_DOSYA}",
    hint: "chmod 600 ile yalnız dosya sahibine okuma/yazma izni ver.",
    check: (l) =>
      get(l, HOME + "/paylasim/gizli.txt")?.mode === "600" &&
      read(HOME + "/paylasim/gizli.txt")(l),
  },
  {
    id: "dns",
    title: "DNS eşleşmesi",
    topic: "linux:network",
    path: "/egitim/dns.txt",
    description:
      "calisma.example A kaydının IP'sini bul. FLAG{IP_ADRESI} biçiminde gönder.",
    flag: "FLAG{198.51.100.20}",
    hint: "cat /egitim/dns.txt",
    check: read("/egitim/dns.txt"),
  },
  {
    id: "http",
    title: "HTTP yanıtını anla",
    topic: "linux:network",
    path: "/egitim/http.txt",
    description:
      "Kurgusal HTTP yanıtındaki durum kodunu FLAG{HTTP_KOD} biçiminde gönder.",
    flag: "FLAG{HTTP_403}",
    hint: "İlk satırdaki üç basamaklı kod, isteğin sonucunu anlatır.",
    check: read("/egitim/http.txt"),
  },
  {
    id: "hash",
    title: "Hash ve şifreleme",
    topic: "linux:security",
    path: "/egitim/hash.txt",
    description: "Hash'in şifrelemeden farkını oku, dosyadaki flag'i bul.",
    flag: "FLAG{HASH_GERI_DONMEZ}",
    hint: "Hash tek yönlü bütünlük özetidir; anahtarla çözülen şifreleme değildir.",
    check: read("/egitim/hash.txt"),
  },
  {
    id: "password",
    title: "Güvenli parola ilkesi",
    topic: "linux:security",
    path: "/egitim/parola.txt",
    description: "Kurgusal parola ilkesindeki flag'i bul. Gerçek parola girme.",
    flag: "FLAG{UZUN_VE_BENZERSIZ}",
    hint: "Uzunluk ve hesaplar arasında benzersizlik birlikte önemlidir.",
    check: read("/egitim/parola.txt"),
  },
  {
    id: "authorization",
    title: "Kimlik mi, yetki mi?",
    topic: "linux:security",
    path: "/egitim/yetki.json",
    description:
      "Kimliği bilinen öğrencinin yönetici paneline neden alınmadığını incele, flag'i bul.",
    flag: "FLAG{YETKILENDIRME}",
    hint: "authenticated=true, bütün işlemlere yetki verildiği anlamına gelmez.",
    check: read("/egitim/yetki.json"),
  },
  {
    id: "address",
    title: "Ağ adresini ayırt et",
    topic: "linux:network",
    path: "/egitim/ag.txt",
    description:
      "Belgede dokümantasyon için ayrılan örnek IP'yi FLAG{IP_ADRESI} biçiminde gönder.",
    flag: "FLAG{192.0.2.10}",
    hint: "Özel ağ adresi ile dokümantasyon örneği aynı kategori değildir.",
    check: read("/egitim/ag.txt"),
  },
  {
    id: "web",
    title: "Web girdisini veri olarak tut",
    topic: "linux:security",
    path: "/egitim/web.txt",
    description:
      "Tehlikeli HTML ile güvenli metin gösterimini karşılaştır, flag'i bul.",
    flag: "FLAG{XSS_KACIS}",
    hint: "Kullanıcı girdisi HTML olarak çalıştırılmadan kaçış uygulanarak gösterilir.",
    check: read("/egitim/web.txt"),
  },
];
export function submitFlag(state, id, value) {
  const lab = state.learning.lab,
    c = ctfs.find((c) => c.id === id);
  if (!c || !stageUnlocked(lab, 5))
    throw Error("Önce öğrenme yolundaki temel görevleri tamamla.");
  if (typeof value !== "string" || value.length > 100)
    throw Error("Flag en fazla 100 karakter olmalı.");
  const done = lab.ctf.find((x) => x.id === id);
  if (done) return { correct: true, already: true, score: done.score };
  const correct = value.trim() === c.flag && c.check(lab);
  recordEvidence(state, {
    id: "ctf:" + crypto.randomUUID(),
    topic: c.topic,
    source: "ctf",
    correct,
    weight: correct ? 1 : 0.25,
    question: {
      id: "ctf-review:" + id,
      type: "short",
      text: c.title + ": " + c.description,
      answers: [c.flag],
      explain: c.hint,
      tag: c.title,
    },
  });
  if (correct)
    lab.ctf.push({
      id,
      date: localDay(),
      score: lab.hints.includes(id) ? 80 : 100,
    });
  if (lab.ctf.length === ctfs.length && !lab.completed.includes("path-ctf"))
    lab.completed.push("path-ctf");
  return {
    correct,
    already: false,
    score: correct ? (lab.hints.includes(id) ? 80 : 100) : 0,
    message: correct
      ? "Görev doğrulandı."
      : value.trim() === c.flag
        ? "Flag doğru; istenen sanal dosya incelemesi veya izin durumu henüz doğrulanmadı."
        : "Flag eşleşmedi; dosya ve ipuçlarını yeniden incele.",
  };
}
