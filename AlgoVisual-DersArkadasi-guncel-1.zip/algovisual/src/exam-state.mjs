import { examConfigs, examConfigVersions, fields, languages, getConfig, profileTopics, totalQuestions, topicStatuses, mistakeReasons, comparisonSignature } from './exam-config.mjs';
export const newExamCoach = () => ({version:1,profiles:[],activeProfileId:null,progress:[],sessions:[],results:[],mistakes:[],bank:[],autoMistakes:true,weeklyReports:[]});
const str=(x,n=200)=>typeof x==='string'&&x.length<=n;
const id=x=>str(x,100)&&/^[\w:.-]+$/.test(x);
const number=(x,a,b)=>Number.isFinite(x)&&x>=a&&x<=b;
const integer=(x,a,b)=>Number.isInteger(x)&&number(x,a,b);
const list=(x,n)=>Array.isArray(x)&&x.length<=n;
const stamp=x=>Number.isSafeInteger(x)&&x>=0;
const date=x=>str(x,10)&&/^\d{4}-\d{2}-\d{2}$/.test(x)&&new Date(x+'T12:00:00Z').toISOString().slice(0,10)===x;
function assert(ok,field){if(!ok)throw Error('SınavKoçu yedeği geçersiz: '+field);}
const unique = xs => new Set(xs).size===xs.length;
export function validateProfile(p) {
  assert(p&&id(p.id)&&Object.hasOwn(examConfigs,p.exam)&&Object.hasOwn(examConfigVersions,p.configVersion)&&date(p.targetDate)&&integer(p.dailyMinutes,5,480)&&list(p.workDays,7)&&p.workDays.length>0&&p.workDays.every(x=>integer(x,0,6))&&unique(p.workDays)&&integer(p.level,0,100)&&typeof p.enabled==='boolean'&&str(p.title,100)&&p.title.trim(),'profil');
  assert((p.exam!=='AYT'||Object.hasOwn(fields,p.field))&&(p.exam!=='YDT'||Object.hasOwn(languages,p.language)),'alan veya dil');
  const config=getConfig(p);
  assert(number(p.targetNet,0,totalQuestions(config))&&list(p.subjects,20)&&p.subjects.length>0&&unique(p.subjects)&&p.subjects.every(x=>config.subjects.some(s=>s.id===x)),'hedef');
  return p;
}
export function coachCatalog(state) {
  return (state.examCoach?.profiles || []).filter(p=>p.enabled).flatMap(p=>profileTopics(p).filter(t=>p.subjects.includes(t.subject)).map(t=>({id:t.key,label:`${p.title} · ${t.subjectLabel} — ${t.label}`,subject:`${p.title} · ${t.subjectLabel}`,route:'examcoach/topics/'+t.subject+'/'+p.id,minutes:t.difficulty===3?25:20,prerequisites:[],examProfile:p.id,examTopic:t.id,examSubject:t.subject,difficulty:t.difficulty})));
}
export function topicProgress(state,key) {return state.examCoach?.progress.find(x=>x.key===key);}
export function coachPriority(state,topic,date,days) {
  const p=state.examCoach?.profiles.find(p=>p.id===topic.examProfile);
  if(!p)return {points:0,reasons:[]};
  const row=topicProgress(state,topic.id), reasons=[];
  let points=25;
  if(row?.status==='done')points-=25;
  if(row?.status==='weak'){points+=32;reasons.push('Bu konuyu eksik olarak işaretledin.');}
  if(row?.status==='review'){points+=26;reasons.push('Bu konu için tekrar istedin.');}
  if(!row||row.status==='new')reasons.push('Konu henüz çalışılmadı; başlangıç gerekiyor.');
  if(row?.status==='studying'){points+=8;reasons.push('Başladığın konuyu sürdür.');}
  if(days>=0){points+=Math.round(35/(1+days/20));reasons.push(`Hedef tarihe ${days} gün kaldı.`);}
  const observations=state.learning.topics.find(t=>t.id===topic.id);
  if(observations){const n=observations.successes+observations.failures;if(n>=5&&observations.failures/n>.4){points+=Math.min(25,Math.round(25*observations.failures/n));reasons.push(`${n.toFixed(1)} ağırlıklı gözlem eksik çalışmasını destekliyor.`);}else if(n<5)reasons.push('Örneklem küçük; kesin eksik yargısı yok.');}
  const wrong=state.examCoach.mistakes.filter(m=>m.profileId===p.id&&m.topicKey===topic.id&&!m.history.some(h=>h.correct));
  if(wrong.length){points+=Math.min(20,wrong.length*5);reasons.push(`${wrong.length} soru henüz doğru yeniden çözülmedi.`);}
  const results=state.examCoach.results.filter(r=>r.profileId===p.id).slice(-3);
  const rows=results.flatMap(r=>r.subjects.filter(s=>s.id===topic.examSubject));
  const total=rows.reduce((n,r)=>n+r.total,0),correct=rows.reduce((n,r)=>n+r.correct,0);
  if(total>=5&&correct/total<.6){points+=Math.round((1-correct/total)*22);reasons.push(`Son ders sonuçlarında ${total} soruda ${correct} doğru; konu ayrıntısı olmayan denemeden konu hatası varsayılmadı.`);}
  const full=results.filter(r=>r.kind==='full').at(-1);
  if(full&&full.net<p.targetNet){points+=5;reasons.push(`Son tam deneme ile hedef arasında ${(p.targetNet-full.net).toFixed(2)} net var.`);}
  if(topic.difficulty===3&&days>30){points+=4;reasons.push('Zor konu için erken çalışma payı.');}
  if(p.level<30&&topic.difficulty===3){points-=8;reasons.push('Hazırlık beyanın başlangıç düzeyinde; temel konulara öncelik payı.');}
  if(days>=0&&days<=14){if(row?.status==='review'||observations){points+=10;reasons.push('Son iki haftada ölçüm ve tekrar ağırlığı.');}else points-=8;}
  if(row?.lastStudy&&date>row.lastStudy){const age=Math.floor((Date.parse(date)-Date.parse(row.lastStudy))/86400000);if(age>10){points+=Math.min(12,Math.floor(age/3));reasons.push(`Son konu çalışmasının üzerinden ${age} gün geçti.`);}}
  return {points,reasons};
}
export function validateExamCoach(s,validateQuestion) {
  if(s===undefined)return;
  assert(s&&s.version===1&&typeof s.autoMistakes==='boolean','sürüm');
  assert(list(s.profiles,12)&&unique(s.profiles.map(p=>p.id)),'profiller');
  s.profiles.forEach(validateProfile);
  assert(s.activeProfileId===null||s.profiles.some(p=>p.id===s.activeProfileId),'etkin profil');
  const profile=id=>s.profiles.find(p=>p.id===id);
  const keys=new Set(s.profiles.flatMap(p=>profileTopics(p).map(t=>t.key)));
  assert(list(s.progress,5000)&&unique(s.progress.map(x=>x.key))&&s.progress.every(x=>keys.has(x.key)&&Object.hasOwn(topicStatuses,x.status)&&date(x.updated)&& (x.lastStudy===null||date(x.lastStudy))),'konu ilerlemesi');
  const validMeta=q=>validateQuestion(q)&&id(q.subjectId)&&id(q.topicId)&&keys.has(q.topicKey)&&s.profiles.some(p=>profileTopics(p).some(t=>t.key===q.topicKey&&t.subject===q.subjectId&&t.id===q.topicId));
  assert(list(s.bank,2000)&&unique(s.bank.map(x=>x.id))&&s.bank.every(q=>validMeta(q)&&profile(q.profileId)&&q.topicKey.startsWith('exam:'+q.profileId+':')&&integer(q.level,1,3)),'soru bankası');
  assert(list(s.sessions,500)&&unique(s.sessions.map(x=>x.id)),'oturumlar');
  for(const x of s.sessions){
    assert(id(x.id)&&profile(x.profileId)&&['full','subject','topic','weak','mini','custom'].includes(x.kind)&&str(x.title,200)&&['running','paused','between','done'].includes(x.status)&&list(x.questions,160)&&x.questions.length>0&&unique(x.questions.map(q=>q.id))&&x.questions.every(q=>validMeta(q)&&q.topicKey.startsWith('exam:'+x.profileId+':')),'oturum soruları');
    assert(list(x.answers,160)&&x.answers.length===x.questions.length&&x.answers.every((a,i)=>a===null||(x.questions[i].type==='choice'?integer(a,0,x.questions[i].options.length-1):x.questions[i].type==='boolean'?typeof a==='boolean':str(a,300)))&&list(x.marked,160)&&unique(x.marked)&&x.marked.every(i=>integer(i,0,x.questions.length-1))&&integer(x.index,0,x.questions.length-1),'cevaplar');
    assert(list(x.stages,2)&&x.stages.length>0&&x.stages.every(t=>id(t.id)&&str(t.label,100)&&integer(t.seconds,60,14400)&&list(t.indices,160)&&t.indices.length>0&&t.indices.every(i=>integer(i,0,x.questions.length-1)))&&unique(x.stages.flatMap(t=>t.indices))&&x.stages.flatMap(t=>t.indices).length===x.questions.length&&integer(x.stageIndex,0,x.stages.length-1)&&x.stages[x.stageIndex].indices.includes(x.index),'oturum bölümleri');
    assert(number(x.remainingMs,0,x.stages[x.stageIndex].seconds*1000)&&(x.resumedAt===null||stamp(x.resumedAt))&&((x.status==='running')===(x.resumedAt!==null))&&number(x.elapsedMs,0,28800000)&&stamp(x.startedAt)&&stamp(x.updatedAt)&&str(x.configVersion,30)&&number(x.wrongDivisor,1,100),'oturum sayacı');
    assert(getConfig({...profile(x.profileId),configVersion:x.configVersion}).wrongDivisor===x.wrongDivisor,'oturum net kuralı');
  }
  assert(s.profiles.every(p=>s.sessions.filter(x=>x.profileId===p.id&&x.status!=='done').length<=1),'birden fazla etkin oturum');
  assert(list(s.results,1000)&&unique(s.results.map(x=>x.id)),'sonuçlar');
  for(const x of s.results){
    assert(id(x.id)&&profile(x.profileId)&&str(x.title,200)&&['full','subject','topic','weak','mini','custom'].includes(x.kind)&&['internal','manual'].includes(x.source)&&stamp(x.finishedAt)&&date(x.date)&&number(x.seconds,0,28800)&&str(x.signature,20000)&&number(x.wrongDivisor,1,100)&&str(x.configVersion,30)&&list(x.subjects,20)&&x.subjects.length>0&&unique(x.subjects.map(z=>z.id)),'sonuç');
    const c=getConfig(profile(x.profileId));
    assert(getConfig({...profile(x.profileId),configVersion:x.configVersion}).wrongDivisor===x.wrongDivisor,'sonuç net kuralı');
    assert(x.subjects.every(z=>c.subjects.some(t=>t.id===z.id)&&integer(z.total,1,160)&&integer(z.correct,0,z.total)&&integer(z.wrong,0,z.total)&&integer(z.blank,0,z.total)&&z.correct+z.wrong+z.blank===z.total&&number(z.net,-160,160)&&Math.abs(z.net-(z.correct-z.wrong/x.wrongDivisor))<1e-8)&&x.subjects.reduce((n,z)=>n+z.total,0)<=160&&Math.abs(x.net-x.subjects.reduce((n,z)=>n+z.net,0))<1e-8,'net hesabı');
    assert(x.source!=='internal'||s.sessions.some(z=>z.id===x.id&&z.status==='done'&&z.profileId===x.profileId),'sonuç oturumu');
    assert(list(x.topics,500)&&x.topics.every(z=>keys.has(z.key)&&integer(z.correct,0,160)&&integer(z.wrong,0,160)&&integer(z.blank,0,160))&&list(x.marked,160)&&x.marked.every(z=>integer(z,0,159)),'konu sonucu');
    assert(x.topics.every(t=>t.key.startsWith('exam:'+x.profileId+':'))&&unique(x.topics.map(t=>t.key))&&unique(x.marked),'konu eşleşmesi');
    for(const row of x.subjects){const ts=x.topics.filter(t=>t.key.startsWith('exam:'+x.profileId+':'+row.id+':'));assert(['correct','wrong','blank'].every(k=>ts.reduce((n,t)=>n+t[k],0)<=row[k]),'konu ders toplamı');}
    assert(x.topics.every(t=>x.subjects.some(row=>t.key.startsWith('exam:'+x.profileId+':'+row.id+':'))),'sonuç dersi');
    assert(x.signature===comparisonSignature(profile(x.profileId),x.kind,x.subjects,x.configVersion,x.wrongDivisor,x.topics),'karşılaştırma kapsamı');
    if(x.kind==='full')assert(x.subjects.length===c.subjects.length&&x.subjects.every(row=>c.subjects.some(sub=>sub.id===row.id&&sub.count===row.total)),'tam deneme kapsamı');
  }
  assert(s.sessions.filter(x=>x.status==='done').every(x=>s.results.some(r=>r.id===x.id)),'tamamlanmış oturum sonucu');
  assert(list(s.mistakes,3000)&&unique(s.mistakes.map(x=>x.id))&&unique(s.mistakes.map(x=>x.profileId+':'+x.question.id)),'yanlış defteri');
  assert(s.mistakes.every(x=>id(x.id)&&profile(x.profileId)&&validMeta(x.question)&&x.question.topicKey===x.topicKey&&x.topicKey.startsWith('exam:'+x.profileId+':')&&date(x.date)&&str(x.studentAnswer,1000)&&Object.hasOwn(mistakeReasons,x.reason)&&list(x.history,1000)&&x.history.every(h=>id(h.id)&&date(h.date)&&typeof h.correct==='boolean'&&str(h.answer,1000))),'yanlış kaydı');
  assert(list(s.weeklyReports,500)&&unique(s.weeklyReports.map(x=>x.profileId+':'+x.week))&&s.weeklyReports.every(x=>profile(x.profileId)&&date(x.week)&&stamp(x.generatedAt)&&number(x.seconds,0,604800)&&integer(x.questions,0,1000000)&&list(x.improved,500)&&x.improved.every(k=>keys.has(k))&&list(x.focus,20)&&x.focus.every(k=>keys.has(k))&& (x.netChange===null||number(x.netChange,-320,320))),'haftalık rapor');
}
