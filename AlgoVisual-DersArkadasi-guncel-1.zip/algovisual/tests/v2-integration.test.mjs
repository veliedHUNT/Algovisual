import test from "node:test";
import assert from "node:assert/strict";
import { initialState, validateState } from "../src/core.mjs";
import { lessons } from "../src/content.mjs";
import { upgradeLearning, localDay, shiftDay } from "../src/learning-state.mjs";
import {
  rebuildPlan,
  deferTask,
  configureStudyTime,
  startTask,
  settleTask,
} from "../src/planner.mjs";
import {
  buildSimulation,
  predictionQuestion,
  recordPrediction,
  answerChallenge,
} from "../src/playground.mjs";
import { rateCard } from "../src/review-engine.mjs";
import { createLab, runCommand } from "../src/linux-lab.mjs";
const date = "2026-10-22";
function state() {
  const s = initialState();
  s.lessons = structuredClone(lessons);
  return s;
}
test("Binary Search yanlışından tekrar, plan, başarı ve yeni aralık zinciri çalışır", () => {
  const s = state(),
    t = buildSimulation("binary", "1,3,5,7", "5"),
    q = predictionQuestion(t, 0);
  recordPrediction(s, t, 0, (q.answer + 1) % q.options.length);
  upgradeLearning(s);
  assert.equal(s.review[0].topic, "algo:binary");
  const today = localDay(),
    p = rebuildPlan(s, today);
  assert.ok(
    p.tasks.some((t) => t.topic === "algo:binary" && t.kind === "review"),
  );
  const before = s.learning.topics.find(
    (t) => t.id === "algo:binary",
  ).successes;
  rateCard(s, s.review[0].id, 4);
  assert.ok(
    s.learning.topics.find((t) => t.id === "algo:binary").successes > before,
  );
  assert.ok(s.review[0].due > today);
  validateState(s);
});
test("Bütçe küçülürken tamamlanmış veya elle kilitli görev silinmez ve süre sessizce aşılmaz", () => {
  const s = state(),
    p = rebuildPlan(s, date);
  p.tasks[0].status = "done";
  const before = JSON.stringify(p.tasks[0]),
    daily = s.settings.dailyMinutes;
  assert.throws(
    () => configureStudyTime(s, 5, Array(7).fill(null), date),
    /aşıyor/,
  );
  assert.equal(s.settings.dailyMinutes, daily);
  assert.equal(JSON.stringify(p.tasks[0]), before);
});
test("Ertelenen görev yalnız bir kez taşınır; tamamlandıktan sonra her gün dirilmez", () => {
  const s = state(),
    p = rebuildPlan(s, date),
    id = p.tasks[0].id;
  deferTask(s, date, id);
  const next = rebuildPlan(s, shiftDay(date, 1));
  const carried = next.tasks.find((t) => t.id.startsWith("carry:"));
  assert.ok(carried);
  carried.status = "done";
  const following = rebuildPlan(s, shiftDay(date, 2));
  assert.ok(!following.tasks.some((t) => t.id === carried.id));
});
test("Sığmayan erteleme sanal bütçeyi aşırmaz ve kaybolmaz", () => {
  const s = state(),
    p = rebuildPlan(s, date),
    first = p.tasks[0];
  deferTask(s, date, first.id);
  const next = rebuildPlan(s, shiftDay(date, 1));
  next.tasks = [
    { ...next.tasks[0], id: "manual:locked", manual: true, minutes: 30 },
  ];
  const queued = p.tasks.find((t) => t.id === first.id);
  delete queued.carriedTo;
  const updated = rebuildPlan(s, shiftDay(date, 1));
  assert.equal(
    updated.tasks.reduce((n, t) => n + t.minutes, 0),
    30,
  );
  assert.equal(queued.status, "deferred");
  assert.equal(queued.carriedTo, undefined);
});
test("Tamamlanan molalar yeniden hesaplamada yinelenen görev kimliği oluşturmaz", () => {
  const s = state();
  s.settings.dailyMinutes = 180;
  const p = rebuildPlan(s, date);
  const rest = p.tasks.find((t) => t.kind === "break");
  rest.status = "done";
  for (let i = 0; i < 4; i++) rebuildPlan(s, date);
  assert.equal(new Set(p.tasks.map((t) => t.id)).size, p.tasks.length);
  validateState(s);
});
test("Gece yarısı ve geç dönülen sayaç, süreyi gerçek başlangıç günlerine böler", () => {
  const s = state(),
    p = rebuildPlan(s, date),
    task = p.tasks[0];
  task.minutes = 20;
  const start = new Date(2026, 9, 22, 23, 50).getTime();
  startTask(s, date, task.id, start);
  settleTask(s, "done", start + 3 * 3600000); // Only the first twenty minutes count.
  assert.equal(
    s.sessions.reduce((n, x) => n + x.seconds, 0),
    1200,
  );
  assert.equal(s.sessions.find((x) => x.date === date).seconds, 600);
  assert.equal(s.sessions.find((x) => x.date === "2026-10-23").seconds, 600);
});
test("Başka günün aynı kimlikli görevi çalışan görev diye yanlışlıkla kilitlenmez", () => {
  const s = state(),
    p = rebuildPlan(s, date);
  startTask(s, date, p.tasks[0].id, new Date(date + "T12:00:00").getTime());
  const tomorrow = rebuildPlan(s, shiftDay(date, 1));
  const old = tomorrow.tasks[0];
  tomorrow.tasks[0] = { ...old, title: "değişmesi gereken otomatik başlık" };
  rebuildPlan(s, shiftDay(date, 1));
  assert.ok(
    !tomorrow.tasks.some(
      (t) => t.title === "değişmesi gereken otomatik başlık",
    ),
  );
});
test("Sanal terminal tırnak içindeki operatörleri komut olarak yorumlamaz", () => {
  let lab = createLab();
  for (const command of ['echo ">" > simge.txt', 'echo "|" >> simge.txt']) {
    const r = runCommand(lab, command);
    assert.equal(r.error, false);
    lab = r.lab;
  }
  assert.equal(runCommand(lab, "cat simge.txt").output, ">\n|\n");
});
test("Find yıldız desenleri sınırlı dinamik programla eşleşir; regex geri izleme yoktur", () => {
  const lab = createLab();
  assert.equal(
    runCommand(lab, 'find . -name "' + "*".repeat(90) + 'x"').error,
    false,
  );
  assert.ok(
    runCommand(lab, 'find . -name "*.txt"').output.includes("hosgeldin.txt"),
  );
});
test("Bozuk tekrar parametresi, takvim tarihi ve sanal yol yedekte reddedilir", () => {
  const s = state();
  s.review = [
    { id: "r", question: s.lessons[0].quiz[0], due: date, interval: 1 },
  ];
  upgradeLearning(s);
  s.review[0].srs.ease = 0;
  assert.throws(() => validateState(s), /algoritması/);
  s.review[0].srs.ease = 2.5;
  s.review[0].due = "2026-02-31";
  assert.throws(() => validateState(s), /Tekrar verisi/);
  s.review[0].due = date;
  s.learning.lab = createLab();
  s.learning.lab.fs[1].path = "//home";
  assert.throws(() => validateState(s), /sanal dosya/);
});
test("Başarılmış algoritma görevinden tekrar tekrar hâkimiyet puanı kazanılamaz", () => {
  const s = state();
  answerChallenge(s, "binary-mid", 1);
  const count = s.learning.events.length;
  answerChallenge(s, "binary-mid", 1);
  assert.equal(s.learning.events.length, count);
});
