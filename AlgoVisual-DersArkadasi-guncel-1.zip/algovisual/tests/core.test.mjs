import test from "node:test";
import assert from "node:assert/strict";
import {
  initialState,
  validateState,
  validateQuestion,
  validateTest,
  startAttempt,
  finalizeAttempt,
  gradeAnswer,
  day,
  addDays,
  reschedule,
  documentTools,
  migrateLegacy,
  stats,
  syntaxCheck,
  esc,
} from "../src/core.mjs";
import { buildTrace } from "../src/algorithms.mjs";
import { lessons } from "../src/content.mjs";
const choice = {
  id: "q1",
  type: "choice",
  text: "2 + 2?",
  options: ["3", "4", "5", "6"],
  answer: 1,
  explain: "2 + 2 = 4",
  tag: "Toplama",
};
const short = {
  id: "q2",
  type: "short",
  text: "Sözcük?",
  answers: ["İstanbul", "İSTANBUL"],
  explain: "Anahtar",
};
const boolean = {
  id: "q3",
  type: "boolean",
  text: "2 > 1",
  answer: true,
  explain: "Karşılaştırma",
};
const sample = {
  id: "test1",
  title: "Örnek",
  subject: "Matematik",
  minutes: 1,
  questions: [choice, short, boolean],
};

test("Yerel takvim tarihi UTC kayması olmadan hesaplanır", () => {
  assert.equal(day(new Date(2026, 9, 22, 0, 15)), "2026-10-22");
  assert.equal(addDays("2026-12-31", 1), "2027-01-01");
});
test("Başlangıç ve tüm içerik veri modeline uygundur", () => {
  const s = initialState();
  s.lessons = lessons;
  assert.equal(validateState(s), s);
  assert.ok(lessons.length >= 18);
  for (const l of lessons) {
    assert.ok(l.goal && l.body && l.exercise && l.example && l.quiz.length);
    for (const p of l.prerequisites) assert.ok(lessons.some((x) => x.id === p));
  }
});
test("Üç soru türü ve kabul edilen kısa cevaplar doğru puanlanır", () => {
  assert.ok([choice, short, boolean].every(validateQuestion));
  assert.equal(gradeAnswer(choice, 1), true);
  assert.equal(gradeAnswer(choice, "1"), false);
  assert.equal(gradeAnswer(short, "  istanbul "), true);
  assert.equal(gradeAnswer(short, "Ankara"), false);
  assert.equal(gradeAnswer(boolean, false), false);
  assert.equal(gradeAnswer(boolean, true), true);
  assert.equal(gradeAnswer(boolean, null), false);
});
test("Hatalı seçenek ve boş cevap anahtarı reddedilir", () => {
  assert.equal(validateQuestion({ ...choice, answer: 9 }), false);
  assert.equal(validateQuestion({ ...short, answers: [] }), false);
  assert.equal(validateQuestion({ ...choice, id: '" onload=x' }), false);
  assert.equal(validateTest({ ...sample, questions: [choice, choice] }), false);
});
test("Test snapshotı orijinalden bağımsızdır, süre ve boşlar hesaplanır", () => {
  const a = startAttempt(sample, false, 1000);
  a.answers = [1, "Ankara"];
  const result = finalizeAttempt(a, 16000);
  assert.equal(result.correct, 1);
  assert.equal(result.total, 3);
  assert.equal(result.seconds, 15);
  assert.equal(a.deadline, 61000);
  assert.equal(result.results[2].answer, null);
  a.test.questions[0].text = "değişti";
  assert.equal(sample.questions[0].text, "2 + 2?");
});
test("Karışık test tüm soruları tam bir kez içerir", () => {
  const a = startAttempt(sample, true);
  assert.deepEqual(a.test.questions.map((q) => q.id).sort(), [
    "q1",
    "q2",
    "q3",
  ]);
});
test("Gerçek cevaplardan konu başarıları hesaplanır", () => {
  const s = initialState();
  assert.equal(stats(s).rate, null);
  const a = startAttempt(sample);
  a.answers = [1, "Ankara", true];
  s.attempts = [finalizeAttempt(a)];
  assert.equal(stats(s).rate, 67);
  assert.equal(stats(s).topics.Toplama.correct, 1);
});
test("Aralıklı tekrarda başarı aralığı büyütür; hata bugüne alır", () => {
  let r = { interval: 0 };
  r = reschedule(r, true, "2026-10-22");
  assert.equal(r.due, "2026-10-23");
  r = reschedule(r, true, "2026-10-23");
  assert.equal(r.interval, 2);
  assert.equal(reschedule(r, false, "2026-10-23").due, "2026-10-23");
  assert.equal(reschedule({ interval: 179 }, true).interval, 180);
});
test("PDF soru taslağı ve özet kaynak sayfasını korur", () => {
  const t = documentTools([
    "Fonksiyonlar her girdiyi yalnızca bir çıktıya eşleyen kurallardır.",
    "Algoritmalar bir problemi çözmek için sonlu adımlar kullanır.",
  ]);
  assert.equal(t.questions.length, 2);
  assert.equal(t.questions[1].source.page, 2);
  assert.ok(t.questions.every(validateQuestion));
  assert.ok(t.summary[0].text.includes("Fonksiyonlar"));
  assert.deepEqual(documentTools([""]).questions, []);
});
test("Eski sürüm sonuç ve testleri kaybetmeden aktarılır", () => {
  const s = migrateLegacy({
    tests: [
      {
        title: "Eski",
        questions: [{ text: "?", options: ["A", "B", "C", "D"], correct: "B" }],
      },
    ],
    attempts: [{ title: "Eski", correct: 1, total: 2, date: Date.now() }],
    lessons: [
      {
        id: "l1",
        title: "Python",
        subject: "Yazılım",
        level: "Başlangıç",
        done: true,
      },
    ],
  });
  assert.equal(s.tests[0].questions[0].answer, 1);
  assert.equal(s.attempts[0].correct, 1);
  assert.equal(s.completed.length, 1);
  assert.ok(validateState(s));
});
test("JSON yedek turu ve bozuk veri doğrulaması", () => {
  const s = initialState();
  s.tests = [sample];
  assert.deepEqual(validateState(JSON.parse(JSON.stringify(s))), s);
  assert.throws(() =>
    validateState({ ...s, notes: [{ id: "bad", text: [], target: "x" }] }),
  );
  assert.throws(() =>
    validateState({
      ...s,
      attempts: [
        {
          id: "a",
          title: "x",
          correct: 10,
          total: 2,
          date: Date.now(),
          results: [],
        },
      ],
    }),
  );
  assert.throws(() =>
    validateState({
      ...s,
      tests: [{ ...sample, questions: [{ ...short, answers: [] }] }],
    }),
  );
});
test("Algoritma boş, negatif ve sınır girdilerini doğru yürütür", () => {
  assert.equal(buildTrace("loop", "1,2,3").steps.at(-1).output, "6");
  assert.equal(buildTrace("loop", "").steps.at(-1).output, "0");
  assert.equal(buildTrace("loop", "-2,0,5").steps.at(-1).output, "3");
  assert.equal(buildTrace("condition", "18").steps.at(-1).output, "Reşit");
  assert.equal(buildTrace("variables", "4").steps.at(-1).output, "5 8");
  assert.equal(buildTrace("function", "-4").steps.at(-1).output, "-8");
  assert.throws(() => buildTrace("loop", "no"));
  assert.throws(() => buildTrace("condition", "-1"));
});
test("Geri adım için snapshotlar birbirinden bağımsızdır", () => {
  const trace = buildTrace("loop", "1,2");
  assert.equal(trace.steps[1].vars.toplam, 0);
  assert.equal(trace.steps.at(-1).vars.toplam, 3);
  assert.ok(
    trace.steps.every((s) => s.line >= 1 && s.line <= trace.code.length),
  );
});
test("Temel sözdizimi denetimi gerçek hataları ve metinleri ayırır", () => {
  assert.ok(syntaxCheck("if x\n    print(x)", "python").length);
  assert.ok(syntaxCheck("int main( {", "c").length);
  assert.equal(syntaxCheck('print("(")', "python").length, 0);
  assert.equal(
    syntaxCheck("/* ( */ int main(void) { return 0; }", "c").length,
    0,
  );
});
test("Kullanıcı HTML girdisi yürütülebilir işaretleme oluşturmaz", () => {
  assert.equal(esc('<img onerror="x">'), "&lt;img onerror=&quot;x&quot;&gt;");
});

test("İçe aktarılan kaynak sayfası ve kimlikler HTML içeremez", () => {
  assert.equal(
    validateQuestion({ ...choice, source: { page: "<img src=x>", text: "x" } }),
    false,
  );
  assert.throws(() => migrateLegacy({ other: "x" }));
  const s = initialState();
  s.favorites = ["a", "a"];
  assert.throws(() => validateState(s));
});
test("Konu etiketi nesne prototipine yazamaz", () => {
  const s = initialState(),
    a = startAttempt({
      ...sample,
      questions: [{ ...choice, tag: "__proto__" }],
    });
  a.answers = [1];
  s.attempts = [finalizeAttempt(a)];
  assert.equal(stats(s).topics.__proto__.correct, 1);
  assert.equal(Object.prototype.correct, undefined);
});
