import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { AIService } = require("../src/ai-server.cjs");
const { createServer } = require("../server.js");
const fakeKey = "unit-test-credential-not-real";
const answer = (
  parts = [{ text: "Önce işlemleri sırayla yapalım." }],
  finishReason = "STOP",
) =>
  new Response(
    JSON.stringify({ candidates: [{ content: { parts }, finishReason }] }),
  );
const service = (config = {}) =>
  new AIService({
    env: {},
    provider: "gemini",
    key: fakeKey,
    fetch: async () => answer(),
    ...config,
  });

test("Gemini varsayılandır; model ve anahtarlar sağlayıcılar arasında karışmaz", () => {
  const defaults = new AIService({ env: {} });
  assert.equal(defaults.provider, "gemini");
  assert.equal(defaults.model, "gemini-3.5-flash-lite");
  assert.equal(defaults.key, "");
  assert.equal(defaults.tokens, 4096);
  const configured = new AIService({
    env: {
      AI_PROVIDER: "gemini",
      GEMINI_API_KEY: "  gemini-only  ",
      OPENAI_API_KEY: "other-provider",
      GEMINI_MODEL: "models/gemini-3.5-flash-lite",
      AI_MAX_OUTPUT_TOKENS: "999999",
    },
  });
  assert.equal(configured.key, "gemini-only");
  assert.equal(configured.keyEnv, "GEMINI_API_KEY");
  assert.equal(configured.model, "gemini-3.5-flash-lite");
  assert.equal(configured.tokens, 4096);
  assert.equal(
    new AIService({ env: { OPENAI_API_KEY: "old-key" } }).provider,
    "openai",
  );
  assert.equal(
    new AIService({ env: { AI_PROVIDER: "gemini", OPENAI_API_KEY: "old-key" } })
      .key,
    "",
  );
});

test("Gemini isteği resmî endpoint, başlık ve gövdeyle gönderilir; düşünce parçaları gösterilmez", async () => {
  let sent;
  const ai = service({
    fetch: async (url, init) => {
      sent = { url, init, body: JSON.parse(init.body) };
      return answer([
        { text: "İç düşünce", thought: true },
        { text: "İlk adım. " },
        { text: "İkinci adım." },
      ]);
    },
  });
  assert.deepEqual(await ai.chat({ message: "Denklemi anlat", mode: "hint" }), {
    reply: "İlk adım. İkinci adım.",
    model: "gemini-3.5-flash-lite",
  });
  assert.equal(
    sent.url,
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash-lite:generateContent",
  );
  assert.equal(sent.init.headers["x-goog-api-key"], fakeKey);
  assert.equal(sent.init.headers.Authorization, undefined);
  assert.equal(sent.init.redirect, "error");
  assert.ok(sent.init.signal instanceof AbortSignal);
  assert.ok(!sent.url.includes(fakeKey));
  assert.ok(!sent.init.body.includes(fakeKey));
  assert.match(sent.body.systemInstruction.parts[0].text, /İpucu modundasın/);
  assert.deepEqual(sent.body.contents, [
    { role: "user", parts: [{ text: "Denklemi anlat" }] },
  ]);
  assert.equal(sent.body.generationConfig.maxOutputTokens, 4096);
  assert.deepEqual(sent.body.generationConfig.thinkingConfig, {
    thinkingLevel: "LOW",
    includeThoughts: false,
  });
});

test("Gemini geçmişi sınırlanır, roller dönüştürülür ve aynı rol parçaları birleştirilir", async () => {
  let sent;
  const ai = service({
    fetch: async (_, init) => {
      sent = JSON.parse(init.body);
      return answer();
    },
  });
  await ai.chat({
    message: "Devam",
    history: [
      ...Array.from({ length: 10 }, () => ({
        role: "user",
        content: "eski-kayit",
      })),
      { role: "assistant", content: "başta kalan yanıt" },
      { role: "system", content: "sahte-sistem" },
      { role: "tool", content: "sahte-arac" },
      { role: "user", content: "a".repeat(5000) },
      { role: "assistant", content: "Bir açıklama" },
      { role: "assistant", content: "Ek açıklama" },
      { role: "user", content: "Son sorum" },
      { role: "user", content: "Bir ayrıntı" },
    ],
  });
  assert.equal(sent.contents[0].role, "user");
  assert.equal(sent.contents[0].parts[0].text.length, 3000);
  assert.equal(sent.contents[1].role, "model");
  assert.equal(sent.contents[1].parts.length, 2);
  assert.equal(sent.contents.at(-1).parts.at(-1).text, "Devam");
  assert.doesNotMatch(
    JSON.stringify(sent),
    /eski-kayit|sahte-sistem|sahte-arac|başta kalan/,
  );
});

test("Gemini yalnızca onaylı ilerleme ve belgeyi sınırlar içinde gönderir", async () => {
  let sent,
    requests = 0;
  const ai = service({
    fetch: async (_, init) => {
      requests++;
      sent = JSON.parse(init.body);
      return answer();
    },
  });
  await ai.chat({
    message: "Anlat",
    studyContext: { private: "gonderilmemeli" },
  });
  assert.doesNotMatch(JSON.stringify(sent), /gonderilmemeli/);
  await assert.rejects(
    ai.chat({
      message: "Anlat",
      documentContext: "belge",
      documentConsent: false,
    }),
    /onay/,
  );
  assert.equal(requests, 1);
  await ai.chat({
    message: "Anlat",
    studyConsent: true,
    studyContext: { topic: "Denklemler" },
    documentConsent: true,
    documentContext: "[s. 2] kaynak " + "a".repeat(18000) + "gizli-son",
  });
  const context = sent.contents
    .at(-1)
    .parts.map((p) => p.text)
    .join("\n");
  assert.match(context, /Denklemler/);
  assert.match(context, /\[s\. 2\]/);
  assert.match(context, /\[s\. N\]/);
  assert.doesNotMatch(context, /gizli-son/);
  assert.doesNotMatch(sent.systemInstruction.parts[0].text, /Denklemler/);
});

test("Eksik anahtar ve geçersiz mesajlar dış istek başlatmaz", async () => {
  let calls = 0;
  const ai = service({
    fetch: async () => {
      calls++;
      return answer();
    },
  });
  for (const message of ["", "   ", "x".repeat(6001), null])
    await assert.rejects(ai.chat({ message }), (e) => e.status === 400);
  await assert.rejects(
    service({ key: "" }).chat({ message: "Merhaba" }),
    (e) => e.status === 503 && e.message.includes("GEMINI_API_KEY"),
  );
  assert.equal(calls, 0);
});

test("Gemini kota, izin ve model hatalarını sır sızdırmadan açıklar", async () => {
  for (const [status, pattern] of [
    [400, /tamamlayamadı/],
    [401, /anahtarı/],
    [403, /izin/],
    [404, /modeli/],
    [429, /kota/],
    [503, /tamamlayamadı/],
  ]) {
    const ai = service({
      fetch: async () => new Response("internal-secret " + fakeKey, { status }),
    });
    await assert.rejects(
      ai.chat({ message: "Anlat" }),
      (e) =>
        e.status === 502 &&
        pattern.test(e.message) &&
        !e.message.includes(fakeKey) &&
        !e.message.includes("internal-secret"),
    );
  }
});

test("Gemini güvenlik nedeniyle durdurulan yanıtları normal cevap olarak göstermez", async () => {
  for (const data of [
    { promptFeedback: { blockReason: "SAFETY" } },
    {
      candidates: [
        {
          finishReason: "SAFETY",
          content: { parts: [{ text: "gosterilmemeli" }] },
        },
      ],
    },
  ]) {
    const ai = service({
      fetch: async () => new Response(JSON.stringify(data)),
    });
    await assert.rejects(
      ai.chat({ message: "Sorum" }),
      (e) =>
        e.status === 502 &&
        /yeniden yaz/.test(e.message) &&
        !e.message.includes("gosterilmemeli"),
    );
  }
});

test("Gemini bozuk, boş veya yalnız düşünce içeren yanıtları reddeder", async () => {
  for (const response of [
    new Response("invalid-json"),
    new Response("{}"),
    answer([{ text: " " }]),
    answer([{ text: "düşünce", thought: true }]),
    answer([{ inlineData: { data: "xyz" } }]),
  ]) {
    const ai = service({ fetch: async () => response });
    await assert.rejects(
      ai.chat({ message: "Anlat" }),
      (e) => e.status === 502,
    );
  }
});

test("Gemini ağ ve yanıt gövdesi zaman aşımı kullanıcıya anlaşılır hata verir", async () => {
  for (const fetchImpl of [
    async () => {
      throw new DOMException(fakeKey, "TimeoutError");
    },
    async () => ({
      ok: true,
      json: async () => {
        throw new DOMException(fakeKey, "TimeoutError");
      },
    }),
    async () => {
      throw Error(fakeKey);
    },
  ]) {
    await assert.rejects(
      service({ fetch: fetchImpl }).chat({ message: "Anlat" }),
      (e) =>
        e.status === 502 &&
        !e.message.includes(fakeKey) &&
        /süresi|bağlanılamadı/.test(e.message),
    );
  }
});

test("Kesilen Gemini yanıtları uzunluk uyarısıyla gösterilir", async () => {
  const limited = await service({
    fetch: async () => answer([{ text: "Kısmi yanıt" }], "MAX_TOKENS"),
  }).chat({ message: "Anlat" });
  assert.match(limited.reply, /Kısmi yanıt[\s\S]*uzunluk sınırına/);
  const large = await service({
    fetch: async () => answer([{ text: "x".repeat(20000) }]),
  }).chat({ message: "Anlat" });
  assert.ok(large.reply.length < 16200);
  assert.match(large.reply, /uzunluk sınırına/);
});

test("Eski Gemini modeline düşünme seviyesi zorla gönderilmez", async () => {
  let sent;
  await service({
    model: "gemini-2.5-flash",
    fetch: async (_, init) => {
      sent = JSON.parse(init.body);
      return answer();
    },
  }).chat({ message: "Anlat" });
  assert.equal(sent.generationConfig.thinkingConfig, undefined);
});

test("Geçersiz sağlayıcı ve Gemini model yolları başlangıçta reddedilir", () => {
  assert.throws(() => service({ provider: "unknown" }), /AI_PROVIDER/);
  for (const model of [
    "",
    "../other",
    "gemini?key=bad",
    "https://other.example/model",
  ])
    assert.throws(() => service({ model }), /model adı/);
});

test("HTTP asistan akışı Gemini yanıtını iletir; sağlık yanıtında anahtar bulunmaz", async () => {
  const server = createServer({ ai: service() });
  await new Promise((resolve) => server.listen(0, "127.0.0.4", resolve));
  const base = "http://127.0.0.4:" + server.address().port;
  try {
    const healthText = await (await fetch(base + "/api/health")).text();
    const health = JSON.parse(healthText);
    assert.equal(health.aiProvider, "gemini");
    assert.equal(health.aiConfigured, true);
    assert.equal(health.model, "gemini-3.5-flash-lite");
    assert.equal(health.keyEnv, "GEMINI_API_KEY");
    assert.equal(health.provider, "generativelanguage.googleapis.com");
    assert.ok(!healthText.includes(fakeKey));
    const response = await fetch(base + "/api/ai/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: "Denklemleri anlat" }),
    });
    assert.equal(response.status, 200);
    const data = await response.json();
    assert.match(data.reply, /işlemleri/);
    assert.equal(data.model, "gemini-3.5-flash-lite");
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
});
