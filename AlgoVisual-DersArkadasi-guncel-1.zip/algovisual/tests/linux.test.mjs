import test from "node:test";
import assert from "node:assert/strict";
import {
  createLab,
  runCommand,
  resolvePath,
  checkMissions,
  submitFlag,
  ctfs,
  stageUnlocked,
} from "../src/linux-lab.mjs";
import { initialState, validateState } from "../src/core.mjs";
function session() {
  const s = initialState();
  s.learning.lab = createLab();
  const run = (command) => {
    const r = runCommand(s.learning.lab, command);
    s.learning.lab = r.lab;
    checkMissions(s);
    return r;
  };
  return { s, run };
}
test("Sanal dosya oluşturma/yazma/kopyalama/taşıma/silme gerçek simülasyon durumunu değiştirir", () => {
  const { s, run } = session();
  for (const command of [
    "mkdir proje",
    "touch proje/a.txt",
    "echo merhaba > proje/a.txt",
    "cp proje/a.txt proje/b.txt",
    "mv proje/b.txt proje/c.txt",
  ])
    assert.equal(run(command).error, false, command);
  assert.equal(run("cat proje/c.txt").output, "merhaba\n");
  assert.equal(run("rm proje/a.txt").error, false);
  assert.ok(!s.learning.lab.fs.some((f) => f.path.endsWith("/a.txt")));
  validateState(s);
});
test("Klasör değiştirme, kök kontrolü ve desteklenmeyen komutlar tutarlıdır", () => {
  const { s, run } = session();
  run("cd /");
  assert.equal(run("pwd").output, "/");
  assert.equal(run("cd ..").error, true);
  assert.equal(s.learning.lab.cwd, "/");
  for (const command of [
    "sudo whoami",
    "curl https://example.com",
    "node server.js",
    "cat C:/Windows/win.ini",
    "ls /__proto__",
  ])
    assert.equal(run(command).error, true, command);
  assert.throws(() => resolvePath("/", "../../etc"), /kök/);
});
test("Shell enjeksiyonları çalışmaz; tırnak içindeki HTML yalnız veridir", () => {
  const { s, run } = session();
  for (const command of [
    "echo x; touch hacked",
    "echo $(whoami)",
    "pwd && ls",
    "echo x | rm -rf /",
  ])
    assert.equal(run(command).error, true, command);
  assert.equal(
    run('echo "<img src=x onerror=alert(1)>" > ornek.txt').error,
    false,
  );
  assert.match(run("cat ornek.txt").output, /<img/);
  assert.ok(!s.learning.lab.fs.some((f) => f.path.endsWith("hacked")));
});
test("Grep, find, head, tail, wc ve boru hatları tutarlı çıktı üretir", () => {
  const { run } = session();
  assert.match(run("grep -n ERROR /var/log/app.log").output, /2:ERROR E42/);
  assert.match(run('find . -name "mesaj.txt"').output, /\.arsiv\/mesaj.txt/);
  assert.equal(run("cat /var/log/auth.log | grep FAIL | wc -l").output, "3");
  assert.match(run("head -n 1 /var/log/app.log").output, /INFO uygulama/);
  assert.equal(
    run("tail -n 1 /var/log/app.log").output,
    "INFO yeniden denendi\n",
  );
});
test("Büyük girdi ve dosya sistemi sınırı atomik biçimde uygulanır", () => {
  const { s, run } = session();
  const before = s.learning.lab.fs.length;
  assert.equal(run("x".repeat(1001)).error, true);
  let hit = false;
  for (let i = 0; i < 150; i++)
    if (run("touch a" + i).error) {
      hit = true;
      break;
    }
  assert.equal(hit, true);
  assert.ok(s.learning.lab.fs.length <= 128);
  const preserved = JSON.stringify(s.learning.lab.fs);
  assert.equal(run("mkdir -p one/two/three/four").error, true);
  assert.equal(JSON.stringify(s.learning.lab.fs), preserved);
  assert.ok(before < 128);
});
test("rm yalnız sanal dosyaları etkiler ve kök/çalışılan klasörü korur", () => {
  const { s, run } = session();
  assert.equal(run("rm -rf /").error, true);
  run("mkdir -p a/b");
  run("touch a/b/c");
  assert.equal(run("rm -r a").error, false);
  assert.ok(!s.learning.lab.fs.some((f) => f.path.includes("/a/")));
});
function unlock(run) {
  for (const command of [
    "pwd",
    "ls -a",
    "mkdir proje",
    "touch proje/README.txt",
    'find . -name "mesaj.txt"',
    "grep ERROR /var/log/app.log",
    "mv rapor.txt proje/rapor.txt",
    "cat /egitim/dns.txt",
    "cat /egitim/http.txt",
    "chmod 600 /home/ogrenci/paylasim/gizli.txt",
  ])
    assert.equal(run(command).error, false, command);
}
test("Görevler yalnız komut metniyle tamamlanmaz; gerçek sanal durum ve inceleme kanıtı gerekir", () => {
  const { s, run } = session();
  run("echo pwd");
  assert.ok(!s.learning.lab.completed.includes("m-pwd"));
  assert.equal(stageUnlocked(s.learning.lab, 5), false);
  unlock(run);
  assert.equal(stageUnlocked(s.learning.lab, 5), true);
  assert.ok(s.learning.lab.completed.includes("m-create"));
  validateState(s);
});
test("10 CTF görevinin tümü gerçek çalışma alanında tamamlanabilir; puan tekrar kazanılmaz", () => {
  const { s, run } = session();
  unlock(run);
  for (const c of ctfs) {
    run("cat " + c.path);
    assert.equal(submitFlag(s, c.id, c.flag).correct, true, c.id);
    assert.equal(submitFlag(s, c.id, c.flag).already, true, c.id);
  }
  assert.equal(s.learning.lab.ctf.length, 10);
  assert.equal(
    s.learning.lab.ctf.reduce((n, c) => n + c.score, 0),
    1000,
  );
  assert.ok(s.learning.lab.completed.includes("path-ctf"));
  validateState(s);
});
test("Doğru flag tek başına yeterli değildir; hatalı deneme ve ipucu puanı işlenir", () => {
  const { s, run } = session();
  unlock(run);
  const c = ctfs[0];
  assert.equal(submitFlag(s, c.id, c.flag).correct, false);
  assert.equal(submitFlag(s, c.id, "wrong").correct, false);
  assert.ok(s.review.length);
  s.learning.lab.hints.push(c.id);
  run("cat " + c.path);
  assert.equal(submitFlag(s, c.id, c.flag).score, 80);
});
test("Laboratuvar, dosyalar ve CTF ilerlemesi JSON turunda korunur", () => {
  const { s, run } = session();
  unlock(run);
  run("echo kayit > benim.txt");
  const restored = JSON.parse(JSON.stringify(s));
  validateState(restored);
  assert.equal(
    runCommand(restored.learning.lab, "cat benim.txt").output,
    "kayit\n",
  );
  restored.learning.lab.fs.push({
    path: "/../escape",
    type: "file",
    content: "",
    mode: "644",
  });
  assert.throws(() => validateState(restored), /sanal dosya/);
});
