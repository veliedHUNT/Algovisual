import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
const require = createRequire(import.meta.url);
const { createServer } = require("../server.js");
const { AIService } = require("../src/ai-server.cjs");
const server = createServer({ ai: new AIService({ key: "" }) });
await new Promise((resolve) => server.listen(0, "127.0.0.4", resolve));
const base = "http://127.0.0.4:" + server.address().port;
test.after(() => new Promise((resolve) => server.close(resolve)));
const post = (url, body, headers = {}) =>
  fetch(base + url, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...headers },
    body: JSON.stringify(body),
  });
test("Sunucu HTML ve modülleri güvenlik başlıklarıyla sunar", async () => {
  const r = await fetch(base);
  assert.equal(r.status, 200);
  assert.ok(
    r.headers.get("content-security-policy").includes("script-src 'self'"),
  );
  assert.match(await r.text(), /AlgoVisual/);
  assert.equal((await fetch(base + "/src/core.mjs")).status, 200);
});
test("Anahtar yokken sağlık endpointi çalışır, AI sahte yanıt vermez", async () => {
  const h = await (await fetch(base + "/api/health")).json();
  assert.equal(h.aiConfigured, false);
  const r = await post("/api/ai/chat", { message: "Merhaba" });
  assert.equal(r.status, 503);
  assert.match((await r.json()).error, /anahtar/);
});
test("Sunucu sırları, kaynak sunucu dosyası ve yedekler erişilemez", async () => {
  for (const p of [
    "/.env",
    "/env.example",
    "/server.js",
    "/README.md",
    "/package.json",
    "/tests/core.test.mjs",
    "/src/ai-server.cjs",
    "/%2e%2e/.env",
  ])
    assert.equal((await fetch(base + p)).status, 404, p);
});
test("CSRF kaynağı ve içerik türü kontrol edilir", async () => {
  assert.equal(
    (
      await post(
        "/api/ai/chat",
        { message: "x" },
        { Origin: "https://evil.example" },
      )
    ).status,
    403,
  );
  assert.equal(
    (await fetch(base + "/api/ai/chat", { method: "POST", body: "{}" })).status,
    415,
  );
  assert.equal((await fetch(base + "/%ZZ")).status, 400);
});
test("Runner yokken kod yürütme sahte çıktı üretmez", async () => {
  const r = await post("/api/code/run", { lang: "python", code: "print(1)" });
  assert.equal(r.status, 501);
  assert.match((await r.json()).error, /İzole/);
});
test("Girdi ve istek boyutu sınırları uygulanır", async () => {
  assert.equal(
    (await post("/api/code/run", { lang: "javascript", code: "x" })).status,
    400,
  );
  assert.equal(
    (await post("/api/ai/chat", { message: "x".repeat(190000) })).status,
    413,
  );
});
test("Python AST ayrıştırması sözdizimini denetler, kodu yürütmez", async () => {
  const r = await post("/api/code/check", {
      lang: "python",
      code: 'raise Exception("RUN_IF_EXECUTED")',
    }),
    d = await r.json();
  if (d.available) assert.deepEqual(d.issues, []);
  const bad = await (
    await post("/api/code/check", {
      lang: "python",
      code: "if True\n print(1)",
    })
  ).json();
  if (bad.available) assert.equal(bad.issues[0].line, 1);
});
test("İstek hızı sınırı uygulanır", async () => {
  let r;
  for (let i = 0; i < 32; i++)
    r = await post("/api/code/run", { lang: "python", code: "" });
  assert.equal(r.status, 429);
});
test("AI servis katmanı yalnızca onaylanan veriyi ve sınırlı geçmişi gönderir", async () => {
  let sent;
  const service = new AIService({
    provider: "openai",
    key: "test-key-not-real",
    fetch: async (url, init) => {
      sent = JSON.parse(init.body);
      return new Response(
        JSON.stringify({ choices: [{ message: { content: "Yanıt" } }] }),
      );
    },
  });
  const result = await service.chat({
    message: "Anlat",
    studyContext: { secret: "should-not-send" },
    history: Array.from({ length: 20 }, () => ({ role: "user", content: "x" })),
  });
  assert.equal(result.reply, "Yanıt");
  assert.equal(sent.messages.length, 10);
  assert.ok(!sent.messages[0].content.includes("should-not-send"));
  assert.ok(sent.max_completion_tokens <= 4096);
  assert.equal(sent.api_key, undefined);
  await assert.rejects(
    service.chat({
      message: "x",
      documentContext: "belge",
      documentConsent: false,
    }),
    /onay/,
  );
});
test("AI sağlayıcı hatası sır ve iç hata metnini sızdırmaz", async () => {
  const service = new AIService({
    provider: "openai",
    key: "secret",
    fetch: async () =>
      new Response(
        JSON.stringify({ error: { message: "secret confidential" } }),
        { status: 401 },
      ),
  });
  await assert.rejects(
    service.chat({ message: "x" }),
    (err) => !err.message.includes("confidential") && err.status === 502,
  );
});
