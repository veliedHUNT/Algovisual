import test from "node:test";
import assert from "node:assert/strict";
import { lessons, schoolSubjects, reconcileLessons } from "../src/content.mjs";
import {
  initialState,
  validateState,
  validateQuestion,
  gradeAnswer,
  startAttempt,
  finalizeAttempt,
} from "../src/core.mjs";

// Önceki içerik örneği yalnız geçiş kontrolü için eski sürüm alanlarıyla kurulur.
const originalMath = {
  id: "math9",
  area: "school",
  subject: "Matematik",
  grade: "9",
  unit: "Sayılar",
  title: "Üslü ifadeler",
  goal: "Üs kavramını açıklayıp aynı tabanlı çarpımları çözebilmek.",
  body: "aⁿ, a sayısının n kez çarpılmasıdır (n pozitif tam sayı). Aynı tabanlı çarpımda üsler toplanır: aᵐ · aⁿ = aᵐ⁺ⁿ. Sıfırdan farklı a için a⁰ = 1. Negatif üs, tersini ifade eder: a⁻ⁿ = 1/aⁿ. Parantez önemlidir: (−2)² = 4, ancak −2² = −4.",
  example: "2³ · 2² = 2⁵ = 32.\n3⁻² = 1/9.",
  exercise:
    "5² · 5³ ifadesini tek üs olarak yaz. Sonra (−3)² ile −3² arasındaki farkı açıkla.",
  quiz: [
    {
      id: "m91",
      type: "choice",
      text: "2³ · 2² kaçtır?",
      options: ["12", "16", "32", "64"],
      answer: 2,
      explain: "Tabanlar aynı: üsler 3 + 2 = 5 olur; 2⁵ = 32.",
      difficulty: "Başlangıç",
      tag: "Üslü ifadeler",
    },
    {
      id: "m92",
      type: "choice",
      text: "Sıfırdan farklı a için a⁰ nedir?",
      options: ["0", "1", "a", "Tanımsız"],
      answer: 1,
      explain: "Sıfırdan farklı bir sayının sıfırıncı kuvveti 1’dir.",
      difficulty: "Başlangıç",
      tag: "Üslü ifadeler",
    },
  ],
  prerequisites: [],
  status: "Özgün başlangıç içeriği · resmî müfredat eşlemesi doğrulanmadı",
};

test("43 konu ve 172 soru veri modeline uygundur", () => {
  const state = initialState();
  state.lessons = structuredClone(lessons);
  validateState(state);
  assert.equal(lessons.length, 43);
  assert.equal(lessons.filter((l) => l.area === "school").length, 30);
  assert.equal(
    lessons.reduce((n, l) => n + l.quiz.length, 0),
    172,
  );
  for (const l of lessons) {
    assert.ok(l.body.length >= 700, l.id);
    assert.ok(l.example.length >= 100, l.id);
    assert.ok(l.exercise.length >= 100, l.id);
    assert.equal(l.quiz.length, 4, l.id);
    assert.ok(l.quiz.every(validateQuestion), l.id);
    assert.ok(
      l.quiz.every((q) => q.explain.trim().length >= 20),
      l.id,
    );
  }
});

test("On okul dersinin tamamında destek içeriği bulunur; felsefe 10. sınıftadır", () => {
  const school = lessons.filter((l) => l.area === "school");
  for (const name of schoolSubjects)
    assert.ok(
      school.some((l) => l.subject === name),
      name,
    );
  assert.ok(school.every((l) => ["9", "10"].includes(l.grade)));
  assert.ok(
    school
      .filter((l) => l.subject === "Felsefe")
      .every((l) => l.grade === "10"),
  );
  assert.ok(school.every((l) => l.status.includes("doğrulanmamıştır")));
});

test("Konu ve soru kimlikleri benzersizdir; seçenekler tekrarsızdır", () => {
  assert.equal(new Set(lessons.map((l) => l.id)).size, lessons.length);
  const questions = lessons.flatMap((l) => l.quiz);
  assert.equal(new Set(questions.map((q) => q.id)).size, questions.length);
  for (const q of questions)
    assert.equal(new Set(q.options).size, q.options.length, q.id);
});

test("Ön koşullar mevcut ve döngüsüzdür", () => {
  const byId = new Map(lessons.map((l) => [l.id, l]));
  function visit(id, path = new Set()) {
    assert.ok(!path.has(id), "Ön koşul döngüsü: " + id);
    const next = new Set(path);
    next.add(id);
    for (const prerequisite of byId.get(id).prerequisites) {
      assert.ok(byId.has(prerequisite));
      visit(prerequisite, next);
    }
  }
  lessons.forEach((l) => visit(l.id));
});

test("Eski standart konu aynı kimlikle zenginleşir; girdi nesnesi değişmez", async () => {
  const source = structuredClone(originalMath),
    snapshot = structuredClone(source);
  const result = await reconcileLessons([source]);
  assert.equal(result.updated, 1);
  assert.equal(result.lessons[0].id, "math9");
  assert.equal(result.lessons[0].quiz.length, 4);
  assert.ok(result.lessons[0].body.length > source.body.length);
  assert.deepEqual(source, snapshot);
  assert.equal(result.lessons[0].quiz[0].id, "m91");
});

test("Kullanıcının ders düzenlemeleri ve özel konuları korunur", async () => {
  const custom = {
    ...structuredClone(originalMath),
    body: "Kullanıcının kendi anlatımı.",
  };
  const own = {
    ...structuredClone(lessons[0]),
    id: "my-custom-lesson",
    title: "Kendi konum",
  };
  const result = await reconcileLessons([custom, own]);
  assert.equal(result.updated, 0);
  assert.deepEqual(result.lessons, [custom, own]);
});

test("İçerik güncellemesi ikinci kez kayıt değiştirmez", async () => {
  const result = await reconcileLessons(structuredClone(lessons));
  assert.equal(result.updated, 0);
  assert.deepEqual(result.lessons, lessons);
});

test("Notlar, tamamlanma, favoriler ve geçmiş test snapshotı değişmez", async () => {
  const state = initialState();
  state.lessons = [structuredClone(originalMath)];
  state.notes = [
    { id: "note1", target: "math9", text: "Kendi notum", date: Date.now() },
  ];
  state.completed = ["math9"];
  state.favorites = ["math9"];
  state.exercises = ["math9"];
  const attempt = startAttempt({
    id: "old-quiz",
    title: "Eski sınav",
    subject: "Matematik",
    questions: originalMath.quiz,
    minutes: 0,
  });
  attempt.answers = [2, 1];
  state.attempts = [finalizeAttempt(attempt)];
  const before = structuredClone({
    notes: state.notes,
    completed: state.completed,
    favorites: state.favorites,
    exercises: state.exercises,
    attempts: state.attempts,
  });
  state.lessons = (await reconcileLessons(state.lessons)).lessons;
  validateState(state);
  assert.deepEqual(
    {
      notes: state.notes,
      completed: state.completed,
      favorites: state.favorites,
      exercises: state.exercises,
      attempts: state.attempts,
    },
    before,
  );
  assert.equal(state.attempts[0].total, 2);
});

test("Sayısal soru anahtarları bağımsız hesaplarla tutarlıdır", () => {
  const find = (id, index) => {
    const q = lessons.find((l) => l.id === id).quiz[index];
    return q.options[q.answer];
  };
  assert.equal(find("math9", 0), String(2 ** 3 * 2 ** 2));
  assert.equal(find("math10", 0), String(2 * 3 + 1));
  assert.equal(find("math9-equations", 0), String((9 + 7) / 4));
  assert.equal(find("physics10-circuit", 0), String(12 / 4));
  assert.equal(find("chem10-mixtures", 3), "%" + String((10 / 200) * 100));
  assert.equal(find("bio10-division", 2), String(12 / 2));
  assert.equal(find("geography9-map", 3), String((4 * 50000) / 100000));
});

test("Her açıklamalı anahtar test motorunda doğru kabul edilir", () => {
  for (const l of lessons)
    for (const q of l.quiz) {
      assert.equal(gradeAnswer(q, q.answer), true, q.id);
      assert.equal(
        gradeAnswer(q, (q.answer + 1) % q.options.length),
        false,
        q.id,
      );
    }
});
