import test from "node:test";
import assert from "node:assert/strict";
import { initialState, validateState } from "../src/core.mjs";
import { lessons } from "../src/content.mjs";
import {
  upgradeLearning,
  localDay,
  shiftDay,
  daysBetween,
  recordEvidence,
  mastery,
} from "../src/learning-state.mjs";
import {
  rebuildPlan,
  rankTopics,
  availableMinutes,
  deferTask,
  editTask,
  startTask,
  settleTask,
} from "../src/planner.mjs";
import {
  scheduleReview,
  rateCard,
  addBankReviews,
  isDue,
  reviewSummary,
} from "../src/review-engine.mjs";
const date = "2026-10-22",
  now = new Date(date + "T12:00:00").getTime();
function state() {
  const s = initialState();
  s.lessons = structuredClone(lessons);
  upgradeLearning(s);
  return s;
}
function exam(s, days, topics = ["lesson:math9"]) {
  s.learning.exams.push({
    id: crypto.randomUUID(),
    title: "Matematik sınavı",
    subject: "Matematik",
    date: shiftDay(date, days),
    topics,
    importance: 3,
    prepared: 10,
  });
}
test("Eski şema-3 yedeği ilerlemeyi silmeden bir kez yükseltilir", () => {
  const s = state();
  delete s.learning;
  s.favorites = ["math9"];
  s.notes = [{ id: "n1", target: "math9", text: "Notum" }];
  s.review = [
    {
      id: "r1",
      question: s.lessons[0].quiz[0],
      due: date,
      interval: 12,
      repetitions: 3,
    },
  ];
  assert.equal(upgradeLearning(s), true);
  assert.equal(s.review[0].interval, 12);
  assert.equal(s.review[0].srs.ease, 2.5);
  assert.equal(upgradeLearning(s), false);
  assert.deepEqual(s.favorites, ["math9"]);
  assert.equal(s.notes[0].text, "Notum");
  validateState(s);
});
test("Eski test gözlemleri yalnız bir kez ortak hâkimiyete aktarılır", () => {
  const s = state();
  s.attempts.push({
    id: "a1",
    title: "Test",
    date: new Date(now).toISOString(),
    correct: 1,
    total: 1,
    results: [{ question: s.lessons[0].quiz[0], correct: true }],
  });
  upgradeLearning(s);
  upgradeLearning(s);
  assert.equal(mastery(s, "lesson:math9").successes, 1);
});
test("Tek yanlış hâkimiyet tahminini aşırı düşürmez; olaylar tekrar sayılmaz", () => {
  const s = state(),
    event = {
      id: "e1",
      topic: "algo:binary",
      source: "algorithm",
      correct: false,
    };
  assert.equal(recordEvidence(s, event), true);
  assert.equal(recordEvidence(s, event), false);
  assert.ok(mastery(s, event.topic).score >= 40);
  assert.equal(s.learning.events.length, 1);
});
test("Plan boş geçmişte çalışır; 15 dakika sınırını aşmaz", () => {
  const s = state();
  s.settings.dailyMinutes = 15;
  const p = rebuildPlan(s, date);
  assert.ok(p.tasks.length);
  assert.ok(p.tasks.reduce((n, t) => n + t.minutes, 0) <= 15);
  assert.ok(p.tasks.every((t) => t.reasons.length));
  validateState(s);
});
test("Sınava 1 gün kalan konu 30 gün kalandan daha yüksek puan alır", () => {
  const a = state(),
    b = state();
  exam(a, 1);
  exam(b, 30);
  assert.ok(
    rankTopics(a, date).find((t) => t.id === "lesson:math9").score >
      rankTopics(b, date).find((t) => t.id === "lesson:math9").score,
  );
});
test("Birden çok sınav, eksiklik ve tekrar aynı planda değerlendirilir", () => {
  const s = state();
  exam(s, 1);
  exam(s, 3, ["lesson:physics9"]);
  recordEvidence(s, {
    id: "weak",
    topic: "lesson:physics9",
    source: "test",
    correct: false,
  });
  const p = rebuildPlan(s, date);
  assert.ok(p.tasks.some((t) => t.topic === "lesson:physics9"));
  assert.ok(p.tasks.some((t) => t.topic === "lesson:math9"));
});
test("Ön koşulu öğrenilmemiş ileri konu planlanmaz", () => {
  const s = state();
  assert.ok(!rankTopics(s, date).some((t) => t.id === "algo:binary"));
  recordEvidence(s, {
    id: "l1",
    topic: "algo:linear",
    correct: true,
    source: "algorithm",
  });
  recordEvidence(s, {
    id: "l2",
    topic: "algo:linear",
    correct: true,
    source: "algorithm",
  });
  assert.ok(rankTopics(s, date).some((t) => t.id === "algo:binary"));
});
test("Mola dahil toplam süre bütün günlük bütçelerde sınır içindedir", () => {
  for (const minutes of [0, 15, 30, 45, 60, 90, 120, 180, 480]) {
    const s = state();
    s.learning.availability.fill(minutes);
    const p = rebuildPlan(s, date);
    assert.ok(p.tasks.reduce((n, t) => n + t.minutes, 0) <= minutes);
    if (minutes >= 90) assert.ok(p.tasks.some((t) => t.kind === "break"));
  }
});
test("Haftanın günlerine farklı süreler atanır", () => {
  const s = state();
  s.learning.availability[0] = 15;
  s.learning.availability[5] = 120;
  assert.equal(availableMinutes(s, "2026-10-26"), 15);
  assert.equal(availableMinutes(s, "2026-10-24"), 120);
  assert.equal(availableMinutes(s, "2026-10-25"), 30);
});
test("Yeniden hesaplama tamamlanmış ve elle düzenlenmiş görevleri korur", () => {
  const s = state();
  s.settings.dailyMinutes = 90;
  const p = rebuildPlan(s, date);
  p.tasks[0].status = "done";
  const completed = structuredClone(p.tasks[0]),
    id = p.tasks[1].id;
  editTask(s, date, id, { title: "Kendi görevim", minutes: 10 });
  exam(s, 1);
  const updated = rebuildPlan(s, date);
  assert.deepEqual(
    updated.tasks.find((t) => t.id === completed.id),
    completed,
  );
  assert.equal(updated.tasks.find((t) => t.id === id).title, "Kendi görevim");
});
test("Erteleme aynı görevi bugün tekrar üretmez ve yarına taşır", () => {
  const s = state();
  const p = rebuildPlan(s, date),
    task = p.tasks[0];
  deferTask(s, date, task.id);
  assert.equal(p.tasks.find((t) => t.id === task.id).status, "deferred");
  assert.equal(p.tasks.filter((t) => t.topic === task.topic).length, 1);
  assert.ok(
    rebuildPlan(s, shiftDay(date, 1)).tasks.some(
      (t) => t.topic === task.topic && t.manual,
    ),
  );
});
test("Başlat/duraklat/devam/tamamla yalnız geçen gerçek süreyi bir kez kaydeder", () => {
  const s = state(),
    p = rebuildPlan(s, date),
    id = p.tasks[0].id;
  startTask(s, date, id, now);
  settleTask(s, "pause", now + 30000);
  settleTask(s, "pause", now + 40000);
  assert.equal(
    s.sessions.reduce((n, x) => n + x.seconds, 0),
    30,
  );
  startTask(s, date, id, now + 60000);
  settleTask(s, "done", now + 80000);
  assert.equal(
    s.sessions.reduce((n, x) => n + x.seconds, 0),
    50,
  );
  assert.equal(p.tasks[0].status, "done");
});
test("Sayaç çalışmadan tamamlanan görev sahte çalışma dakikası eklemez", () => {
  const s = state(),
    p = rebuildPlan(s, date);
  p.tasks[0].status = "done";
  rebuildPlan(s, date);
  assert.equal(s.sessions.length, 0);
});
test("Yerel tarihler ve gün farkları saat dilimi/DST etkisi olmadan ilerler", () => {
  assert.equal(shiftDay("2026-03-28", 2), "2026-03-30");
  assert.equal(daysBetween("2026-10-24", "2026-10-26"), 2);
  assert.equal(localDay(new Date(2026, 9, 22, 0, 1)), date);
});
test("Dört değerlendirme farklı aralıklar üretir ve kolay hatırlama aralığı büyütür", () => {
  const card = {
    interval: 10,
    srs: { ease: 2.5, streak: 3, lapses: 0, successes: 3, failures: 0 },
  };
  const results = [1, 2, 3, 4].map((r) => scheduleReview(card, r, now));
  assert.deepEqual(
    results.map((r) => r.interval),
    [0, 6, 25, 34],
  );
  assert.ok(results[3].srs.ease >= results[2].srs.ease);
});
test("Tekrarlanan başarısızlık sıklığı artırır ve 10 dakika sonra yeniden görünür", () => {
  let c = { interval: 20 };
  c = scheduleReview(c, 1, now);
  c = scheduleReview(c, 1, now + 600000);
  assert.equal(c.srs.lapses, 2);
  assert.equal(c.srs.streak, 0);
  assert.equal(isDue(c, now + 600001), false);
  assert.equal(isDue(c, now + 1200000), true);
});
test("Geciken kart değerlendirme gününden itibaren planlanır", () => {
  const c = scheduleReview({ due: "2026-09-01", interval: 4 }, 3, now);
  assert.equal(c.due, "2026-10-26");
  assert.ok(c.srs.last === date);
});
test("Soru bankası oturumu yinelenen kart oluşturmaz, farklı konuları dolaşır", () => {
  const s = state();
  const first = addBankReviews(s, 12, date);
  assert.equal(first.added, 12);
  const ids = new Set(s.review.map((r) => r.question.id));
  assert.equal(ids.size, 12);
  assert.ok(new Set(s.review.map((r) => r.topic)).size > 5);
  addBankReviews(s, 12, date);
  assert.equal(new Set(s.review.map((r) => r.question.id)).size, 24);
});
test("Tekrar sonucu ortak ilerlemeyi ve tekrar takvimini günceller", () => {
  const s = state();
  addBankReviews(s, 1, date);
  upgradeLearning(s);
  const id = s.review[0].id;
  rateCard(s, id, 4, now);
  assert.equal(s.learning.reviewLog.length, 1);
  assert.equal(s.learning.events.at(-1).source, "review");
  const sum = reviewSummary(s, date, now);
  assert.equal(sum.due.length, 0);
  assert.equal(sum.topics[0].memory, "Yeterli veri yok");
  validateState(s);
});
test("Yeni veriler JSON yedeğinde korunur ve bozuk yeni alanlar reddedilir", () => {
  const s = state();
  exam(s, 1);
  rebuildPlan(s, date);
  validateState(JSON.parse(JSON.stringify(s)));
  s.learning.availability[0] = -1;
  assert.throws(() => validateState(s), /haftalık/);
});
