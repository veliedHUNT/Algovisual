import test from "node:test";
import assert from "node:assert/strict";
import {
  algorithms,
  buildSimulation,
  predictionQuestion,
  recordPrediction,
  answerChallenge,
  graphExample,
} from "../src/playground.mjs";
import { initialState, validateState } from "../src/core.mjs";
for (const kind of ["bubble", "selection", "insertion", "merge", "quick"])
  test(
    kind +
      " boş, tek, yinelenen, negatif, sıralı ve ters girdileri doğru sıralar",
    () => {
      for (const a of [
        [],
        [3],
        [4, 4, 1, 1],
        [-2, 7, 0, -8],
        [1, 2, 3, 4],
        [4, 3, 2, 1],
      ]) {
        const trace = buildSimulation(kind, a.join(","));
        assert.deepEqual(
          JSON.parse(trace.steps.at(-1).output),
          [...a].sort((a, b) => a - b),
        );
        assert.ok(
          trace.steps.every((s) => s.line >= 1 && s.line <= trace.code.length),
        );
        assert.ok(trace.steps.length <= 5000);
        const before = JSON.stringify(trace.steps[0]);
        trace.steps.at(-1).visual.array?.push(99);
        assert.equal(JSON.stringify(trace.steps[0]), before);
      }
    },
  );
test("Bubble erken çıkışı ve küçük karşılaştırma örnekleri gerçek sayaçlarla tutarlı", () => {
  assert.equal(buildSimulation("bubble", "1,2,3,4").metrics.comparisons, 3);
  assert.equal(buildSimulation("bubble", "4,3,2,1").metrics.comparisons, 6);
  assert.equal(buildSimulation("merge", "4,3,2,1").metrics.comparisons, 4);
});
for (const kind of ["linear", "binary"])
  test(kind + " araması doğru indis veya -1 döndürür", () => {
    for (const [input, target, expected] of [
      ["", 2, -1],
      ["-1", -1, 0],
      ["1,3,5,7", 5, 2],
      ["1,3,5", 4, -1],
    ]) {
      const trace = buildSimulation(kind, input, String(target));
      assert.equal(Number(trace.steps.at(-1).output), expected);
    }
  });
test("Binary Search sırasız veriyi sessizce sıralamaz; girdi sınırları uygulanır", () => {
  assert.throws(() => buildSimulation("binary", "3,1,2", "2"), /sıralı/);
  for (const input of ["1,,2", "NaN", Array(25).fill(1).join(","), "1000001"])
    assert.throws(() => buildSimulation("bubble", input));
});
test("Stack LIFO, queue FIFO ve linked list bağlantıları gerçek işlemleri izler", () => {
  assert.equal(
    buildSimulation("stack", "push 1;push 2;pop").steps.at(-1).output,
    "[1]",
  );
  assert.equal(
    buildSimulation("queue", "enqueue 1;enqueue 2;dequeue").steps.at(-1).output,
    "[2]",
  );
  assert.equal(
    buildSimulation("linked", "add 1;add 2;add 1;remove 1").steps.at(-1).output,
    "[2,1]",
  );
  assert.doesNotThrow(() => buildSimulation("stack", "pop;peek"));
  assert.throws(() => buildSimulation("queue", "pop"), /enqueue/);
});
test("BST tekrarları eklemez, doğru alt dalları ve aramayı gösterir", () => {
  const trace = buildSimulation(
    "bst",
    "insert 5;insert 2;insert 8;insert 2;find 8",
  );
  const tree = JSON.parse(trace.steps.at(-1).output);
  assert.equal(tree.value, 5);
  assert.equal(tree.left.value, 2);
  assert.equal(tree.right.value, 8);
  assert.equal(trace.metrics.writes, 3);
});
for (const kind of ["bfs", "dfs"])
  test(kind + " döngüde düğümü yalnız bir kez ziyaret eder", () => {
    const trace = buildSimulation(kind, graphExample, "A"),
      visited = trace.steps.at(-1).vars.visited;
    assert.equal(visited.length, 5);
    assert.equal(new Set(visited).size, 5);
    assert.equal(trace.metrics.visits, 5);
  });
test("Dijkstra ağırlıklı en kısa yolları ve ulaşılamayan düğümleri doğru bulur", () => {
  const g = JSON.stringify({
    nodes: ["A", "B", "C", "X"],
    edges: [
      ["A", "B", 7],
      ["A", "C", 2],
      ["C", "B", 1],
    ],
    directed: true,
  });
  const trace = buildSimulation("dijkstra", g, "A"),
    dist = trace.steps.at(-1).vars.distances;
  assert.deepEqual(dist, { A: 0, B: 3, C: 2, X: "∞" });
  assert.throws(
    () =>
      buildSimulation(
        "dijkstra",
        JSON.stringify({
          nodes: ["A", "B"],
          edges: [["A", "B", -1]],
          directed: false,
        }),
        "A",
      ),
    /negatif/,
  );
});
test("14 simülasyonun tamamı girdiye bağlı adımlarla ve geçerli satırlarla çalışır", () => {
  assert.equal(Object.keys(algorithms).length, 14);
  for (const [kind, a] of Object.entries(algorithms)) {
    const t = buildSimulation(kind, a.input, a.group === "Graf" ? "A" : "5");
    assert.ok(t.steps.length);
    assert.ok(t.steps.every((s) => s.line > 0 && s.line <= t.code.length));
  }
});
test("Tahmin puanı aynı adım için tekrar kazanılamaz ve yanlışlar tekrar kartına bağlanır", () => {
  const s = initialState(),
    t = buildSimulation("bubble", "3,1"),
    q = predictionQuestion(t, 0);
  const wrong = (q.answer + 1) % q.options.length;
  assert.equal(recordPrediction(s, t, 0, wrong).correct, false);
  assert.equal(recordPrediction(s, t, 0, q.answer).duplicate, true);
  assert.equal(s.learning.algorithms.answers.length, 1);
  assert.equal(s.review.length, 1);
  assert.equal(s.review[0].topic, "algo:bubble");
  validateState(s);
});
test("Algoritma görevinde başarı tek kayıttır, yanlış tahmin de ortak ilerlemeye gider", () => {
  const s = initialState();
  assert.equal(answerChallenge(s, "binary-mid", 0).correct, false);
  assert.equal(s.review.length, 1);
  answerChallenge(s, "binary-mid", 1);
  answerChallenge(s, "binary-mid", 1);
  assert.equal(s.learning.algorithms.challenges.length, 1);
});
