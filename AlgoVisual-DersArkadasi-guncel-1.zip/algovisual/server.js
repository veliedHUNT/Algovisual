"use strict";
const http = require("node:http"),
  fs = require("node:fs"),
  path = require("node:path"),
  { spawn } = require("node:child_process");
try {
  process.loadEnvFile(path.join(__dirname, ".env"));
} catch (e) {
  if (e.code !== "ENOENT") throw e;
}
const { AIService } = require("./src/ai-server.cjs");
const ROOT = __dirname;
const types = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".bcmap": "application/octet-stream",
  ".pfb": "application/octet-stream",
  ".ttf": "font/ttf",
};
const allowed =
  /^\/(?:index\.html|app\.js|styles\.css|sw\.js|manifest\.json|icon\.svg|src\/(?:core|store|content|algorithms|learning-state|planner|review-engine|playground|linux-lab|v2-ui|exam-config|exam-state|exam-bank|exam-engine|exam-ui)\.mjs|vendor\/(?:pdf(?:\.worker)?\.mjs|(?:cmaps|standard_fonts)\/[\w.-]+))$/;
const headers = {
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "no-referrer",
  "X-Frame-Options": "DENY",
  "Content-Security-Policy":
    "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; worker-src 'self' blob:; connect-src 'self'; font-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
};
function send(res, status, data) {
  res.writeHead(status, {
    ...headers,
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0,
      chunks = [];
    req.on("data", (c) => {
      size += c.length;
      if (size > 180000) {
        reject(Object.assign(Error("İstek çok büyük."), { status: 413 }));
        req.resume();
        chunks = [];
      } else chunks.push(c);
    });
    req.on("end", () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"));
      } catch {
        reject(Object.assign(Error("Geçerli JSON gönder."), { status: 400 }));
      }
    });
    req.on("error", reject);
  });
}
function pythonSyntax(code) {
  return new Promise((resolve) => {
    const source =
      'import ast,json,sys\ntry:\n ast.parse(sys.stdin.read())\n print(json.dumps({"issues":[]}))\nexcept SyntaxError as e:\n print(json.dumps({"issues":[{"line":e.lineno,"message":e.msg}]}))\n';
    const child = spawn(
      process.env.PYTHON_BIN || "python",
      ["-I", "-S", "-c", source],
      { windowsHide: true, stdio: ["pipe", "pipe", "ignore"], timeout: 3500 },
    );
    let output = "",
      done = false;
    const finish = (x) => {
      if (!done) {
        done = true;
        resolve(x);
      }
    };
    child.stdout.on("data", (x) => {
      output += x;
      if (output.length > 20000) {
        child.kill();
        finish({ available: false });
      }
    });
    child.on("error", () => finish({ available: false }));
    child.on("close", () => {
      try {
        finish({ ...JSON.parse(output), available: true });
      } catch {
        finish({ available: false });
      }
    });
    child.stdin.on("error", () => {});
    child.stdin.end(code);
  });
}
function createServer(options = {}) {
  const ai = options.ai || new AIService(),
    buckets = new Map();
  let active = 0,
    daily = 0,
    currentDay = new Date().toISOString().slice(0, 10);
  const instance = http.createServer(async (req, res) => {
    try {
      const host = req.headers.host || "";
      if (!/^(?:127(?:\.\d{1,3}){3}|localhost|\[::1\])(?::\d+)?$/.test(host))
        return send(res, 403, {
          error: "Bu sunucu yalnızca yerel kullanım içindir.",
        });
      let url;
      try {
        url = new URL(req.url, "http://" + host);
      } catch {
        return send(res, 400, { error: "Geçersiz adres." });
      }
      if (req.headers.origin && req.headers.origin !== "http://" + host)
        return send(res, 403, {
          error: "Farklı kaynaktan gelen isteğe izin verilmedi.",
        });
      if (req.method === "GET" && url.pathname === "/api/health")
        return send(res, 200, {
          ok: true,
          aiConfigured: Boolean(ai.key),
          model: ai.model,
          provider: new URL(ai.base).hostname,
          aiProvider: ai.provider,
          keyEnv: ai.keyEnv,
          runnerConfigured: Boolean(process.env.RUNNER_URL),
          version: "2.1.0",
        });
      if (url.pathname.startsWith("/api/")) {
        if (req.method !== "POST")
          return send(res, 405, { error: "Bu işlem POST gerektirir." });
        if (
          !String(req.headers["content-type"] || "").startsWith(
            "application/json",
          )
        )
          return send(res, 415, { error: "JSON içerik türü gerekli." });
        const now = Date.now(),
          ip = req.socket.remoteAddress,
          bucket = buckets.get(ip) || { start: now, count: 0 };
        if (now - bucket.start > 600000) {
          bucket.start = now;
          bucket.count = 0;
        }
        if (++bucket.count > 30)
          return send(res, 429, {
            error: "Çok fazla istek. Birkaç dakika sonra tekrar dene.",
          });
        buckets.set(ip, bucket);
        if (active >= 2)
          return send(res, 429, {
            error: "Sunucu meşgul; açık isteğin tamamlanmasını bekle.",
          });
        const body = await readBody(req);
        active++;
        try {
          if (url.pathname === "/api/ai/chat") {
            const date = new Date().toISOString().slice(0, 10);
            if (date !== currentDay) {
              currentDay = date;
              daily = 0;
            }
            if (daily >= (Number(process.env.AI_DAILY_REQUEST_LIMIT) || 100))
              return send(res, 429, {
                error: "Sunucunun günlük AI istek sınırına ulaşıldı.",
              });
            daily++;
            return send(res, 200, await ai.chat(body));
          }
          if (url.pathname === "/api/code/check") {
            if (
              typeof body.code !== "string" ||
              body.code.length > 100000 ||
              body.lang !== "python"
            )
              return send(res, 400, {
                error: "Python kodu en fazla 100.000 karakter olabilir.",
              });
            return send(res, 200, await pythonSyntax(body.code));
          }
          if (url.pathname === "/api/code/run") {
            if (
              !["python", "c"].includes(body.lang) ||
              typeof body.code !== "string" ||
              body.code.length > 100000
            )
              return send(res, 400, { error: "Geçersiz dil veya kod boyutu." });
            if (!process.env.RUNNER_URL)
              return send(res, 501, {
                error:
                  "İzole çalıştırma servisi bağlı değil. Editör ve sözdizimi kontrolü kullanılabilir; README’de sandbox bağlantı sözleşmesi var.",
              });
            const remote = await fetch(process.env.RUNNER_URL, {
              method: "POST",
              headers: {
                "Content-Type": "application/json",
                ...(process.env.RUNNER_TOKEN
                  ? { Authorization: "Bearer " + process.env.RUNNER_TOKEN }
                  : {}),
              },
              body: JSON.stringify({
                language: body.lang,
                source: body.code,
                stdin: String(body.stdin || "").slice(0, 10000),
                limits: { wallTimeMs: 3000, memoryMb: 128, network: false },
              }),
              signal: AbortSignal.timeout(6000),
            });
            if (!remote.ok)
              return send(res, 502, {
                error: "Çalıştırma servisi isteği tamamlayamadı.",
              });
            const result = await remote.json();
            return send(res, 200, {
              stdout: String(result.stdout || "").slice(0, 20000),
              stderr: String(result.stderr || "").slice(0, 10000),
              exitCode: Number.isInteger(result.exitCode)
                ? result.exitCode
                : null,
            });
          }
          return send(res, 404, { error: "API yolu bulunamadı." });
        } finally {
          active--;
        }
      }
      if (!["GET", "HEAD"].includes(req.method))
        return send(res, 405, { error: "Desteklenmeyen yöntem." });
      let pathname;
      try {
        pathname = decodeURIComponent(url.pathname);
      } catch {
        return send(res, 400, { error: "Geçersiz adres kodlaması." });
      }
      if (pathname === "/") pathname = "/index.html";
      if (!allowed.test(pathname))
        return send(res, 404, { error: "Dosya bulunamadı." });
      const file = path.resolve(ROOT, "." + pathname);
      if (!file.startsWith(ROOT + path.sep))
        return send(res, 403, { error: "Erişim reddedildi." });
      fs.stat(file, (err, st) => {
        if (err || !st.isFile())
          return send(res, 404, { error: "Dosya bulunamadı." });
        res.writeHead(200, {
          ...headers,
          "Content-Type":
            types[path.extname(file)] || "application/octet-stream",
          "Cache-Control":
            pathname === "/sw.js"
              ? "no-cache"
              : pathname.startsWith("/vendor/")
                ? "public, max-age=31536000, immutable"
                : "no-cache",
        });
        if (req.method === "HEAD") return res.end();
        const stream = fs.createReadStream(file);
        stream.on("error", () => res.destroy());
        stream.pipe(res);
      });
    } catch (e) {
      if (!res.headersSent)
        send(res, e.status || 502, {
          error: e.status
            ? e.message
            : "İstek tamamlanamadı. Yerel sunucu bağlantısını kontrol et.",
        });
      else res.end();
    }
  });
  instance.requestTimeout = 15000;
  instance.headersTimeout = 10000;
  instance.keepAliveTimeout = 5000;
  return instance;
}
if (require.main === module) {
  const host = process.env.HOST || "127.0.0.4";
  if (
    !/^127(?:\.\d{1,3}){3}$/.test(host) &&
    host !== "::1" &&
    host !== "localhost"
  )
    throw Error(
      "Bu sürüm yalnızca loopback adresinde çalışır. Uzaktan erişim için oturum, HTTPS ve yetkilendirme ekleyin.",
    );
  createServer().listen(Number(process.env.PORT) || 8080, host, () =>
    console.log(`AlgoVisual hazır: http://${host}:${process.env.PORT || 8080}`),
  );
}
module.exports = { createServer };
