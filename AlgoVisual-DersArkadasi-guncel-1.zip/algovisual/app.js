import {
  uid,
  day,
  addDays,
  esc as e,
  normalize,
  initialState,
  validateState,
  validateTest,
  validateQuestion,
  migrateLegacy,
  answerText,
  gradeAnswer,
  startAttempt,
  finalizeAttempt,
  reschedule,
  stats,
  documentTools,
  syntaxCheck,
} from "./src/core.mjs";
import {
  openStore,
  writeState,
  saveBlob,
  getBlob,
  removeBlob,
  clearBlobs,
} from "./src/store.mjs";
import {
  lessons as library,
  schoolSubjects,
  reconcileLessons,
} from "./src/content.mjs";
import { buildTrace, algorithmNames } from "./src/algorithms.mjs";
import { upgradeLearning, recordEvidence } from "./src/learning-state.mjs";
import { rebuildPlan, configureStudyTime } from "./src/planner.mjs";
import { isDue, rateCard } from "./src/review-engine.mjs";
const $ = (s) => document.querySelector(s);
const icons = {
  dashboard: "M3 3h7v7H3zm11 0h7v7h-7zM3 14h7v7H3zm11 0h7v7h-7z",
  lessons:
    "M3 4h6a3 3 0 0 1 3 3v14a4 4 0 0 0-4-3H3zm18 0h-6a3 3 0 0 0-3 3v14a4 4 0 0 1 4-3h5z",
  tests: "M9 5H5v16h14V5h-4M9 3h6v4H9zM8 12h8m-8 4h5",
  pdf: "M6 2h8l4 4v16H6zM14 2v5h5M9 12h6m-6 4h6",
  review: "M3 11a9 9 0 1 1 3 8M3 4v7h7m2-4v5l3 2",
  coach: "m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z",
  reports: "M4 20V10m8 10V4m8 16v-7M2 22h20",
  algovisual: "m8 5-6 7 6 7m8-14 6 7-6 7M14 2l-4 20",
  academy: "m2 8 10-5 10 5-10 5zM6 11v6c4 3 8 3 12 0v-6m4-3v9",
  cyber: "m12 2 8 4v6c0 5-8 10-8 10S4 17 4 12V6zM8 12l3 3 5-6",
  codelab: "M3 4h18v15H3zm-1 18h20M7 8l3 3-3 3m6 0h4",
  ai: "m12 2 2 7 7 2-7 2-2 7-2-7-7-2 7-2zM21 2v5m-2-2h4",
  calendar: "M5 3v4m14-4v4M3 9h18M3 5h18v17H3z",
  clock: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18m0 4v6l4 2",
  arrow: "M4 12h16m-6-6 6 6-6 6",
  plus: "M12 4v16M4 12h16",
  search: "M10 3a7 7 0 1 0 0 14 7 7 0 0 0 0-14m5 12 6 6",
  check: "m5 12 4 4L19 6",
};
const icon = (name) =>
  `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${icons[name] || icons.lessons}"/></svg>`;
const nav = [
  ["dashboard", "Genel bakış"],
  ["examcoach", "SınavKoçu"],
  ["lessons", "Derslerim"],
  ["tests", "Testler ve soru bankası"],
  ["pdf", "PDF merkezi"],
  ["review", "Tekrar ve yanlışlar"],
  ["coach", "Çalışma planım"],
  ["reports", "Çalışma raporum"],
  ["algovisual", "AlgoVisual"],
  ["playground", "Algoritma oyun alanı"],
  ["academy", "Yazılım akademisi"],
  ["cyber", "Siber güvenlik"],
  ["linuxlab", "Linux ve CTF laboratuvarı"],
  ["codelab", "Kod laboratuvarı"],
  ["ai", "AI ders asistanı"],
];
let db,
  revision = 0,
  saveQueue = Promise.resolve(),
  savingBroken = false,
  chat = [],
  lastResult = null,
  editor = null,
  selectedFile = null,
  codeSaveTimer,
  trace = buildTrace("loop", "1, 2, 3"),
  algoIndex = 0,
  algoKind = "loop",
  algoInput = "1, 2, 3",
  algoSpeed = 1000,
  algoInterval = null,
  pdfModule = null,
  pdfDoc = null,
  pdfRenderTask = null,
  pdfToken = 0,
  busyAI = false,
  health = null,
  shownReview = new Set();
let filters = { query: "", grade: "all", subject: "all", favorite: false };
icons.playground = icons.algovisual;
icons.linuxlab = icons.codelab;
icons.examcoach = icons.coach;
let examModule, examPromise;
const examContext = () => ({...v2Context(), exportBackup});
async function loadExamCoach() {
  examPromise ??= import('./src/exam-ui.mjs').then(async module => {
    await module.prepare(examContext());
    examModule = module;
    return module;
  }).catch(err => { examPromise = null; throw err; });
  await examPromise;
}
let v2Module, v2Promise;
const v2Loads = new Map();
const v2Routes = ["coach", "review", "playground", "linuxlab"];
const v2Context = () => ({
  state: db,
  save: persist,
  render,
  go,
  toast,
  route,
  legacyCoach: coachPage,
});
async function loadV2(page, id) {
  const key = page + "/" + (id || "");
  if (v2Loads.has(key)) return v2Loads.get(key);
  const job = (async () => {
    v2Promise ??= import("./src/v2-ui.mjs");
    v2Module = await v2Promise;
    await v2Module.prepare(page, id, v2Context());
    if (route()[0] === page && route()[1] === id) render();
  })().finally(() => v2Loads.delete(key));
  v2Loads.set(key, job);
  return job;
}
function toast(message, error = false) {
  const el = $("#toast");
  el.textContent = message;
  el.classList.toggle("error", error);
  el.style.display = "block";
  clearTimeout(toast.timeout);
  toast.timeout = setTimeout(() => (el.style.display = "none"), 4500);
}
function persist() {
  upgradeLearning(db);
  for (const date of db.learning.plans
    .filter((p) => p.date >= day())
    .map((p) => p.date))
    rebuildPlan(db, date);
  const snapshot = structuredClone(db);
  const job = saveQueue.then(async () => {
    if (savingBroken)
      throw Error("Kayıt durdu. Verilerini yedekleyip sayfayı yenile.");
    try {
      validateState(snapshot);
      await writeState(snapshot, revision);
      revision = snapshot.rev;
      db.rev = revision;
    } catch (err) {
      savingBroken = true;
      $("#saveError").hidden = false;
      $("#saveError").textContent =
        err.message +
        " Kaydedilmemiş verileri Ayarlar → Yedeği indir ile koruyabilirsin.";
      throw err;
    }
  });
  saveQueue = job.catch(() => {});
  return job;
}
function route() {
  try {
    return (location.hash.slice(1) || "dashboard")
      .split("/")
      .map(decodeURIComponent);
  } catch {
    return ["dashboard"];
  }
}
async function go(path) {
  if (location.hash.slice(1) === path) render();
  else location.hash = path;
}
const action = (name, label, id = "", className = "secondary", extra = "") =>
  `<button type="button" class="btn ${className}" data-action="${name}" ${id ? `data-id="${e(id)}"` : ""} ${extra}>${label}</button>`;
const link = (path, label, className = "secondary") =>
  `<a class="btn ${className}" href="#${e(path)}">${label}</a>`;
const card = (title, body, extra = "") =>
  `<section class="card ${extra}">${title ? `<div class="card-header"><h2>${title}</h2></div>` : ""}${body}</section>`;
const empty = (text, button = "") =>
  `<div class="empty"><p>${text}</p>${button}</div>`;
const badge = (text, cls = "") => `<span class="tag ${cls}">${e(text)}</span>`;
const options = (values, current) =>
  values
    .map(
      (v) =>
        `<option value="${e(v)}" ${String(v) === String(current) ? "selected" : ""}>${e(v)}</option>`,
    )
    .join("");
const heading = (title, desc, buttons = "") =>
  `<div class="page-heading"><div><span class="eyebrow">KİŞİSEL ÖĞRENME ALANIN</span><h1>${title}</h1><p>${desc}</p></div>${buttons}</div>`;
const stat = (name, value, hint, ic) =>
  `<div class="stat"><div class="stat-top">${name}<span class="stat-icon">${icon(ic)}</span></div><div class="stat-value">${value}</div><small>${hint}</small></div>`;
function due() {
  return db.review.filter((r) => isDue(r));
}
function progress(l) {
  return db.completed.includes(l.id)
    ? 100
    : db.exercises.includes(l.id)
      ? 50
      : db.recent.includes(l.id)
        ? 20
        : 0;
}
function nextLesson(area) {
  return (
    db.lessons.find(
      (l) =>
        (!area || l.area === area) &&
        !db.completed.includes(l.id) &&
        (l.prerequisites || []).every((id) => db.completed.includes(id)),
    ) || db.lessons[0]
  );
}
function lessonTile(l) {
  const symbols = {
    Matematik: "ƒ",
    Python: "Py",
    Fizik: "↗",
    Kimya: "⚗",
    Biyoloji: "⌘",
    C: "C",
    Web: "</>",
    "Ağ temelleri": "⌁",
  };
  return `<article class="lesson-card"><button class="favorite ${db.favorites.includes(l.id) ? "on" : ""}" data-action="favorite" data-id="${e(l.id)}" aria-label="${db.favorites.includes(l.id) ? "Favoriden çıkar" : "Favoriye ekle"}" aria-pressed="${db.favorites.includes(l.id)}">${db.favorites.includes(l.id) ? "★" : "☆"}</button><div class="subject-icon">${e(symbols[l.subject] || l.subject.slice(0, 2))}</div><small>${e(l.area === "school" ? l.grade + ". SINIF · " + l.subject.toLocaleUpperCase("tr") : l.subject.toLocaleUpperCase("tr"))}</small><a href="#lesson/${e(l.id)}"><h3>${e(l.title)}</h3></a><p class="line-clamp">${e(l.goal)}</p><div class="progress" aria-label="İlerleme %${progress(l)}"><span style="width:${progress(l)}%"></span></div><div class="card-bottom"><span>${progress(l)}% tamamlandı</span><a class="text-link" href="#lesson/${e(l.id)}">${db.recent.includes(l.id) ? "Devam et" : "Başla"} ↗</a></div></article>`;
}
function weekChart() {
  const days = Array.from({ length: 7 }, (_, i) => {
    const iso = addDays(day(), i - 6);
    return {
      iso,
      minutes: Math.round(
        db.sessions
          .filter((s) => s.date === iso)
          .reduce((n, s) => n + s.seconds, 0) / 60,
      ),
    };
  });
  const max = Math.max(30, ...days.map((d) => d.minutes));
  return `<div class="week">${days.map((d) => `<div class="day-bar"><span>${d.minutes || ""}</span><div class="bar" style="height:${(d.minutes / max) * 75}px" title="${d.iso}: ${d.minutes} dakika"></div><span>${new Date(d.iso + "T12:00:00").toLocaleDateString("tr-TR", { weekday: "narrow" })}</span></div>`).join("")}</div><div class="week-caption"><span>Son 7 gün · odak sayacı</span><span>Dakika</span></div>`;
}
function updateShell() {
  const p = route()[0],
    key =
      p === "lesson"
        ? "lessons"
        : p === "result" || p === "attempt" || p === "testedit"
          ? "tests"
          : p;
  $("#navigation").innerHTML = nav
    .map(
      ([id, title], i) =>
        `${i === 7 ? '<div class="nav-divider"></div>' : ""}<a class="nav-link ${key === id ? "active" : ""}" href="#${id}" ${key === id ? 'aria-current="page"' : ""}>${icon(id)}<span>${title}</span>${id === "review" && due().length ? `<b>${due().length}</b>` : ""}</a>`,
    )
    .join("");
  $("#breadcrumb").textContent =
    nav.find((x) => x[0] === key)?.[1] || "Çalışma alanı";
  $("#connection").textContent = navigator.onLine
    ? "Yerel çalışma alanı"
    : "Çevrimdışı";
  document.documentElement.dataset.theme = db.settings.theme;
}
function dashboard() {
  const st = stats(db),
    todaySeconds = db.sessions
      .filter((s) => s.date === day())
      .reduce((n, s) => n + s.seconds, 0),
    minutes = Math.floor(todaySeconds / 60),
    percent = Math.min(
      100,
      Math.round((minutes / db.settings.dailyMinutes) * 100),
    ),
    next = nextLesson();
  const recent = db.recent
    .map((id) => db.lessons.find((l) => l.id === id))
    .filter(Boolean)
    .filter((l) => !db.completed.includes(l.id));
  const picks = (
    recent.length
      ? recent
      : db.lessons.filter((l) => ["py1", "math10", "net1"].includes(l.id))
  ).slice(0, 3);
  const offset = 226 * (1 - percent / 100);
  return (
    heading(
      "Bugün ne öğrenmek istersin?",
      "Küçük adımlar, kalıcı bilgiler. Öğrenme yolculuğuna devam et.",
      `<div class="date-label">${icon("calendar")}${new Date().toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" })}</div>`,
    ) +
    `
<section class="hero"><div><span class="eyebrow">HER GÜN BİRAZ DAHA İLERİ</span><h2>Potansiyelini öğrenerek keşfet.</h2><p>Derslerini pekiştir, kodun mantığını gör ve kendi hızında ilerle. Bugünkü küçük bir adımın, yarının büyük farkı olsun.</p>${link("lesson/" + next.id, "Öğrenmeye devam et " + icon("arrow"), "")}</div><div class="hero-art" aria-hidden="true"><svg viewBox="0 0 230 170" fill="none"><path d="M28 99 113 49l86 50-85 50z" fill="#365447" stroke="#6b997c"/><path d="m28 99 86 50v16l-86-50z" fill="#293e34"/><path d="m114 149 85-50v16l-85 50z" fill="#24392e"/><path d="M52 68 113 33l64 36-63 36z" fill="#597f63" stroke="#a3cfa8"/><path d="m52 68 62 37v16L52 84z" fill="#3d5c47"/><path d="m114 105 63-36v16l-63 36z" fill="#314d3a"/><path d="m77 36 36-21 38 22-37 22z" fill="#bad7a6"/><path d="m77 36 37 23v16L77 52z" fill="#83aa7b"/><path d="m114 59 37-22v16l-37 22z" fill="#658d62"/><path d="m181 36 5-12 5 12 12 5-12 5-5 12-5-12-12-5z" fill="#c0ddb7"/><circle cx="39" cy="46" r="3" fill="#799a7d"/><circle cx="198" cy="136" r="3" fill="#799a7d"/></svg></div></section>
<div class="stats">${stat("Tamamlanan konu", db.completed.length, db.lessons.length + " konu içinden", "lessons")}${stat("Çözülen soru", st.total, db.attempts.length + " tamamlanmış test", "tests")}${stat("Başarı oranı", st.rate === null ? "—" : st.rate + "%", st.total ? "Cevaplarından hesaplandı" : "İlk testinle başlayacak", "reports")}${stat("Bugünkü tekrar", due().length, "Hatırlamak için iyi bir gün", "review")}</div>
<div class="dashboard-grid"><div><div class="section-title"><h2>${recent.length ? "Kaldığın yerden devam et" : "Senin için başlangıçlar"}</h2><a class="text-link" href="#lessons">Tüm dersler →</a></div><div class="lesson-grid">${picks.map(lessonTile).join("")}</div><div class="section-title"><h2>Öğrenmenin farklı yolları</h2></div><div class="quick-grid">${[
      ["pdf", "PDF ile çalış", "Notlarını bilgiye dönüştür"],
      ["algovisual", "Kodu görselleştir", "Adım adım mantığı keşfet"],
      ["tests", "Kendini dene", "Bilgilerini pekiştir"],
    ]
      .map(
        ([id, title, desc]) =>
          `<a class="quick-card" href="#${id}">${icon(id)}<div>${title}<small>${desc}</small></div></a>`,
      )
      .join("")}</div>${card(
      "Son testlerin",
      db.attempts.length
        ? db.attempts
            .slice(-3)
            .reverse()
            .map(
              (a) =>
                `<a class="row" href="#result/${a.id}"><div><strong>${e(a.title)}</strong><small>${new Date(a.date).toLocaleDateString("tr-TR")} · ${a.total} soru</small></div>${badge(a.correct + "/" + a.total + " doğru", "blue")}</a>`,
            )
            .join("")
        : empty(
            "Henüz tamamlanmış testin yok. Hazır bir mini sınavla başlayabilirsin.",
            link("tests", "Testlere göz at", "ghost small"),
          ),
    )}</div>
<aside class="dashboard-side">${card("Günlük hedefin", `<div class="goal-ring"><div class="ring"><svg viewBox="0 0 90 90"><circle cx="45" cy="45" r="36" fill="none" stroke="var(--line)" stroke-width="6"/><circle cx="45" cy="45" r="36" fill="none" stroke="var(--green)" stroke-width="6" stroke-linecap="round" stroke-dasharray="226" stroke-dashoffset="${offset}"/></svg><strong>${percent}%</strong><small>tamamlandı</small></div><div><h3>${minutes} / ${db.settings.dailyMinutes} dakika</h3><p>Odak sayacıyla kaydedilen<br>bugünkü çalışma süren.</p></div></div>${link("coach", db.timer ? "Sayacına dön" : "Odaklanmaya başla", "secondary")}<div class="hint-divider"></div><div class="row"><div><strong>${due().length ? due().length + " tekrar seni bekliyor" : "Tekrarların burada birikecek"}</strong><small>${due().length ? "Unutmadan pekiştir." : "Yanlışların tekrar kartına dönüşür."}</small></div><a class="text-link" href="#review">→</a></div>`)}${card("Bu haftaki ritmin", weekChart())}<div class="ai-callout"><h3>✦ Yanında bir öğrenme asistanı</h3><p>Bir konuyu farklı bir yoldan anlamak ister misin? AI bağlantısı kurulduğunda birlikte keşfedebilirsin.</p><a class="text-link" href="#ai">AI asistanını aç →</a></div></aside></div>`
  );
}
function catalog(area = "school") {
  const title =
    area === "school"
      ? "Derslerim"
      : area === "software"
        ? "Yazılım akademisi"
        : "Siber güvenlik akademisi";
  let items = db.lessons.filter((l) => l.area === area);
  items = items.filter(
    (l) =>
      (filters.grade === "all" || l.grade === filters.grade) &&
      (filters.subject === "all" || l.subject === filters.subject) &&
      (!filters.favorite || db.favorites.includes(l.id)) &&
      normalize(l.title + " " + l.subject + " " + l.unit).includes(
        normalize(filters.query),
      ),
  );
  const subjects =
    area === "school"
      ? schoolSubjects
      : [
          ...new Set(
            db.lessons.filter((l) => l.area === area).map((l) => l.subject),
          ),
        ];
  return (
    heading(
      title,
      area === "school"
        ? "Konuyu anla, uygulayarak pekiştir, kendi ilerlemeni izle."
        : "Ön koşulları takip ederek adım adım ilerle. Alıştırma ve mini sınavla tamamla.",
      link("lessonedit/new", "+ İçerik ekle", ""),
    ) +
    `<form id="filterForm" class="toolbar"><label class="field search-field">Konu ara<input name="query" value="${e(filters.query)}" placeholder="Konu veya ünite adı…" maxlength="100"></label>${area === "school" ? `<label class="field">Sınıf<select name="grade"><option value="all">Tüm sınıflar</option>${options(["9", "10"], filters.grade)}</select></label>` : ""}<label class="field">Ders<select name="subject"><option value="all">Tüm dersler</option>${options(subjects, filters.subject)}</select></label><label class="check"><input name="favorite" type="checkbox" ${filters.favorite ? "checked" : ""}>Favoriler</label><button class="btn secondary">Filtrele</button></form><div class="notice">İçerikler özgün başlangıç örnekleridir. Resmî 9–10. sınıf müfredatıyla tam eşleşme ve kapsam doğrulanmamıştır. İçerik ekleyebilir ve düzenleyebilirsin.</div>${area === "cyber" ? '<p class="notice warning">Uygulamalar yalnızca kendi ortamında veya açık izin verilen laboratuvarlarda yapılmalıdır.</p>' : ""}<div class="content-list">${items.map(lessonTile).join("")}</div>${!items.length ? empty("Bu filtrede içerik bulunamadı. Bu ders için kendi içeriğini ekleyebilirsin.", link("lessonedit/new", "İçerik ekle", "secondary")) : ""}`
  );
}
function notesFor(target) {
  return db.notes
    .filter((n) => n.target === target)
    .map(
      (n) =>
        `<div class="row"><div><p class="prose">${e(n.text)}</p><small>${new Date(n.date).toLocaleDateString("tr-TR")}</small></div>${action("delete-note", "Sil", n.id, "ghost small")}</div>`,
    )
    .join("");
}
function noteForm(target) {
  return `<form data-form="note" data-target="${e(target)}"><label class="field" for="noteText">Kendi notun / alıştırma çözümün</label><textarea id="noteText" name="text" maxlength="20000" required placeholder="Kendi cümlelerinle ne öğrendiğini yaz…"></textarea><button class="btn secondary" type="submit">Notu kaydet</button></form>`;
}
function lessonPage(id) {
  const l = db.lessons.find((x) => x.id === id);
  if (!l) return empty("Ders bulunamadı.", link("lessons", "Derslere dön"));
  const missing = (l.prerequisites || []).filter(
    (x) => !db.completed.includes(x),
  );
  const passed = db.attempts.some(
      (a) => a.lessonId === id && a.correct / a.total >= 0.6,
    ),
    exercise = db.exercises.includes(id),
    canFinish =
      (!l.quiz.length || passed) &&
      (!l.exercise || exercise) &&
      !missing.length;
  return (
    heading(
      e(l.title),
      `${e(l.grade === "9" || l.grade === "10" ? l.grade + ". sınıf" : l.grade)} → ${e(l.subject)} → ${e(l.unit)}`,
      `<div class="row-actions">${action("favorite", db.favorites.includes(id) ? "★ Favoride" : "☆ Favoriye ekle", id, "ghost")}${link("lessonedit/" + id, "Düzenle", "ghost")}</div>`,
    ) +
    `<div class="two-col"><div>${
      missing.length
        ? `<div class="notice warning">Önerilen ön koşul: ${missing
            .map((m) => {
              const p = db.lessons.find((x) => x.id === m);
              return `<a class="text-link" href="#lesson/${e(m)}">${e(p?.title || m)}</a>`;
            })
            .join(
              ", ",
            )}. Konuyu okuyabilirsin; tamamlamak için ön koşulu bitir.</div>`
        : ""
    }${card("Öğrenme hedefi", `<p>${e(l.goal)}</p>${badge(l.status || "Kendi içeriğin", "muted")}`)}${card("Konuyu anlayalım", `<div class="prose">${e(l.body)}</div>`)}${l.example ? card("Birlikte inceleyelim", `<pre class="code">${e(l.example)}</pre>`) : ""}${l.exercise ? card("Sıra sende", `<p class="prose">${e(l.exercise)}</p><label class="check"><input type="checkbox" data-change="exercise" data-id="${e(id)}" ${exercise ? "checked" : ""}> Alıştırmayı yaptım ve çözümümü kontrol ettim.</label>`) : ""}${card("Not defterin", notesFor(id) + noteForm(id))}</div><aside>${card("Konudaki ilerlemen", `<div class="progress"><span style="width:${progress(l)}%"></span></div><p>${progress(l)}% tamamlandı</p><div class="row"><span>Alıştırma</span>${badge(exercise ? "Yapıldı" : l.exercise ? "Bekliyor" : "Gerekmiyor", exercise ? "" : "muted")}</div><div class="row"><span>Mini sınav</span>${badge(passed ? "Başarılı" : l.quiz.length ? "Bekliyor" : "Eklenmedi", passed ? "" : "muted")}</div><p class="input-hint">Tamamlanma: varsa alıştırma, mini sınavda en az %60 ve ön koşullar.</p>${l.quiz.length ? action("lesson-quiz", "Mini sınavı başlat", id, "") : ""}<div class="actions">${action("complete", db.completed.includes(id) ? "✓ Konu tamamlandı" : "Konuyu tamamla", id, "secondary", !canFinish || db.completed.includes(id) ? "disabled" : "")}</div>`)}${card("Öğrenmeyi pekiştir", `<p>Bir cümleyle özetle. Anlatamadığın bir nokta varsa örneğe geri dön.</p>${action("ask-lesson", "✦ Bu konuyu AI’ya sor", id, "ghost")}`)}</aside></div>`
  );
}
function lessonEditor(id) {
  const l = db.lessons.find((x) => x.id === id) || {
    id: "new",
    area: "school",
    subject: "Matematik",
    grade: "9",
    unit: "",
    title: "",
    goal: "",
    body: "",
    example: "",
    exercise: "",
    quiz: [],
  };
  return (
    heading(
      id === "new" ? "Kendi içeriğini oluştur" : "İçeriği düzenle",
      "Metinler cihazında saklanır. Kaynak ve doğrulama durumunu açıkça belirt.",
    ) +
    card(
      "",
      `<form id="lessonEditor" data-id="${e(id)}"><div class="form-grid"><label class="field">Alan<select name="area">${options(["school", "software", "cyber"], l.area)}</select><small>school: okul · software: yazılım · cyber: güvenlik</small></label><label class="field">Sınıf / seviye<input name="grade" value="${e(l.grade)}" maxlength="30" required></label><label class="field">Ders<input name="subject" value="${e(l.subject)}" maxlength="100" list="subjectList" required><datalist id="subjectList">${schoolSubjects.map((s) => `<option>${e(s)}</option>`).join("")}</datalist></label><label class="field">Ünite<input name="unit" value="${e(l.unit)}" maxlength="100" required></label><label class="field span-2">Konu başlığı<input name="title" value="${e(l.title)}" maxlength="200" required></label><label class="field span-2">Öğrenme hedefi<input name="goal" value="${e(l.goal)}" maxlength="1000" required></label><label class="field span-2">Anlatım<textarea name="body" maxlength="30000" required>${e(l.body)}</textarea></label><label class="field span-2">Çözümlü örnek<textarea name="example" maxlength="10000">${e(l.example)}</textarea></label><label class="field span-2">Alıştırma<textarea name="exercise" maxlength="5000">${e(l.exercise)}</textarea></label><label class="field span-2">Kaynak / doğrulama notu<input name="status" value="${e(l.status || "Kullanıcı tarafından eklendi · doğrulanmadı")}" maxlength="500"></label>${!l.quiz.length ? `<label class="field span-2">Mini sınav sorusu (kısa cevap)<input name="quizText" maxlength="3000"></label><label class="field span-2">Kabul edilen tam cevaplar (| ile ayır)<input name="quizAnswers" maxlength="1000" placeholder="örnek cevap | diğer kabul edilen cevap"></label>` : '<p class="span-2 muted">Mevcut mini sınav korunur. Soru bankasından bu ders için yeni testler de oluşturabilirsin.</p>'}</div><div class="actions"><button class="btn">İçeriği kaydet</button>${link(id === "new" ? "lessons" : "lesson/" + id, "Vazgeç", "ghost")}</div></form>`,
    )
  );
}
function testCards(items) {
  return items
    .map(
      (t) =>
        `<div class="row"><div><strong>${e(t.title)}</strong><small>${e(t.subject)} · ${t.questions.length} soru · ${t.minutes ? t.minutes + " dakika" : "Süre sınırı yok"}</small></div><div class="row-actions">${action("start-test", "Testi çöz", t.id, "")}${link("testedit/" + t.id, "Düzenle", "ghost small")}${action("delete-test", "Sil", t.id, "ghost small")}</div></div>`,
    )
    .join("");
}
function testsPage(tab = "list") {
  const bank = db.lessons
    .flatMap((l) => l.quiz)
    .concat(db.tests.flatMap((t) => t.questions))
    .filter((q, i, a) => a.findIndex((x) => x.id === q.id) === i);
  const query = normalize(filters.query);
  const filtered = bank.filter((q) =>
    normalize(q.text + " " + q.tag + " " + q.difficulty).includes(query),
  );
  return (
    heading(
      "Bilgini dene, eksiklerini keşfet.",
      "Kendi testini oluştur veya derslerin mini sınavlarıyla başla.",
      link("testedit/new", "+ Test oluştur", ""),
    ) +
    `<div class="tabs"><a href="#tests" class="${tab === "list" ? "active" : ""}">Testlerim (${db.tests.length})</a><a href="#tests/bank" class="${tab === "bank" ? "active" : ""}">Soru bankası (${bank.length})</a></div>${db.activeAttempt ? `<div class="notice">Yarım kalan test: ${e(db.activeAttempt.test.title)} ${link("attempt", "Kaldığın yerden devam et", "ghost small")}</div>` : ""}${
      tab === "bank"
        ? card(
            "Soru bankası",
            `<form id="bankSearch" class="toolbar"><label class="field search-field">Soru, konu veya zorluk ara<input name="query" value="${e(filters.query)}" maxlength="100"></label><button class="btn secondary">Ara</button>${action("bank-test", "Seçilenlerden test hazırla", "", "")}</form><div id="questionBank">${filtered.map((q) => `<div class="row"><label class="check"><input type="checkbox" name="bankQuestion" value="${e(q.id)}"><span>${e(q.text)}<small>${e(q.tag || "Genel")} · ${e(q.difficulty || "Başlangıç")} · ${q.type === "choice" ? "Çoktan seçmeli" : q.type === "boolean" ? "Doğru / yanlış" : "Kısa cevap"}</small></span></label></div>`).join("") || empty("Aramana uyan soru bulunamadı.")}</div>`,
          )
        : `${card("Oluşturduğun testler", db.tests.length ? testCards(db.tests.filter((t) => normalize(t.title + " " + t.subject).includes(query))) : empty("Henüz kendi testin yok. Soru bankasından seçebilir veya sıfırdan oluşturabilirsin."))}${card(
            "Ders mini sınavları",
            db.lessons
              .filter((l) => l.quiz.length)
              .map(
                (l) =>
                  `<div class="row"><div><strong>${e(l.title)}</strong><small>${e(l.subject)} · ${l.quiz.length} soru · Başlangıç</small></div>${action("lesson-quiz", "Mini sınavı çöz", l.id, "secondary small")}</div>`,
              )
              .join(""),
          )}`
    }`
  );
}
function blankQuestion() {
  return {
    id: uid(),
    type: "choice",
    text: "",
    options: ["", "", "", ""],
    answer: 0,
    explain: "",
    tag: "Genel",
    difficulty: "Başlangıç",
  };
}
function testEditor() {
  const t = editor;
  if (!t)
    return empty("Test taslağı bulunamadı.", link("tests", "Testlere dön"));
  return (
    heading(
      t.isNew ? "Yeni testini oluştur" : "Testini düzenle",
      "Soruları ve cevap anahtarını kaydetmeden önce kontrol et.",
    ) +
    card(
      "",
      `<form id="testEditor"><div class="form-grid"><label class="field">Test adı<input name="title" value="${e(t.title)}" maxlength="200" required></label><label class="field">Ders / kategori<input name="subject" value="${e(t.subject)}" maxlength="100" required></label><label class="field">Süre sınırı (dakika, 0 = sınırsız)<input name="minutes" type="number" min="0" max="240" value="${t.minutes || 0}"></label><label class="check"><input name="randomize" type="checkbox" ${t.randomize ? "checked" : ""}> Soru sırasını karıştır</label></div><div id="questionBuilder">${t.questions.map((q, i) => `<section class="question-editor" data-index="${i}"><h3>Soru ${i + 1} ${action("remove-question", "Kaldır", String(i), "ghost small")}</h3><div class="form-grid"><label class="field">Soru türü<select name="type" data-change="question-type" data-index="${i}"><option value="choice" ${q.type === "choice" ? "selected" : ""}>Çoktan seçmeli</option><option value="boolean" ${q.type === "boolean" ? "selected" : ""}>Doğru / yanlış</option><option value="short" ${q.type === "short" ? "selected" : ""}>Kısa cevap</option></select></label><label class="field">Zorluk<select name="difficulty">${options(["Başlangıç", "Orta", "İleri"], q.difficulty)}</select></label><label class="field span-2">Soru metni<textarea name="text" maxlength="3000" required>${e(q.text)}</textarea></label>${q.type === "choice" ? q.options.map((o, j) => `<label class="field">${"ABCDEF"[j]} seçeneği<input name="option" maxlength="1000" value="${e(o)}" required></label>`).join("") + `<label class="field">Doğru seçenek<select name="answer">${q.options.map((o, j) => `<option value="${j}" ${j === q.answer ? "selected" : ""}>${"ABCDEF"[j]}</option>`).join("")}</select></label>` : q.type === "boolean" ? `<label class="field">Doğru cevap<select name="answer"><option value="true" ${q.answer === true ? "selected" : ""}>Doğru</option><option value="false" ${q.answer === false ? "selected" : ""}>Yanlış</option></select></label>` : `<label class="field span-2">Kabul edilen tam cevaplar (| ile ayır)<input name="answers" value="${e((q.answers || []).join(" | "))}" maxlength="1000" required><small>Büyük/küçük harf ve gereksiz boşluklar yok sayılır. Anlam benzerliği değerlendirilmez.</small></label>`}<label class="field">Konu etiketi<input name="tag" value="${e(q.tag)}" maxlength="100"></label><label class="field span-2">Açıklamalı çözüm<textarea name="explain" maxlength="5000">${e(q.explain)}</textarea></label></div>${q.source ? `<div class="source">Kaynak: sayfa ${q.source.page}\n${e(q.source.text)}</div>` : ""}</section>`).join("")}</div>${t.fromPDF ? '<label class="check"><input name="approved" type="checkbox" required> Taslakları kaynak metinle karşılaştırdım, soruları ve cevapları onaylıyorum.</label>' : ""}<div class="actions">${action("add-question", "+ Soru ekle", "", "secondary")}<button class="btn">Testi kaydet</button>${link("tests", "Vazgeç", "ghost")}</div></form>`,
    )
  );
}
function readTestEditor() {
  const f = $("#testEditor");
  if (!f) return;
  const data = new FormData(f);
  editor.title = String(data.get("title")).trim();
  editor.subject = String(data.get("subject")).trim();
  editor.minutes = Number(data.get("minutes"));
  editor.randomize = data.has("randomize");
  editor.questions = [...f.querySelectorAll(".question-editor")].map(
    (block, i) => {
      const value = (name) =>
        block.querySelector(`[name="${name}"]`)?.value ?? "";
      const q = {
        ...editor.questions[i],
        type: value("type"),
        text: value("text").trim(),
        difficulty: value("difficulty"),
        tag: value("tag"),
        explain: value("explain"),
      };
      if (q.type === "choice") {
        q.options = [...block.querySelectorAll("[name=option]")].map((x) =>
          x.value.trim(),
        );
        if (!q.options.length) q.options = ["", "", "", ""];
        q.answer = Number(value("answer")) || 0;
        delete q.answers;
      } else if (q.type === "boolean") {
        q.answer = value("answer") === "true";
        delete q.options;
        delete q.answers;
      } else {
        q.answers = value("answers")
          .split("|")
          .map((x) => x.trim())
          .filter(Boolean);
        delete q.options;
        delete q.answer;
      }
      return q;
    },
  );
}
function attemptPage() {
  const a = db.activeAttempt;
  if (!a) return empty("Devam eden testin yok.", link("tests", "Testlere git"));
  const q = a.test.questions[a.index],
    answer = a.answers[a.index];
  return (
    heading(
      e(a.test.title),
      "Cevabın her seçimde kaydedilir. Sayfayı yenilesen de kaldığın yerden devam edebilirsin.",
    ) +
    card(
      "",
      `<div class="quiz-meta"><span>Soru ${a.index + 1} / ${a.test.questions.length}</span><span id="testClock">${a.deadline ? "Süre hesaplanıyor…" : "Süre sınırı yok"}</span></div><div class="progress"><span style="width:${((a.index + 1) / a.test.questions.length) * 100}%"></span></div><p class="question-text">${e(q.text)}</p><div id="answerArea">${q.type === "choice" ? q.options.map((o, i) => `<label class="answer-option"><input name="answer" type="radio" value="${i}" data-change="answer" ${answer === i ? "checked" : ""}> <span>${"ABCDEF"[i]}. ${e(o)}</span></label>`).join("") : q.type === "boolean" ? [true, false].map((v) => `<label class="answer-option"><input type="radio" name="answer" value="${v}" data-change="answer" ${v === answer ? "checked" : ""}>${v ? "Doğru" : "Yanlış"}</label>`).join("") : `<label class="field" for="shortAnswer">Kısa cevabın</label><input id="shortAnswer" data-input="short-answer" value="${e(answer ?? "")}" maxlength="300" placeholder="Cevap anahtarına göre değerlendirilecek"><p class="input-hint">Yalnızca kabul edilen tam cevaplar değerlendirilir. Farklı yazılan anlamca benzer yanıtlar için sonuçtan sonra açıklamayı incele.</p>`}</div>${q.source ? `<small>Kaynak: sayfa ${q.source.page}. Cevap ve dayanak metni sonuçta gösterilecek.</small>` : ""}<div class="actions">${action("previous-question", "← Önceki", "", "ghost", a.index === 0 ? "disabled" : "")}${action("next-question", a.index === a.test.questions.length - 1 ? "Testi bitir" : "Sonraki soru →", "", "")}${link("tests", "Kaydedip ara ver", "ghost")}${action("cancel-attempt", "Testi iptal et", "", "ghost small")}</div>`,
    )
  );
}
function resultPage(id) {
  const a = db.attempts.find((x) => x.id === id) || lastResult;
  if (!a) return empty("Sonuç bulunamadı.", link("reports", "Raporlara git"));
  return (
    heading(
      "Bir adım daha ilerledin.",
      e(a.title),
      link("tests", "Testlere dön", "ghost"),
    ) +
    `<div class="two-col">${card("Test sonucun", `<div class="result-big">%${Math.round((a.correct / a.total) * 100)}</div><p>${a.correct} doğru · ${a.total - a.correct} yanlış / boş · ${a.total} soru</p><p>${Math.floor((a.seconds || 0) / 60)} dk ${(a.seconds || 0) % 60} sn geçen test süresi</p>${(a.results || []).some((r) => !r.correct) ? action("retry-wrong", "Yanlışlarımı tekrar çöz", a.id, "") : ""}${a.lessonId ? `<div class="actions">${link("lesson/" + a.lessonId, "Konuya geri dön", "secondary")}</div>` : ""}`)}${card("Sonraki adım", `<p>${a.correct === a.total ? "Harika, tüm cevapların doğru. Konuyu kendi cümlelerinle açıklayarak pekiştir." : "Aşağıdaki açıklamaları incele. Yanlış ve boş cevapların tekrar kartlarına eklendi."}</p>${link("review", "Tekrar kartlarını aç", "secondary")}`)}</div>${card("Cevaplarını incele", (a.results || []).map((r, i) => `<details ${r.correct ? "" : "open"}><summary><span class="${r.correct ? "correct" : "incorrect"}">${r.correct ? "✓" : "×"}</span> ${i + 1}. ${e(r.question.text)}</summary><p>Senin cevabın: ${e(r.answer === null ? "Boş" : r.question.type === "choice" ? r.question.options[r.answer] : r.question.type === "boolean" ? (r.answer ? "Doğru" : "Yanlış") : r.answer)}</p><p class="correct">Doğru cevap: ${e(answerText(r.question))}</p><p>${e(r.question.explain || "Bu soru için ayrıntılı açıklama eklenmemiş.")}</p>${r.question.source ? `<div class="source">Sayfa ${r.question.source.page}: ${e(r.question.source.text)}</div>` : ""}${action("ask-wrong", "✦ Bu soruyu AI ile incele", a.id + ":" + i, "ghost small")}</details>`).join("") || empty("Eski sürümden aktarılan sonuçlarda soru ayrıntıları bulunmuyor."))}`
  );
}
function reviewPage() {
  const items = due();
  return (
    heading(
      "Hatırla, pekiştir, ilerle.",
      "Yanlış ve boş cevapların burada birikir. Cevabı düşün, sonra açıp kendini değerlendir.",
    ) +
    `<div class="stats">${stat("Bugün hazır", items.length, "Tekrar zamanı gelen kart", "review")}${stat("Tüm kartlar", db.review.length, "Yanlışlar ve belge kartları", "tests")}${stat("İleri tarihli", db.review.length - items.length, "Planlanan tekrarlar", "calendar")}${stat(
      "Yanlış / boş",
      db.attempts.reduce((n, a) => n + a.total - a.correct, 0),
      "Tamamlanan testlerden",
      "reports",
    )}</div>${items.length ? items.map((r) => card("", `<div class="quiz-meta">${badge(r.question.tag || "Genel", "blue")}<span>Aralık: ${r.interval} gün</span></div><h2 class="question-text">${e(r.question.text)}</h2>${shownReview.has(r.id) ? `<p class="correct">${e(answerText(r.question))}</p><p>${e(r.question.explain)}</p>${r.question.source ? `<div class="source">Sayfa ${r.question.source.page}: ${e(r.question.source.text)}</div>` : ""}<div class="actions">${action("remember", "Hatırladım", r.id, "")}${action("forget", "Zorlandım", r.id, "secondary")}</div>` : action("reveal", "Cevabı göster", r.id, "secondary")}`)).join("") : card("", empty("Bugün bekleyen tekrarın yok.", link("tests", "Bir test çöz", "secondary")))}${card(
      "Tekrar takvimi",
      db.review.length
        ? db.review
            .slice()
            .sort((a, b) => a.due.localeCompare(b.due))
            .slice(0, 30)
            .map(
              (r) =>
                `<div class="row"><div><strong>${e(r.question.text.slice(0, 120))}</strong><small>${e(r.due)} · ${r.interval} gün aralık</small></div>${badge(r.due <= day() ? "Bugün hazır" : "Planlandı", r.due <= day() ? "" : "muted")}</div>`,
            )
            .join("")
        : empty("Test çözdükçe ve belge kartları ekledikçe takvimin oluşacak."),
    )}`
  );
}
function coachPage() {
  const st = stats(db),
    weak = Object.entries(st.topics)
      .filter(([, t]) => t.correct / t.total < 0.7)
      .sort((a, b) => a[1].correct / a[1].total - b[1].correct / b[1].total),
    todaySeconds = db.sessions
      .filter((s) => s.date === day())
      .reduce((n, s) => n + s.seconds, 0),
    remaining = Math.max(
      0,
      db.settings.dailyMinutes - Math.floor(todaySeconds / 60),
    ),
    next = nextLesson(),
    reviewMinutes = Math.min(remaining, Math.max(0, due().length * 2));
  const days = [
    "Pazartesi",
    "Salı",
    "Çarşamba",
    "Perşembe",
    "Cuma",
    "Cumartesi",
    "Pazar",
  ];
  return (
    heading(
      "Bugün kendine zaman ayır.",
      "Planın gerçek ilerlemene göre hazırlanır. Küçük ve sürdürülebilir adımlar seç.",
    ) +
    `<div class="two-col"><div>${card("Bugünkü çalışma planın", `<p>Hedefin ${db.settings.dailyMinutes} dakika. Kaydedilen odak sürene göre ${remaining} dakika kaldı.</p>${due().length ? `<div class="row"><div><strong>01 · Tekrarlarını tamamla</strong><small>${due().length} hazır kart · öneri: ${reviewMinutes} dakika</small></div>${link("review", "Başla", "ghost small")}</div>` : ""}<div class="row"><div><strong>${due().length ? "02" : "01"} · ${e(next.title)}</strong><small>Yeni konu ve alıştırma · ${Math.max(0, remaining - reviewMinutes)} dakika ayırabilirsin</small></div>${link("lesson/" + next.id, "Derse git", "ghost small")}</div>${weak.length ? `<div class="row"><div><strong>Zorlandığın konu: ${e(weak[0][0])}</strong><small>${weak[0][1].total} soruda ${weak[0][1].correct} doğru · veri arttıkça öneri anlam kazanır.</small></div>${link("review", "Tekrar et", "ghost small")}</div>` : ""}<p class="input-hint">Bu plan kural tabanlıdır. Süreler öneridir; yapılmış çalışma gibi kaydedilmez.</p>${action("ai-coach", "✦ İlerlemeni AI ile değerlendir", "", "secondary")}`)}${card("Haftalık planın", `<form id="weeklyPlan"><div class="plan-grid">${days.map((name, i) => `<label class="field">${name}<input name="day${i}" maxlength="200" value="${e(db.settings.weeklyPlan[i])}" placeholder="Konu veya küçük bir hedef…"></label>`).join("")}</div><div class="actions"><button class="btn secondary">Haftalık planı kaydet</button></div></form>`)}</div><aside>${card("Odak sayacı", `<span class="tag muted">İsteğe bağlı</span><div class="timer-display" id="focusClock">25:00</div><p id="focusStatus">Bir konu seç, dikkatini tek bir işe ver.</p>${db.timer ? action("stop-timer", "Bitir ve süreyi kaydet", "", "") : `<label class="field" for="focusMinutes">Odak süresi (dakika)</label><input id="focusMinutes" type="number" min="1" max="240" value="25"><div class="actions">${action("start-timer", "Odaklanmaya başla", "", "")}</div>`}<p class="input-hint">Sayfa yenilense de sayaç sürer. Süre dolunca sayfada mola hatırlatılır. Sistem bildirimi gönderilmez.</p>`)}${card("Günlük hedef", `<form id="dailyGoal"><label class="field" for="dailyMinutes">Dakika / gün</label><input id="dailyMinutes" name="minutes" type="number" min="5" max="480" value="${db.settings.dailyMinutes}" required><div class="actions"><button class="btn secondary">Hedefi güncelle</button></div></form>`)}</aside></div>`
  );
}
function reportsPage() {
  const st = stats(db),
    thisWeek = db.sessions
      .filter((s) => s.date >= addDays(day(), -6))
      .reduce((n, s) => n + s.seconds, 0),
    previous = db.sessions
      .filter(
        (s) => s.date >= addDays(day(), -13) && s.date < addDays(day(), -6),
      )
      .reduce((n, s) => n + s.seconds, 0);
  return (
    heading(
      "Öğrenme yolculuğun, sayılarla.",
      "Sonuçların yalnızca yaptığın testlerden ve kaydettiğin çalışmalardan hesaplanır.",
      `<div class="row-actions">${action("export-report", "Raporu indir", "", "secondary")}${action("print", "Yazdır", "", "ghost")}</div>`,
    ) +
    `<div class="stats">${stat("Tamamlanan konu", db.completed.length, db.lessons.length + " konu içinden", "lessons")}${stat("Çözülen soru", st.total, db.attempts.length + " test tamamlandı", "tests")}${stat("Başarı oranı", st.rate === null ? "—" : st.rate + "%", "Doğru / toplam soru", "reports")}${stat("Odak süresi", Math.floor(st.seconds / 60) + " dk", "Yalnızca odak sayacı kayıtları", "clock")}</div><div class="two-col"><div>${card("Son 7 gündeki çalışman", weekChart() + `<p class="input-hint">Bu hafta ${Math.floor(thisWeek / 60)} dakika · önceki 7 gün ${Math.floor(previous / 60)} dakika. ${!previous ? "Karşılaştırma için önceki dönemde yeterli kayıt yok." : ""}</p>`)}${card(
      "Konu bazında başarı",
      Object.keys(st.topics).length
        ? `<div class="table-wrap"><table><thead><tr><th>Konu</th><th>Doğru / toplam</th><th>Başarı</th></tr></thead><tbody>${Object.entries(
            st.topics,
          )
            .map(
              ([tag, t]) =>
                `<tr><td>${e(tag)}</td><td>${t.correct} / ${t.total}</td><td>%${Math.round((t.correct / t.total) * 100)}</td></tr>`,
            )
            .join("")}</tbody></table></div>`
        : empty("Konu analizi ilk tamamlanan testinden sonra oluşacak."),
    )}</div><aside>${card(
      "Test geçmişin",
      db.attempts.length
        ? db.attempts
            .slice()
            .reverse()
            .map(
              (a) =>
                `<a class="row" href="#result/${a.id}"><div><strong>${e(a.title)}</strong><small>${new Date(a.date).toLocaleString("tr-TR")}</small></div>${badge(a.correct + "/" + a.total, "blue")}</a>`,
            )
            .join("")
        : empty("Henüz test sonucu yok."),
    )}${card(
      "Kaydedilen odak oturumları",
      db.sessions.filter((s) => s.seconds > 0).length
        ? db.sessions
            .filter((s) => s.seconds > 0)
            .slice(-10)
            .reverse()
            .map(
              (s) =>
                `<div class="row"><div><strong>${e(s.title || "Odak çalışması")}</strong><small>${s.date}</small></div>${badge(Math.floor(s.seconds / 60) + " dk " + (s.seconds % 60) + " sn", "muted")}</div>`,
            )
            .join("")
        : empty("Odak sayacını kullanınca gerçek sürelerin burada görünecek."),
    )}</aside></div>`
  );
}
function pdfPage(id, pageNumber) {
  const d = db.documents.find((x) => x.id === id);
  if (!d)
    return (
      heading(
        "Belgelerini öğrenmeye dönüştür.",
        "PDF’lerini cihazında tut, sayfa notları al ve kaynaklı taslaklarla çalış.",
      ) +
      card(
        "PDF kitaplığın",
        `<label class="btn secondary backup-file">+ PDF yükle<input type="file" id="pdfUpload" accept=".pdf,application/pdf" hidden></label><p class="input-hint">En fazla 20 MB ve 200 sayfa. Metin ve görüntü cihazında işlenir; belge sunucuya yüklenmez.</p><div id="pdfLoading" role="status"></div>${db.documents.length ? db.documents.map((d) => `<div class="row"><a class="document-row" href="#pdf/${d.id}/1"><span class="document-icon">PDF</span><div><strong>${e(d.name)}</strong><small>${d.pages.length} sayfa · ${d.pages.join("").length.toLocaleString("tr-TR")} karakter</small></div></a>${action("delete-document", "Sil", d.id, "ghost small")}</div>`).join("") : empty("İlk PDF’ini ekle veya aşağıya bir metin yapıştır.")}<details><summary>PDF yerine ders metni ekle</summary><form id="pasteDocument"><label class="field">Belge adı<input name="name" maxlength="200" required></label><label class="field">Metin<textarea name="text" maxlength="100000" required placeholder="Her sayfayı ayırmak için tek satıra --- yazabilirsin."></textarea></label><button class="btn secondary">Metin belgesini ekle</button></form></details>`,
      )
    );
  const p = Math.max(1, Math.min(d.pages.length, Number(pageNumber) || 1)),
    target = d.id + ":" + p,
    tools = documentTools(d.pages);
  return (
    heading(
      e(d.name),
      "Belge ve notların yerel veritabanında saklanır.",
      link("pdf", "← Kitaplığa dön", "ghost"),
    ) +
    `<div class="two-col"><div>${card("", `<div class="row"><div class="row-actions">${link("pdf/" + id + "/" + Math.max(1, p - 1), "←", "ghost small")}<span>Sayfa ${p} / ${d.pages.length}</span>${link("pdf/" + id + "/" + Math.min(d.pages.length, p + 1), "→", "ghost small")}</div>${action("bookmark", d.bookmarks.includes(p) ? "★ Favori sayfa" : "☆ Sayfayı işaretle", id, "ghost small", `data-page="${p}"`)}</div><div class="pdf-canvas-wrap" id="pdfViewer"><canvas id="pdfCanvas" aria-label="PDF sayfa görüntüsü"></canvas><span id="pdfRenderStatus">Belge görüntüsü hazırlanıyor…</span></div><details open><summary>Seçilebilir sayfa metni</summary><div class="pdf-text" id="pdfPageText">${e(d.pages[p - 1] || "Bu sayfada seçilebilir metin yok. Görüntü tabanlı belgeler için OCR gerekir; OCR bu sürüme bağlı değil.")}</div>${action("highlight-selection", "Seçili metni not olarak işaretle", target, "ghost small")}</details>`)}${card("Sayfa notların", notesFor(target) + noteForm(target))}</div><aside>${card("Belgede ara", `<form id="documentSearch" data-id="${id}"><label class="field" for="documentQuery">Aranan kelime</label><input id="documentQuery" name="query" type="search" maxlength="100" required><div class="actions"><button class="btn secondary">Ara</button></div></form><div id="documentMatches"></div>${d.bookmarks.length ? `<h3>Favori sayfalar</h3><div class="chips">${d.bookmarks.map((n) => link("pdf/" + id + "/" + n, String(n), "ghost small")).join("")}</div>` : ""}`)}${card("Belgeden çalışma araçları", `<p class="input-hint">Yerel ve kural tabanlı araçlar. Özet, ilk uygun cümlelerden seçilir; kavramlar sözcük sıklığına dayanır. Anlamsal AI analizi değildir.</p><details><summary>Özet / seçili cümleler</summary>${tools.summary.map((s) => `<p><a class="text-link" href="#pdf/${id}/${s.page}">s. ${s.page}</a> ${e(s.text)}</p>`).join("") || "<p>Yeterli seçilebilir metin yok.</p>"}</details><details><summary>Kavram adayları</summary><div class="chips">${tools.concepts.map(([w, n]) => badge(w + " · " + n, "muted")).join("") || "Metin bulunamadı."}</div></details><div class="actions">${action("pdf-test", "Düzenlenebilir test taslağı", id, "secondary", "" + (!tools.questions.length ? "disabled" : ""))}${action("pdf-cards", "Çalışma kartları ekle", id, "ghost", "" + (!tools.questions.length ? "disabled" : ""))}${action("pdf-ai", "✦ PDF asistanıyla çalış", id, "ghost")}</div>`)}${card("Verilerin senin kontrolünde", `<p>AI’ya yalnızca seçtiğin belge sayfaları, gönderim onayıyla iletilir. Hiçbir belge kendiliğinden dış servise gönderilmez.</p>`)}</aside></div>`
  );
}
function withTimeout(promise, ms, message) {
  let timer;
  return Promise.race([
    promise,
    new Promise((_, reject) => {
      timer = setTimeout(() => reject(Error(message)), ms);
    }),
  ]).finally(() => clearTimeout(timer));
}
async function loadPDFModule() {
  if (!pdfModule) {
    pdfModule = await withTimeout(
      import("./vendor/pdf.mjs"),
      15000,
      "PDF kitaplığı yüklenemedi. Sunucu bağlantısını kontrol et.",
    );
    pdfModule.GlobalWorkerOptions.workerSrc = "/vendor/pdf.worker.mjs";
  }
  return pdfModule;
}
async function uploadPDF(file) {
  if (file.size > 20 * 1024 * 1024) throw Error("PDF en fazla 20 MB olabilir.");
  const bytes = new Uint8Array(await file.arrayBuffer());
  if (new TextDecoder().decode(bytes.slice(0, 5)) !== "%PDF-")
    throw Error("Dosya geçerli bir PDF başlığı içermiyor.");
  const status = $("#pdfLoading");
  if (status)
    status.innerHTML =
      '<p><span class="spinner"></span> Belge okunuyor; dosya dışarı gönderilmiyor…</p>';
  let doc, loadingTask;
  const deadline = Date.now() + 45000;
  try {
    const lib = await loadPDFModule();
    loadingTask = lib.getDocument({
      data: bytes,
      isEvalSupported: false,
      standardFontDataUrl: "/vendor/standard_fonts/",
      cMapUrl: "/vendor/cmaps/",
      cMapPacked: true,
    });
    doc = await withTimeout(
      loadingTask.promise,
      20000,
      "PDF açma süresi aşıldı. Daha küçük veya hasarsız bir dosya dene.",
    );
    if (doc.numPages > 200) throw Error("Belge en fazla 200 sayfa olabilir.");
    const pages = [];
    let count = 0;
    for (let i = 1; i <= doc.numPages; i++) {
      if (Date.now() > deadline)
        throw Error(
          "PDF işleme süresi aşıldı. Belgeyi daha küçük parçalara böl.",
        );
      const pg = await withTimeout(
          doc.getPage(i),
          10000,
          "PDF sayfası okunamadı.",
        ),
        text = await withTimeout(
          pg.getTextContent(),
          10000,
          "Sayfa metni okunamadı.",
        );
      const value = text.items
        .map((x) => x.str + (x.hasEOL ? "\n" : " "))
        .join("")
        .trim();
      count += value.length;
      if (value.length > 100000 || count > 1500000)
        throw Error(
          "Çıkarılan metin sınırı aşıldı. Belgeyi bölüp tekrar ekle.",
        );
      pages.push(value);
      pg.cleanup();
      if (status)
        status.textContent = `Sayfa ${i} / ${doc.numPages} işleniyor…`;
    }
    const existing = db.documents.find((d) => d.name === file.name),
      id = existing?.id || uid();
    if (
      existing &&
      !confirm(
        "Aynı adlı belgenin dosyası ve metni güncellenecek. Sayfa numarasıyla tuttuğun notların yeni belgeyle eşleştiğini kontrol et. Devam edilsin mi?",
      )
    )
      return;
    await saveBlob(id, file);
    const item = {
      id,
      name: file.name.slice(0, 200),
      pages,
      bookmarks: (existing?.bookmarks || []).filter((n) => n <= pages.length),
      date: Date.now(),
    };
    db.documents = db.documents.filter((d) => d.id !== id).concat(item);
    await persist();
    await go("pdf/" + id + "/1");
    toast(
      pages.some((p) => p.trim())
        ? "PDF kaydedildi."
        : "PDF kaydedildi; seçilebilir metin yok, OCR gerekir.",
    );
  } finally {
    await loadingTask?.destroy();
    if (status) status.textContent = "";
  }
}
async function renderPDF(id, p) {
  const token = ++pdfToken;
  if (pdfRenderTask) {
    pdfRenderTask.cancel();
    pdfRenderTask = null;
  }
  if (pdfDoc) {
    await pdfDoc.destroy();
    pdfDoc = null;
  }
  const file = await getBlob(id);
  if (token !== pdfToken || !$("#pdfCanvas")) return;
  if (!file) {
    $("#pdfCanvas").hidden = true;
    $("#pdfRenderStatus").textContent =
      "Bu belge metin olarak kayıtlı veya yedekten geri yüklendi. PDF görüntüsü için asıl dosyayı aynı adla yeniden yükle.";
    return;
  }
  try {
    const lib = await loadPDFModule();
    pdfDoc = await lib.getDocument({
      data: new Uint8Array(await file.arrayBuffer()),
      isEvalSupported: false,
      standardFontDataUrl: "/vendor/standard_fonts/",
      cMapUrl: "/vendor/cmaps/",
      cMapPacked: true,
    }).promise;
    if (token !== pdfToken) return;
    const pg = await pdfDoc.getPage(Number(p) || 1),
      canvas = $("#pdfCanvas");
    if (!canvas) return;
    const width = Math.min(
        1000,
        Math.max(250, $("#pdfViewer").clientWidth - 26),
      ),
      viewport = pg.getViewport({ scale: 1 }),
      scaled = pg.getViewport({ scale: width / viewport.width });
    canvas.width = scaled.width * 1.4;
    canvas.height = scaled.height * 1.4;
    canvas.style.width = scaled.width + "px";
    const ctx = canvas.getContext("2d");
    pdfRenderTask = pg.render({
      canvasContext: ctx,
      viewport: scaled,
      transform: [1.4, 0, 0, 1.4, 0, 0],
    });
    await pdfRenderTask.promise;
    if (token === pdfToken && $("#pdfRenderStatus"))
      $("#pdfRenderStatus").hidden = true;
  } catch (err) {
    if (err.name === "RenderingCancelledException") return;
    if ($("#pdfRenderStatus"))
      $("#pdfRenderStatus").textContent =
        "Görüntü açılamadı. Çıkarılan metin ve notların kullanılabilir.";
  }
}
function algoPage() {
  const s = trace.steps[algoIndex];
  return (
    heading(
      "Kodun arkasındaki mantığı gör.",
      "Hazır algoritmaları farklı girdilerle adım adım incele. Bu bir öğretim simülasyonudur.",
    ) +
    `<form id="algoForm" class="toolbar"><label class="field">Algoritma<select name="kind" id="algoKind">${Object.entries(
      algorithmNames,
    )
      .map(
        ([k, v]) =>
          `<option value="${k}" ${k === algoKind ? "selected" : ""}>${v}</option>`,
      )
      .join(
        "",
      )}</select></label><label class="field">${algoKind === "loop" ? "Sayılar (virgülle, boş liste desteklenir)" : algoKind === "condition" ? "Yaş" : "Sayı"}<input name="input" id="algoInput" value="${e(algoInput)}" maxlength="160"></label><label class="field">Adım hızı<select id="algoSpeed" data-change="algo-speed"><option value="1800" ${algoSpeed === 1800 ? "selected" : ""}>Yavaş</option><option value="1000" ${algoSpeed === 1000 ? "selected" : ""}>Normal</option><option value="400" ${algoSpeed === 400 ? "selected" : ""}>Hızlı</option></select></label><button class="btn secondary">Girdiyi uygula</button></form><div class="two-col"><div>${card("Algoritma", `<div class="algorithm-code">${trace.code.map((line, i) => `<span class="algorithm-line ${i + 1 === s.line ? "active" : ""}"><span class="line-number">${i + 1}</span>${e(line)}</span>`).join("")}</div><div class="actions">${action("algo-reset", "↺ Sıfırla", "", "ghost")}${action("algo-back", "← Geri", "", "secondary", algoIndex === 0 ? "disabled" : "")}${action(algoInterval ? "algo-pause" : "algo-play", algoInterval ? "Duraklat" : "▶ Oynat", "", "")}${action("algo-next", "İleri →", "", "secondary", algoIndex === trace.steps.length - 1 ? "disabled" : "")}</div><p class="input-hint">${algoIndex + 1} / ${trace.steps.length} adım · ${algoInterval ? "Oynatılıyor" : algoIndex === trace.steps.length - 1 ? "Tamamlandı" : "Duraklatıldı"}</p>`)}${card("Bu adımda ne oldu?", `<p>${e(s.explain)}</p>${algoIndex < trace.steps.length - 1 ? `<details><summary>Bir sonraki adımda ne olacağını tahmin et, sonra aç.</summary><p>Satır ${trace.steps[algoIndex + 1].line}: ${e(trace.steps[algoIndex + 1].explain)}</p></details>` : '<p class="correct">Simülasyon tamamlandı. Girdiyi değiştirerek sınır durumlarını incele.</p>'}`)}</div><aside>${card(
      "Değişkenler",
      `<div class="variable-grid">${
        Object.entries(s.vars)
          .map(
            ([k, v]) =>
              `<div class="variable"><span>${e(k)}</span><strong>${e(JSON.stringify(v))}</strong></div>`,
          )
          .join("") || empty("Henüz değişken yok.")
      }</div>`,
    )}${card("Konsol çıktısı", `<pre class="code">${e(s.output || "Henüz çıktı üretilmedi.")}</pre>`)}${card(
      "İşlem geçmişi",
      `<ol class="history">${trace.steps
        .slice(0, algoIndex + 1)
        .map((s) => `<li>Satır ${s.line}: ${e(s.explain)}</li>`)
        .join("")}</ol>`,
    )}</aside></div><div class="notice">Bu modül listelenen algoritmalar için hesaplanan yürütme adımlarını simüle eder. Serbest Python veya C kodu çalıştırmaz.</div>`
  );
}
const samples = {
  python:
    "def iki_kati(sayi):\n    return sayi * 2\n\nsonuc = iki_kati(4)\nprint(sonuc)\n",
  c: '#include <stdio.h>\n\nint main(void) {\n    int toplam = 0;\n    for (int i = 1; i <= 3; i++) {\n        toplam += i;\n    }\n    printf("%d\\n", toplam);\n    return 0;\n}\n',
};
function codePage() {
  const f = db.files.find((f) => f.id === selectedFile) || db.files[0];
  selectedFile = f?.id || null;
  return (
    heading(
      "Fikrini koda dönüştür.",
      "Dosyalarını oluştur, düzenle, kontrol et ve cihazında sakla.",
      `<div class="row-actions">${action("new-file", "+ Yeni dosya", "", "")}${action("open-code", "Dosya aç", "", "ghost")}<input id="codeUpload" type="file" accept=".py,.c,.h,.txt" hidden></div>`,
    ) +
    `<div class="tabs">${db.files.map((f) => `<a href="#codelab/${f.id}" class="${selectedFile === f.id ? "active" : ""}">${e(f.name)}</a>`).join("")}</div>${f ? `<div class="two-col"><div>${card("", `<div class="form-grid"><label class="field">Dosya adı<input id="codeFilename" value="${e(f.name)}" maxlength="100"></label><label class="field">Dil<select id="codeLanguage" data-change="code-language">${options(["python", "c"], f.lang)}</select></label></div><p class="input-hint" id="codeSaveStatus">Değişiklikler otomatik kaydedilir. Tab tuşu editörde normal odak gezinmesi yapar.</p><div class="editor-shell"><div class="editor-gutter" id="codeGutter" aria-hidden="true"></div><pre id="codeHighlight" aria-hidden="true"></pre><textarea id="codeEditor" data-input="code" spellcheck="false" autocapitalize="off" autocomplete="off" aria-label="Kaynak kod editörü" maxlength="100000">${e(f.code)}</textarea></div><div class="actions">${action("save-code", "Kaydet / yeniden adlandır", "", "secondary")}${action("check-code", "Sözdizimini kontrol et", "", "")}${action("sample-code", "Örnek ekle", "", "ghost")}${action("download-code", "Dosyayı indir", "", "ghost")}${action("delete-code", "Dosyayı sil", f.id, "ghost small")}</div>`)}${card("Kontrol sonucu", `<div id="codeCheckResult" role="status"><p>Python için sunucudaki AST ayrıştırıcısı kullanılabilir; öğrenci kodu yürütülmez. C için temel parantez/metin denetimi yapılır.</p></div>`)}</div><aside>${card("Çalıştırma", `<div class="notice warning" id="runnerStatus">İzole yürütme bağlantısı kontrol ediliyor…</div><label class="field" for="stdin">Standart girdi (isteğe bağlı)</label><textarea id="stdin" maxlength="10000" placeholder="Programın okuyacağı girdiler…"></textarea><div class="actions">${action("run-code", "Kodu çalıştır", "", "secondary")}</div><pre class="code" id="runOutput" role="status">Henüz kod çalıştırılmadı.</pre><p class="input-hint">Bu sunucu keyfî Python/C kodunu kendi üzerinde çalıştırmaz. RUNNER_URL yalnızca yönetici tarafından izole, süre/bellek/ağ sınırları olan servise bağlanmalıdır.</p>`)}${card("Küçük bir ipucu", `<p>Önce beklediğin çıktıyı yaz. Sonra sınır durumlarını düşün: boş veri, sıfır ve negatif sayılar.</p>${link("algovisual", "Algoritmayı adımlarla incele", "ghost")}`)}</aside></div>` : card("", empty("Henüz kod dosyan yok. Python veya C ile bir dosya oluştur.", action("new-file", "+ Yeni dosya", "", "")))}`
  );
}
function highlightCode() {
  const area = $("#codeEditor");
  if (!area) return;
  const text = area.value;
  let result = "",
    last = 0;
  const regex =
    /(\/\*[\s\S]*?\*\/|\/\/[^\n]*|#[^\n]*|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\b(?:def|return|if|else|elif|for|while|in|import|from|class|try|except|int|void|char|float|double|const|struct|include|True|False|None|break|continue)\b|\b\d+(?:\.\d+)?\b)/g;
  for (const m of text.matchAll(regex)) {
    result += e(text.slice(last, m.index));
    const token = m[0],
      cls = /^(#|\/\/|\/\*)/.test(token)
        ? "comment"
        : /^["']/.test(token)
          ? "string"
          : /^\d/.test(token)
            ? "number"
            : "keyword";
    result += `<span class="token-${cls}">${e(token)}</span>`;
    last = m.index + token.length;
  }
  result += e(text.slice(last));
  $("#codeHighlight").innerHTML = result + "\n";
  $("#codeGutter").textContent = Array.from(
    { length: text.split("\n").length },
    (_, i) => i + 1,
  ).join("\n");
  $("#codeHighlight").scrollTop = area.scrollTop;
  $("#codeHighlight").scrollLeft = area.scrollLeft;
  $("#codeGutter").scrollTop = area.scrollTop;
}
async function saveCode(show = true) {
  const area = $("#codeEditor");
  if (!area) return;
  clearTimeout(codeSaveTimer);
  codeSaveTimer = null;
  const file = db.files.find((f) => f.id === selectedFile);
  if (!file) return;
  const name = $("#codeFilename").value.trim();
  if (!/^[\p{L}\p{N} _.-]{1,100}$/u.test(name) || name === "." || name === "..")
    throw Error(
      "Dosya adı yalnızca harf, sayı, boşluk, nokta, alt çizgi veya tire içerebilir.",
    );
  if (db.files.some((f) => f.id !== file.id && f.name === name))
    throw Error("Bu adla başka bir dosya var.");
  file.name = name;
  file.code = area.value;
  file.lang = $("#codeLanguage").value;
  await persist();
  if ($("#codeSaveStatus"))
    $("#codeSaveStatus").textContent =
      "Kaydedildi · " +
      new Date().toLocaleTimeString("tr-TR", {
        hour: "2-digit",
        minute: "2-digit",
      });
  try {
    const recovery = JSON.parse(
      localStorage.getItem("av-editor-recovery") || "null",
    );
    if (recovery?.id === file.id && recovery.code === file.code)
      localStorage.removeItem("av-editor-recovery");
  } catch {}
  if (show) toast("Kod ve dosya adı kaydedildi.");
}
let aiDraft = "",
  aiDocId = null;
function aiPage() {
  return (
    heading(
      "Birlikte daha iyi anlayalım.",
      "Kendi seviyene uygun açıklamalar, ipuçları ve çalışma önerileri.",
    ) +
    `<div class="two-col"><div>${card("AI ders asistanı", `<div class="chips">${action("ai-prompt", "Python’u örneklerle öğret", "python", "ghost small")}${action("ai-prompt", "İpuçlarıyla yardımcı ol", "hint", "ghost small")}${action("ai-prompt", "Haftalık plan öner", "plan", "ghost small")}</div><div class="chat-history" id="chatHistory">${chat.length ? chat.map((m) => `<div class="chat-message ${m.role}"><small>${m.role === "user" ? "Sen" : "AI asistanı"}</small><p>${e(m.content)}</p></div>`).join("") : empty("Bir konu seç veya aklındaki soruyu yaz. Gerçek yanıtlar için sunucuda AI bağlantısı gerekir.")}${busyAI ? '<div class="loading"><span class="spinner"></span> Yanıt bekleniyor…</div>' : ""}</div><form id="aiForm"><label class="field" for="aiPrompt">Mesajın</label><textarea id="aiPrompt" name="message" maxlength="6000" required placeholder="Örneğin: Fonksiyon kavramını günlük hayattan bir örnekle anlat.">${e(aiDraft)}</textarea><label class="field">Öğretme biçimi<select name="mode"><option value="explain">Adım adım anlat</option><option value="hint">Önce ipucu ver</option></select></label><label class="check"><input name="study" type="checkbox"> Test özetimi ve tamamlanan konularımı bu isteğe ekle</label><label class="field">Belge bağlamı (isteğe bağlı)<select name="document" id="aiDocument"><option value="">Belge gönderme</option>${db.documents.map((d) => `<option value="${d.id}" ${d.id === aiDocId ? "selected" : ""}>${e(d.name)}</option>`).join("")}</select></label><label class="field">Gönderilecek sayfalar<input name="pages" value="1" placeholder="Örn. 1, 3, 5-7" maxlength="100"></label><p class="input-hint">Belge seçilirse gönderilecek metin ve sayfalar onay ekranında gösterilir. En fazla 18.000 karakter iletilir. İlerleme özeti ve mesajın seçili sağlayıcıya gider.</p><div class="actions"><button class="btn" ${busyAI ? "disabled" : ""}>${busyAI ? "Yanıt bekleniyor…" : "✦ Mesajı gönder"}</button>${action("clear-chat", "Sohbeti temizle", "", "ghost", busyAI ? "disabled" : "")}</div></form>`)}<div id="aiConsent"></div></div><aside>${card("Bağlantı durumu", `<div id="aiStatus" role="status"><span class="spinner"></span> Kontrol ediliyor…</div><p class="input-hint">API anahtarı tarayıcıya aktarılmaz. Sağlayıcı, model, istek ve çıktı sınırları sunucu ortamından ayarlanır.</p>`)}${card("Gizlilik tercihin", `<label class="check"><input type="checkbox" data-change="save-chat" ${db.settings.saveChat ? "checked" : ""}> Sohbeti bu cihazda sakla</label><p class="input-hint">Kapalıyken konuşma yalnızca bu açık sayfanın belleğinde tutulur. Yenilemede silinir. Anahtar yoksa sahte AI yanıtı oluşturulmaz.</p>`)}${card("İyi bir soru nasıl sorulur?", `<p>Konuyu, seviyeni ve hangi adımda takıldığını belirt. İstersen “Cevabı hemen söyleme, önce ipucu ver” diye ekle.</p><p class="input-hint">Belge yanıtlarındaki kaynakları kontrol et. AI hata yapabilir; doğrulanmış cevap anahtarının yerini almaz.</p>`)}</aside></div>`
  );
}
function settingsPage() {
  return (
    heading(
      "Çalışma alanın, senin kontrolünde.",
      "Tercihlerini düzenle ve verilerinin bir kopyasını güvende tut.",
    ) +
    `<div class="two-col"><div>${card("Yedekleme ve geri yükleme", `<p>JSON yedeği; derslerini, notlarını, testlerini, sonuçlarını, kodlarını, belge metinlerini, sınavlarını, planlarını, tekrar tarihlerini, algoritma başarılarını, sanal Linux dosyalarını ve SınavKoçu profillerini, denemelerini, cevaplarını, yanlışlarını ve haftalık raporlarını içerir. PDF’nin orijinal dosyası dahil değildir; ayrıca sakla.</p><div class="actions">${action("export", "Yedeği indir", "", "")}<label class="btn secondary">Yedek yükle<input id="importBackup" type="file" accept=".json,application/json" hidden></label></div><p class="input-hint">Geri yükleme öncesinde mevcut verilerin otomatik yedeği indirilir. İşlem mevcut veri kümesinin yerini alır; farklı yedekleri otomatik birleştirmez. Aynı adlı PDF dosyasını tekrar yükleyerek görüntüsünü bağlayabilirsin.</p>`)}${card("Veriler nerede?", `<p>Bu cihazın tarayıcısındaki IndexedDB veritabanında. Hesap ve cihazlar arası senkronizasyon bu sürüme dahil değil. Tarayıcı verilerini temizlemek kayıtlarını siler.</p><p class="input-hint">Aynı çalışma alanı iki sekmede açıksa eski verinin yeni kaydı ezmesi engellenir. Çakışmada kayıt durur ve yenileme uyarısı gösterilir.</p>${action("request-persistence", "Kalıcı depolama iste", "", "ghost")}<p id="persistenceStatus" class="input-hint"></p>`)}${card("Verilerini sil", `<p>Yalnızca bu uygulamanın yerel verilerini siler. Devam etmeden önce bir yedek indir.</p>${action("erase", "Tüm yerel verileri sil", "", "danger")}`)}</div><aside>${card("Görünüm", `<p>Şu an ${db.settings.theme === "dark" ? "koyu" : "açık"} tema kullanıyorsun.</p>${action("theme", "Temayı değiştir", "", "secondary")}`)}${card("Bu sürüm hakkında", `<p>AlgoVisual × DersArkadaşı 2.1 · SınavKoçu</p><p class="input-hint">Gerçek AI için Gemini API anahtarı gerekir. Anahtar yalnızca sunucudaki .env dosyasında tutulur. Python/C çalıştırma için ayrı izole servis gerekir. C denetimi temel sözdizimi kontrolüdür; derleyici değildir. OCR ve kapsamlı müfredat doğrulaması tamamlanmamıştır.</p>${link("reports", "Gerçek çalışma verilerimi gör", "ghost")}`)}</aside></div>`
  );
}
function searchPage(query) {
  const q = normalize(query);
  const ls = db.lessons.filter((l) =>
      normalize(l.title + " " + l.body + " " + l.subject).includes(q),
    ),
    ts = db.tests.filter((t) =>
      normalize(t.title + " " + t.subject).includes(q),
    ),
    ds = db.documents.filter((d) =>
      normalize(d.name + " " + d.pages.join(" ")).includes(q),
    ),
    ns = db.notes.filter((n) => normalize(n.text).includes(q));
  return (
    heading(
      "Arama sonuçları",
      `“${e(query)}” için ${ls.length + ts.length + ds.length + ns.length} sonuç.`,
    ) +
    `${card("Dersler ve konular", ls.length ? `<div class="content-list">${ls.map(lessonTile).join("")}</div>` : empty("Eşleşen ders bulunamadı."))}${card("Testler", ts.length ? testCards(ts) : empty("Eşleşen test bulunamadı."))}${card("Belgeler", ds.map((d) => `<a class="row" href="#pdf/${d.id}/1"><strong>${e(d.name)}</strong><span>Belgeyi aç →</span></a>`).join("") || empty("Eşleşen belge bulunamadı."))}${card("Notlar", ns.map((n) => `<div class="row"><p class="prose">${e(n.text)}</p>${link(n.target.includes(":") ? "pdf/" + n.target.replace(":", "/") : "lesson/" + n.target, "Kaynağa git", "ghost small")}</div>`).join("") || empty("Eşleşen not bulunamadı."))}`
  );
}
function render() {
  if (!db) return;
  const [page, id, extra] = route();
  v2Module?.leave(page);
  if (page !== "algovisual" && algoInterval) {
    clearInterval(algoInterval);
    algoInterval = null;
  }
  if (page !== "pdf") {
    pdfToken++;
    if (pdfRenderTask) pdfRenderTask.cancel();
  }
  document.body.classList.remove("menu-open");
  syncMenu();
  updateShell();
  if (v2Routes.includes(page) && !v2Module?.ready(page, id, db)) {
    $("#main").innerHTML =
      '<div class="loading"><span class="spinner"></span> Öğrenme alanı hazırlanıyor…</div>';
    loadV2(page, id).catch((err) => {
      if (route()[0] === page)
        $("#main").innerHTML = card(
          "Modül açılamadı",
          "<p>" +
            e(err.message) +
            "</p><p>İlk açılış için sunucunun çalıştığını kontrol edip sayfayı yenile. Kayıtların silinmedi.</p>",
        );
    });
    return;
  }
  if (page === 'examcoach' && !examModule) {
    $('#main').innerHTML = '<div class="loading"><span class="spinner"></span> SınavKoçu hazırlanıyor…</div>';
    loadExamCoach().then(() => {if (route()[0] === 'examcoach') render();}).catch(err => {
      $('#main').innerHTML = card('SınavKoçu açılamadı', '<p>'+e(err.message)+'</p><p>İlk açılış için sunucu bağlantısını kontrol edip yenile. Kayıtların silinmedi.</p>');
    });
    return;
  }
  let html;
  switch (page) {
    case 'examcoach':
      html = examModule.renderPage(examContext());
      break;
    case "dashboard":
      html = dashboard();
      break;
    case "lessons":
      html = catalog("school");
      break;
    case "academy":
      html = catalog("software");
      break;
    case "cyber":
      html = catalog("cyber");
      break;
    case "lesson":
      if (db.recent[0] !== id && db.lessons.some((l) => l.id === id)) {
        db.recent = [id, ...db.recent.filter((x) => x !== id)].slice(0, 20);
        persist().catch((err) => toast(err.message, true));
      }
      html = lessonPage(id);
      break;
    case "lessonedit":
      html = lessonEditor(id || "new");
      break;
    case "tests":
      html = testsPage(id || "list");
      break;
    case "testedit":
      if (!editor || editor.routeId !== (id || "new")) {
        const existing = db.tests.find((x) => x.id === id);
        editor = existing
          ? { ...structuredClone(existing), routeId: id, isNew: false }
          : {
              id: uid(),
              title: "",
              subject: "Genel",
              minutes: 0,
              randomize: false,
              questions: [blankQuestion()],
              isNew: true,
              routeId: id || "new",
            };
      }
      html = testEditor();
      break;
    case "attempt":
      html = attemptPage();
      break;
    case "result":
      html = resultPage(id);
      break;
    case "pdf":
      html = pdfPage(id, extra);
      break;
    case "review":
      html = v2Module.renderPage(page, id, v2Context());
      break;
    case "coach":
      html = v2Module.renderPage(page, id, v2Context());
      break;
    case "playground":
    case "linuxlab":
      html = v2Module.renderPage(page, id, v2Context());
      break;
    case "reports":
      html = reportsPage();
      break;
    case "algovisual":
      html = algoPage();
      break;
    case "codelab":
      if (id) selectedFile = id;
      html = codePage();
      break;
    case "ai":
      html = aiPage();
      break;
    case "settings":
      html = settingsPage();
      break;
    case "search":
      html = searchPage(id || "");
      break;
    default:
      html = empty(
        "Bu ekran bulunamadı.",
        link("dashboard", "Genel bakışa dön"),
      );
  }
  $("#main").innerHTML = html;
  if (v2Routes.includes(page)) v2Module.afterRender(page, v2Context());
  if (page === 'examcoach') examModule.afterRender(examContext());
  document.title =
    (nav.find((x) => x[0] === page)?.[1] || "Öğrenme alanın") + " · AlgoVisual";
  if (page === "pdf" && id && db.documents.some((d) => d.id === id)) {
    const d = db.documents.find((d) => d.id === id);
    renderPDF(
      id,
      Math.max(1, Math.min(d.pages.length, Number(extra) || 1)),
    ).catch((err) => toast(err.message, true));
  }
  if (page === "codelab") {
    highlightCode();
    const area = $("#codeEditor");
    if (area) area.addEventListener("scroll", highlightCode);
    refreshHealth();
  }
  if (page === "ai") {
    refreshHealth();
    $("#chatHistory").scrollTop = $("#chatHistory").scrollHeight;
  }
  tick();
}
async function refreshHealth() {
  try {
    const res = await fetch("/api/health", { cache: "no-store" });
    health = await res.json();
    if ($("#aiStatus"))
      $("#aiStatus").innerHTML = health.aiConfigured
        ? `<div class="notice">AI yapılandırıldı · ${e(health.model)} · ${e(health.provider || "yapılandırılan sağlayıcı")} · Bağlantı ilk mesajda doğrulanır.</div>`
        : `<div class="notice warning">API anahtarı henüz eklenmedi. ${e(health.model || "AI modeli")} için sunucudaki .env dosyasına ${e(health.keyEnv || "GEMINI_API_KEY")} ekle ve sunucuyu yeniden başlat. Anahtarı sohbet kutusuna yazma.</div>`;
    if ($("#runnerStatus")) {
      $("#runnerStatus").textContent = health.runnerConfigured
        ? "İzole çalıştırma servisi yapılandırıldı. Çalıştır düğmesi kodu bu servise gönderir."
        : "İzole çalıştırma servisi bağlı değil. Kod bu cihazda çalıştırılmayacak; editör ve denetim kullanılabilir.";
    }
  } catch {
    health = null;
    if ($("#aiStatus"))
      $("#aiStatus").innerHTML =
        '<div class="notice warning">Sunucuya ulaşılamıyor. Çevrimdışı ders, test ve notlar kullanılabilir; AI için bağlantı gerekiyor.</div>';
    if ($("#runnerStatus"))
      $("#runnerStatus").textContent =
        "Çevrimdışısın veya sunucu kapalı. Kod yürütmesi kullanılamıyor.";
  }
}
function download(name, value, type = "application/json") {
  const url = URL.createObjectURL(
      new Blob(
        [typeof value === "string" ? value : JSON.stringify(value, null, 2)],
        { type },
      ),
    ),
    a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function exportBackup() {
  download("algovisual-yedek-" + day() + ".json", {
    format: "algovisual",
    exportedAt: new Date().toISOString(),
    state: db,
  });
}
async function beginTest(test) {
  if (!validateTest(test)) throw Error("Test veya cevap anahtarı geçersiz.");
  if (
    db.activeAttempt &&
    !confirm(
      "Yarım kalan testin var. Yeni teste başlamak mevcut test ilerlemesinin yerini alacak. Devam edilsin mi?",
    )
  )
    return;
  db.activeAttempt = startAttempt(test, test.randomize);
  await persist();
  await go("attempt");
}
async function finishTest(timed = false) {
  const a = db.activeAttempt;
  if (!a) return;
  if (
    !timed &&
    a.answers.filter((v) => v !== undefined && v !== null && v !== "").length <
      a.test.questions.length &&
    !confirm(
      "Boş soruların var. Testi bitirip boşları yanlış olarak değerlendirmek istiyor musun?",
    )
  )
    return;
  const result = finalizeAttempt(a);
  if (db.attempts.some((x) => x.id === result.id)) return;
  db.attempts.push(result);
  for (const r of result.results) {
    const existing = db.review.find((x) => x.question.id === r.question.id);
    if (!r.correct) {
      if (existing) {
        existing.due = day();
        existing.interval = 0;
      } else
        db.review.push({
          id: uid(),
          question: structuredClone(r.question),
          due: day(),
          interval: 0,
          repetitions: 0,
        });
    }
  }
  db.activeAttempt = null;
  lastResult = result;
  await persist();
  await go("result/" + result.id);
  toast(
    timed
      ? "Süre doldu; mevcut cevaplarınla sonuç kaydedildi."
      : "Test sonucun kaydedildi.",
  );
}
let pendingAI = null;
async function prepareAI(form) {
  if (busyAI) return;
  const data = new FormData(form),
    message = String(data.get("message")).trim();
  if (!message) throw Error("Önce bir mesaj yaz.");
  await refreshHealth();
  if (!health?.aiConfigured)
    throw Error(
      "AI anahtarı eksik. Sunucudaki .env dosyasına " +
        (health?.keyEnv || "GEMINI_API_KEY") +
        " ekle ve sunucuyu yeniden başlat.",
    );
  const payload = { message, mode: data.get("mode"), history: chat.slice(-8) },
    doc = db.documents.find((d) => d.id === data.get("document"));
  if (data.has("study")) {
    payload.studyConsent = true;
    payload.studyContext = {
      completed: db.lessons
        .filter((l) => db.completed.includes(l.id))
        .map((l) => l.title),
      tests: db.attempts
        .slice(-10)
        .map((a) => ({ title: a.title, correct: a.correct, total: a.total })),
      dueReviews: due().length,
      dailyMinutes: db.settings.dailyMinutes,
    };
  }
  if (doc) {
    const selected = new Set();
    for (const part of String(data.get("pages")).split(",")) {
      const m = part.trim().match(/^(\d+)(?:-(\d+))?$/);
      if (!m) throw Error("Sayfaları 1, 3, 5-7 biçiminde yaz.");
      const from = Number(m[1]),
        to = Number(m[2] || m[1]);
      if (from < 1 || to > doc.pages.length || to < from)
        throw Error("Seçilen sayfa aralığı belgede yok.");
      for (let i = from; i <= to; i++) selected.add(i);
    }
    const context = [...selected]
      .sort((a, b) => a - b)
      .map((n) => `[s. ${n}]\n${doc.pages[n - 1]}`)
      .join("\n\n");
    if (!context.replace(/\[s\. \d+\]/g, "").trim())
      throw Error("Bu sayfalarda gönderilebilecek metin bulunamadı.");
    payload.documentContext = context.slice(0, 18000);
    payload.documentConsent = true;
    pendingAI = payload;
    $("#aiConsent").innerHTML = card(
      "Gönderilecek belge metnini kontrol et",
      `<p><strong>${e(doc.name)}</strong> · ${selected.size} sayfa seçildi · ${payload.documentContext.length.toLocaleString("tr-TR")} karakter gönderilecek${context.length > 18000 ? " (sınır nedeniyle kesildi)" : ""}.</p><p>Bu metin, mesajın${payload.studyConsent ? " ve ilerleme özetin" : ""} ${e(health?.provider || "yapılandırılan AI sağlayıcısı")} adresindeki AI servisine gönderilecek. Sağlayıcının veri koşulları geçerlidir.</p><pre class="code">${e(payload.documentContext)}</pre><div class="actions">${action("confirm-ai", "Onayla ve gönder", "", "")}${action("cancel-ai", "Vazgeç", "", "ghost")}</div>`,
    );
    $("#aiConsent").scrollIntoView({ block: "start", behavior: "smooth" });
    return;
  }
  await sendAI(payload);
}
async function sendAI(payload) {
  pendingAI = null;
  busyAI = true;
  chat.push({ role: "user", content: payload.message });
  aiDraft = "";
  render();
  try {
    const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(45000),
      }),
      data = await res.json();
    if (!res.ok) throw Error(data.error || "AI isteği tamamlanamadı.");
    chat.push({ role: "assistant", content: data.reply });
    if (db.settings.saveChat) {
      db.chat = chat.slice(-80);
      await persist();
    }
  } catch (err) {
    toast(err.message || "AI yanıtı alınamadı. Bağlantıyı kontrol et.", true);
    aiDraft = payload.message;
  } finally {
    busyAI = false;
    if (route()[0] === "ai") render();
  }
}
async function stopTimer(automatic = false) {
  if (!db.timer) return;
  const timer = db.timer;
  db.timer = null;
  const seconds = Math.min(
    timer.duration,
    Math.max(0, Math.floor((Date.now() - timer.startedAt) / 1000)),
  );
  if (seconds > 0)
    db.sessions.push({
      id: uid(),
      date: day(new Date(timer.startedAt)),
      seconds,
      title: "Odak çalışması",
    });
  await persist();
  toast(
    automatic
      ? "Odak süren tamamlandı. Kısa bir mola verebilirsin."
      : "Gerçek odak süren kaydedildi.",
  );
  render();
}
function tick() {
  if (!db) return;
  v2Module?.tick(v2Context());
  examModule?.tick(examContext());
  if ($("#focusClock")) {
    const left = db.timer
      ? Math.max(
          0,
          Math.ceil(
            (db.timer.startedAt + db.timer.duration * 1000 - Date.now()) / 1000,
          ),
        )
      : 25 * 60;
    $("#focusClock").textContent =
      String(Math.floor(left / 60)).padStart(2, "0") +
      ":" +
      String(left % 60).padStart(2, "0");
    if ($("#focusStatus") && db.timer)
      $("#focusStatus").textContent =
        "Odaklanıyorsun. Süre bitince mola hatırlatılacak.";
  }
  if (db.timer && Date.now() >= db.timer.startedAt + db.timer.duration * 1000)
    stopTimer(true).catch((err) => toast(err.message, true));
  const a = db.activeAttempt;
  if (a?.deadline) {
    const left = Math.max(0, Math.ceil((a.deadline - Date.now()) / 1000));
    if ($("#testClock"))
      $("#testClock").textContent =
        `Kalan süre: ${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}`;
    if (!left) finishTest(true).catch((err) => toast(err.message, true));
  }
}
async function handleAction(name, id, button) {
  if (name.startsWith('ec-')) {
    if (!examModule) throw Error('SınavKoçu henüz yüklenmedi.');
    await examModule.action(name, id, button, examContext());
    return;
  }
  if (name.startsWith("v2-")) {
    if (!v2Module) throw Error("Öğrenme alanı henüz yüklenmedi.");
    await v2Module.action(name, id, button, v2Context());
    return;
  }
  switch (name) {
    case "menu":
      document.body.classList.toggle("menu-open");
      syncMenu();
      break;
    case "theme":
      db.settings.theme = db.settings.theme === "dark" ? "light" : "dark";
      document.documentElement.dataset.theme = db.settings.theme;
      localStorage.setItem("av-theme", db.settings.theme);
      await persist();
      if (route()[0] === "settings") render();
      break;
    case "favorite":
      db.favorites = db.favorites.includes(id)
        ? db.favorites.filter((x) => x !== id)
        : db.favorites.concat(id);
      await persist();
      render();
      break;
    case "complete": {
      const l = db.lessons.find((l) => l.id === id),
        passed =
          !l.quiz.length ||
          db.attempts.some(
            (a) => a.lessonId === id && a.correct / a.total >= 0.6,
          );
      if (
        !passed ||
        (l.exercise && !db.exercises.includes(id)) ||
        !(l.prerequisites || []).every((x) => db.completed.includes(x))
      )
        throw Error("Önce alıştırmayı, mini sınavı ve ön koşulları tamamla.");
      if (!db.completed.includes(id)) {
        db.completed.push(id);
        recordEvidence(db, {
          id: "complete:" + id,
          topic: "lesson:" + id,
          source: "lesson",
          correct: true,
          weight: 0.5,
        });
      }
      await persist();
      render();
      toast("Konu tamamlandı. Bir sonraki adıma hazırsın.");
      break;
    }
    case "lesson-quiz": {
      const l = db.lessons.find((x) => x.id === id);
      await beginTest({
        id: "quiz-" + id,
        title: l.title + " · Mini sınav",
        subject: l.subject,
        lessonId: id,
        questions: l.quiz,
        minutes: 0,
      });
      break;
    }
    case "start-test":
      await beginTest(db.tests.find((t) => t.id === id));
      break;
    case "delete-test":
      if (
        confirm(
          "Bu test silinsin mi? Eski sonuçların ve tekrar kartların korunacak.",
        )
      ) {
        db.tests = db.tests.filter((t) => t.id !== id);
        await persist();
        render();
      }
      break;
    case "add-question":
      readTestEditor();
      if (editor.questions.length >= 100)
        throw Error("Bir testte en fazla 100 soru olabilir.");
      editor.questions.push(blankQuestion());
      render();
      break;
    case "remove-question":
      readTestEditor();
      if (editor.questions.length === 1)
        throw Error("Testte en az bir soru olmalı.");
      editor.questions.splice(Number(id), 1);
      render();
      break;
    case "bank-test": {
      const selected = [
          ...document.querySelectorAll("[name=bankQuestion]:checked"),
        ].map((x) => x.value),
        all = db.lessons
          .flatMap((l) => l.quiz)
          .concat(db.tests.flatMap((t) => t.questions)),
        questions = selected.map((id) => all.find((q) => q.id === id));
      if (!questions.length) throw Error("Önce en az bir soru seç.");
      editor = {
        id: uid(),
        title: "Soru bankası testi",
        subject: "Karma",
        minutes: 0,
        questions: structuredClone(questions),
        isNew: true,
        routeId: "new",
      };
      await go("testedit/new");
      break;
    }
    case "next-question": {
      const a = db.activeAttempt;
      if (!a) break;
      if (a.index === a.test.questions.length - 1) await finishTest();
      else {
        a.index++;
        await persist();
        render();
      }
      break;
    }
    case "previous-question":
      if (db.activeAttempt) {
        db.activeAttempt.index = Math.max(0, db.activeAttempt.index - 1);
        await persist();
        render();
      }
      break;
    case "cancel-attempt":
      if (
        confirm(
          "Bu testin devam kaydı silinsin mi? Tamamlanmış sonuçlar korunur.",
        )
      ) {
        db.activeAttempt = null;
        await persist();
        await go("tests");
      }
      break;
    case "retry-wrong": {
      const a = db.attempts.find((x) => x.id === id),
        questions = a.results.filter((r) => !r.correct).map((r) => r.question);
      if (!questions.length) throw Error("Tekrar çözülecek yanlış yok.");
      await beginTest({
        id: uid(),
        title: a.title + " · Yanlışlar",
        subject: "Tekrar",
        questions,
        minutes: 0,
      });
      break;
    }
    case "reveal":
      shownReview.add(id);
      render();
      break;
    case "remember":
    case "forget":
      rateCard(db, id, name === "remember" ? 3 : 1);
      shownReview.delete(id);
      await persist();
      render();
      toast(
        name === "remember"
          ? "Bir sonraki tekrar planlandı."
          : "Kart bugün tekrar için bırakıldı.",
      );
      break;
    case "delete-note":
      if (confirm("Bu not silinsin mi?")) {
        db.notes = db.notes.filter((n) => n.id !== id);
        await persist();
        render();
      }
      break;
    case "start-timer": {
      if (db.learning.activeTask?.startedAt != null)
        throw Error("Önce çalışma planındaki görev sayacını duraklat.");
      const minutes = Number($("#focusMinutes").value);
      if (!Number.isFinite(minutes) || minutes < 1 || minutes > 240)
        throw Error("Odak süresi 1–240 dakika olmalı.");
      db.timer = { startedAt: Date.now(), duration: Math.round(minutes * 60) };
      await persist();
      render();
      break;
    }
    case "stop-timer":
      await stopTimer();
      break;
    case "export-report":
      download("algovisual-rapor-" + day() + ".json", {
        exportedAt: new Date().toISOString(),
        stats: stats(db),
        attempts: db.attempts,
        sessions: db.sessions,
        completed: db.lessons
          .filter((l) => db.completed.includes(l.id))
          .map((l) => l.title),
      });
      toast("Rapor indirildi.");
      break;
    case "print":
      window.print();
      break;
    case "delete-document":
      if (
        confirm(
          "Belge, sayfa notları ve işaretler silinsin mi? Daha önce kaydettiğin test ve kartlar korunacak.",
        )
      ) {
        db.documents = db.documents.filter((d) => d.id !== id);
        db.notes = db.notes.filter((n) => !n.target.startsWith(id + ":"));
        await persist();
        await removeBlob(id);
        render();
      }
      break;
    case "bookmark": {
      const d = db.documents.find((d) => d.id === id),
        p = Number(button.dataset.page);
      d.bookmarks = d.bookmarks.includes(p)
        ? d.bookmarks.filter((n) => n !== p)
        : [...d.bookmarks, p].sort((a, b) => a - b);
      await persist();
      render();
      break;
    }
    case "highlight-selection": {
      const selection = window.getSelection(),
        text = selection?.toString().trim(),
        source = $("#pdfPageText");
      if (
        !text ||
        !source?.contains(selection.anchorNode) ||
        !source.contains(selection.focusNode)
      )
        throw Error("Önce seçilebilir sayfa metninden bir bölüm seç.");
      db.notes.push({
        id: uid(),
        target: id,
        text: "İşaretlenen bölüm: " + text.slice(0, 18000),
        date: Date.now(),
      });
      await persist();
      render();
      toast("Seçilen bölüm sayfa notlarına eklendi.");
      break;
    }
    case "pdf-test": {
      const d = db.documents.find((x) => x.id === id),
        questions = documentTools(d.pages).questions;
      if (!questions.length)
        throw Error("Taslak için yeterli seçilebilir metin yok.");
      editor = {
        id: uid(),
        title: d.name + " · Taslak test",
        subject: "Belge",
        minutes: 0,
        questions,
        isNew: true,
        routeId: "new",
        fromPDF: true,
      };
      await go("testedit/new");
      break;
    }
    case "pdf-cards": {
      const d = db.documents.find((x) => x.id === id),
        questions = documentTools(d.pages).questions;
      let added = 0;
      for (const q of questions) {
        if (
          db.review.some(
            (r) => r.documentId === id && r.question.text === q.text,
          )
        )
          continue;
        db.review.push({
          id: uid(),
          question: q,
          documentId: id,
          due: day(),
          interval: 0,
        });
        added++;
      }
      await persist();
      toast(added + " kaynaklı çalışma kartı eklendi.");
      break;
    }
    case "pdf-ai":
      aiDocId = id;
      aiDraft =
        "Bu belgedeki seçtiğim sayfaları özetle, temel kavramları açıkla ve 3 tekrar sorusu öner. Her bilgi için sayfa referansı ver.";
      await go("ai");
      break;
    case "algo-reset":
      pauseAlgo();
      algoIndex = 0;
      render();
      break;
    case "algo-back":
      pauseAlgo();
      algoIndex = Math.max(0, algoIndex - 1);
      render();
      break;
    case "algo-next":
      pauseAlgo();
      algoIndex = Math.min(trace.steps.length - 1, algoIndex + 1);
      render();
      break;
    case "algo-play":
      if (algoIndex === trace.steps.length - 1) algoIndex = 0;
      algoInterval = setInterval(() => {
        if (route()[0] !== "algovisual") {
          pauseAlgo();
          return;
        }
        algoIndex = Math.min(algoIndex + 1, trace.steps.length - 1);
        if (algoIndex === trace.steps.length - 1) pauseAlgo();
        render();
      }, algoSpeed);
      render();
      break;
    case "algo-pause":
      pauseAlgo();
      render();
      break;
    case "new-file": {
      if ($("#codeEditor")) await saveCode(false);
      if (!$("#newCodeFile"))
        $("#main").insertAdjacentHTML(
          "afterbegin",
          card(
            "Yeni kod dosyası",
            `<form id="newCodeFile"><label class="field" for="newCodeName">Dosya adı (.py veya .c)</label><input id="newCodeName" name="name" value="main.py" maxlength="100" required><div class="actions"><button class="btn">Dosyayı oluştur</button></div></form>`,
          ),
        );
      $("#newCodeName").focus();
      break;
    }
    case "open-code":
      $("#codeUpload").click();
      break;
    case "save-code":
      await saveCode();
      break;
    case "sample-code":
      if (
        $("#codeEditor").value &&
        !confirm("Editördeki kod örnekle değiştirilsin mi?")
      )
        break;
      $("#codeEditor").value = samples[$("#codeLanguage").value];
      highlightCode();
      await saveCode();
      break;
    case "download-code":
      await saveCode(false);
      download(
        $("#codeFilename").value,
        $("#codeEditor").value,
        "text/plain;charset=utf-8",
      );
      break;
    case "delete-code":
      if (confirm("Bu kod dosyası silinsin mi?")) {
        clearTimeout(codeSaveTimer);
        db.files = db.files.filter((f) => f.id !== id);
        selectedFile = null;
        await persist();
        await go("codelab");
      }
      break;
    case "check-code": {
      await saveCode(false);
      const code = $("#codeEditor").value,
        lang = $("#codeLanguage").value;
      let issues = syntaxCheck(code, lang),
        full = false;
      if (lang === "python" && navigator.onLine) {
        try {
          const res = await fetch("/api/code/check", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ code, lang }),
          });
          const data = await res.json();
          if (res.ok && data.available) {
            issues = data.issues;
            full = true;
          }
        } catch {}
      }
      $("#codeCheckResult").innerHTML =
        `<div class="notice ${issues.length ? "warning" : ""}">${issues.length ? issues.map((x) => `<p>Satır ${e(x.line)}: ${e(x.message)}</p>`).join("") : full ? "Python ayrıştırıcısı sözdizimi hatası bulmadı. Kod yürütülmedi." : "Temel parantez, metin ve blok denetiminde sorun bulunmadı."}</div><p class="input-hint">${full ? "AST denetimi çalışma zamanı hatalarını veya programın doğruluğunu değerlendirmez." : lang === "c" ? "Bu kontrol C derleyicisi değildir; tür, başlık ve diğer dil hatalarını bulamayabilir." : "Python ayrıştırıcısı çevrimdışı veya kurulu değil. Yalnızca temel yerel kontrol yapıldı."}</p>`;
      break;
    }
    case "run-code": {
      await saveCode(false);
      $("#runOutput").textContent = "Çalıştırma isteği denetleniyor…";
      try {
        const res = await fetch("/api/code/run", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              code: $("#codeEditor").value,
              lang: $("#codeLanguage").value,
              stdin: $("#stdin").value,
            }),
            signal: AbortSignal.timeout(8000),
          }),
          data = await res.json();
        if (!res.ok) throw Error(data.error || "Çalıştırma tamamlanamadı.");
        $("#runOutput").textContent =
          `Çıkış kodu: ${data.exitCode}\n${data.stdout}${data.stderr ? "\nHata çıktısı:\n" + data.stderr : ""}`;
      } catch (err) {
        $("#runOutput").textContent = err.message;
      }
      break;
    }
    case "ai-prompt": {
      const prompts = {
        python:
          "Python değişkenlerini başlangıç seviyesinde örneklerle anlat ve sonunda 3 soru sor.",
        hint: "Bir sonraki sorumu cevabı hemen söylemeden, ipuçlarıyla çözmeme yardımcı ol.",
        plan: "Haftalık bir çalışma planı öner. Önce hangi derslere ve günlük kaç dakikaya odaklanacağımı sor.",
      };
      aiDraft = prompts[id];
      $("#aiPrompt").value = aiDraft;
      $("#aiPrompt").focus();
      break;
    }
    case "ask-lesson": {
      const l = db.lessons.find((l) => l.id === id);
      aiDraft =
        l.title +
        " konusunu başlangıç seviyesinde, örneklerle öğret. Sonunda bir kontrol sorusu sor.";
      aiDocId = null;
      await go("ai");
      break;
    }
    case "ask-wrong": {
      const pos = id.lastIndexOf(":"),
        a = db.attempts.find((a) => a.id === id.slice(0, pos)),
        r = a.results[Number(id.slice(pos + 1))];
      aiDraft =
        "Bu soruyu ipuçlarıyla açıklayabilir misin?\nSoru: " +
        r.question.text +
        "\nCevap anahtarı: " +
        answerText(r.question) +
        "\nAçıklama: " +
        (r.question.explain || "");
      aiDocId = null;
      await go("ai");
      break;
    }
    case "ai-coach":
      aiDraft =
        "Test sonuçlarımı ve tamamlanan konularımı kullanarak günlük " +
        db.settings.dailyMinutes +
        " dakikalık ölçülebilir bir plan öner. Veri azsa belirt.";
      aiDocId = null;
      await go("ai");
      break;
    case "confirm-ai":
      if (pendingAI) await sendAI(pendingAI);
      break;
    case "cancel-ai":
      pendingAI = null;
      $("#aiConsent").innerHTML = "";
      break;
    case "clear-chat":
      if (confirm("Bu sohbet temizlensin mi?")) {
        chat = [];
        db.chat = [];
        await persist();
        render();
      }
      break;
    case "export":
      exportBackup();
      toast("Yedeğin indirildi. PDF asıllarını ayrıca sakla.");
      break;
    case "request-persistence": {
      const granted = await navigator.storage?.persist?.();
      $("#persistenceStatus").textContent = granted
        ? "Tarayıcı kalıcı depolama izni verdi. Yedek almaya devam et."
        : "Tarayıcı kalıcı depolama izni vermedi veya desteklemiyor. JSON yedeğini düzenli indir.";
      break;
    }
    case "erase": {
      const code = prompt(
        "Bu uygulamanın dersleri, testleri, notları, belgeleri ve kodları silinecek. Önce yedek al. Onay için SİL yaz:",
      );
      if (code !== "SİL") break;
      await clearBlobs();
      localStorage.removeItem("av-editor-recovery");
      db = {
        ...initialState(),
        rev: revision,
        lessons: structuredClone(library),
      };
      chat = [];
      await persist();
      await go("dashboard");
      toast("Yerel veriler temizlendi.");
      break;
    }
    default:
      throw Error("Bu işlem tanınmıyor.");
  }
}
function pauseAlgo() {
  clearInterval(algoInterval);
  algoInterval = null;
}
document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-action]");
  if (button) {
    event.preventDefault();
    if (button.disabled || button.dataset.busy) return;
    button.dataset.busy = "1";
    try {
      await handleAction(button.dataset.action, button.dataset.id, button);
    } catch (err) {
      toast(err.message || "İşlem tamamlanamadı.", true);
    } finally {
      delete button.dataset.busy;
    }
    return;
  }
  const anchor = event.target.closest('a[href^="#"]');
  if (anchor?.getAttribute("href") === "#main") {
    event.preventDefault();
    $("#main").focus();
    $("#main").scrollIntoView({ block: "start" });
    return;
  }
  if (
    anchor &&
    anchor.getAttribute("href") !== "#main" &&
    $("#codeEditor") &&
    !event.ctrlKey &&
    !event.metaKey
  ) {
    event.preventDefault();
    try {
      await saveCode(false);
      await go(anchor.getAttribute("href").slice(1));
    } catch (err) {
      toast(err.message, true);
    }
  }
});
document.addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.target,
    data = new FormData(form);
  try {
    if (form.dataset.ec) {
      await examModule.submit(form, examContext());
      return;
    }
    if (form.dataset.v2) {
      await v2Module.submit(form, v2Context());
      return;
    }
    switch (form.id) {
      case "newCodeFile": {
        const name = String(data.get("name")).trim();
        if (!/^[\p{L}\p{N} _.-]{1,96}\.(py|c)$/u.test(name))
          throw Error("Dosya adı .py veya .c ile bitmeli.");
        if (db.files.some((f) => f.name === name))
          throw Error("Bu adla bir dosya var.");
        const f = {
          id: uid(),
          name,
          lang: name.endsWith(".c") ? "c" : "python",
          code: "",
        };
        db.files.push(f);
        selectedFile = f.id;
        await persist();
        await go("codelab/" + f.id);
        break;
      }
      case "globalSearch": {
        const q = String(data.get("query")).trim();
        if (q) await go("search/" + encodeURIComponent(q));
        break;
      }
      case "filterForm":
        filters = {
          query: String(data.get("query") || ""),
          grade: String(data.get("grade") || "all"),
          subject: String(data.get("subject") || "all"),
          favorite: data.has("favorite"),
        };
        render();
        break;
      case "bankSearch":
        filters.query = String(data.get("query") || "");
        render();
        break;
      case "lessonEditor": {
        const old = db.lessons.find((l) => l.id === form.dataset.id),
          id = old?.id || uid(),
          item = {
            ...old,
            id,
            prerequisites: old?.prerequisites || [],
            quiz: old?.quiz || [],
          };
        for (const key of [
          "area",
          "grade",
          "subject",
          "unit",
          "title",
          "goal",
          "body",
          "example",
          "exercise",
          "status",
        ])
          item[key] = String(data.get(key) || "").trim();
        if (!item.title || !item.body || !item.goal)
          throw Error("Başlık, hedef ve konu anlatımı gerekli.");
        if (!old?.quiz.length && data.get("quizText")) {
          const question = {
            id: uid(),
            type: "short",
            text: String(data.get("quizText")).trim(),
            answers: String(data.get("quizAnswers") || "")
              .split("|")
              .map((x) => x.trim())
              .filter(Boolean),
            explain: "Kabul edilen cevaplar konu sahibi tarafından belirlendi.",
            tag: item.title,
            difficulty: "Başlangıç",
          };
          if (!validateQuestion(question))
            throw Error(
              "Mini sınav için geçerli soru ve en az bir cevap anahtarı gerekli.",
            );
          item.quiz = [question];
        }
        db.lessons = db.lessons.filter((l) => l.id !== id).concat(item);
        await persist();
        await go("lesson/" + id);
        toast("İçerik kaydedildi.");
        break;
      }
      case "testEditor":
        readTestEditor();
        if (editor.fromPDF && !data.has("approved"))
          throw Error("PDF taslaklarını inceleyip onayla.");
        if (!validateTest(editor))
          throw Error(
            "Her sorunun metnini, seçeneklerini ve geçerli cevap anahtarını doldur.",
          );
        const test = structuredClone(editor);
        delete test.isNew;
        delete test.routeId;
        delete test.fromPDF;
        db.tests = db.tests.filter((t) => t.id !== test.id).concat(test);
        await persist();
        editor = null;
        await go("tests");
        toast("Test kaydedildi.");
        break;
      case "weeklyPlan":
        db.settings.weeklyPlan = Array.from({ length: 7 }, (_, i) =>
          String(data.get("day" + i) || "").trim(),
        );
        await persist();
        toast("Haftalık planın kaydedildi.");
        break;
      case "dailyGoal": {
        const n = Number(data.get("minutes"));
        if (!Number.isInteger(n) || n < 5 || n > 480)
          throw Error("Hedef 5–480 dakika olmalı.");
        configureStudyTime(db, n, db.learning.availability);
        await persist();
        render();
        toast("Günlük hedef güncellendi.");
        break;
      }
      case "pasteDocument": {
        const name = String(data.get("name")).trim(),
          text = String(data.get("text")).trim();
        if (!name || !text) throw Error("Belge adı ve metin gerekli.");
        const pages = text
          .split(/^---\s*$/m)
          .filter((x) => x.trim())
          .map((x) => x.trim());
        if (pages.length > 200)
          throw Error("En fazla 200 sayfa ekleyebilirsin.");
        const d = { id: uid(), name, pages, bookmarks: [], date: Date.now() };
        db.documents.push(d);
        await persist();
        await go("pdf/" + d.id + "/1");
        toast("Metin belgesi kaydedildi.");
        break;
      }
      case "documentSearch": {
        const d = db.documents.find((d) => d.id === form.dataset.id),
          q = normalize(data.get("query")),
          matches = d.pages
            .map((text, i) => ({
              text,
              page: i + 1,
              index: normalize(text).indexOf(q),
            }))
            .filter((x) => x.index >= 0);
        $("#documentMatches").innerHTML =
          `<p class="input-hint">${matches.length} sayfada eşleşme</p>` +
          matches
            .map(
              (m) =>
                `<a class="row" href="#pdf/${d.id}/${m.page}"><div><strong>Sayfa ${m.page}</strong><small>${e(m.text.slice(Math.max(0, m.index - 35), m.index + 100))}</small></div></a>`,
            )
            .join("");
        break;
      }
      case "algoForm": {
        const nextKind = String(data.get("kind")),
          nextInput = String(data.get("input")),
          nextTrace = buildTrace(nextKind, nextInput);
        pauseAlgo();
        algoKind = nextKind;
        algoInput = nextInput;
        trace = nextTrace;
        algoIndex = 0;
        render();
        break;
      }
      case "aiForm":
        await prepareAI(form);
        break;
      default:
        if (form.dataset.form === "note") {
          const text = String(data.get("text")).trim();
          if (!text) throw Error("Önce notunu yaz.");
          db.notes.push({
            id: uid(),
            target: form.dataset.target,
            text,
            date: Date.now(),
          });
          await persist();
          render();
          toast("Notun kaydedildi.");
        }
    }
  } catch (err) {
    toast(err.message || "Form kaydedilemedi.", true);
  }
});
document.addEventListener("change", async (event) => {
  const el = event.target;
  try {
    if (el.dataset.v2Change) {
      await v2Module.change(el, v2Context());
      return;
    }
    if (el.dataset.ecChange) {
      await examModule.change(el, examContext());
      return;
    }
    if (el.dataset.change === "exercise") {
      db.exercises = el.checked
        ? [...new Set([...db.exercises, el.dataset.id])]
        : db.exercises.filter((x) => x !== el.dataset.id);
      await persist();
      render();
    }
    if (el.dataset.change === "answer" && db.activeAttempt) {
      const q = db.activeAttempt.test.questions[db.activeAttempt.index];
      db.activeAttempt.answers[db.activeAttempt.index] =
        q.type === "choice" ? Number(el.value) : el.value === "true";
      await persist();
    }
    if (el.dataset.change === "question-type") {
      readTestEditor();
      const q = editor.questions[Number(el.dataset.index)];
      if (q.type === "choice") {
        q.options = q.options?.length ? q.options : ["", "", "", ""];
        q.answer = 0;
      } else if (q.type === "boolean") q.answer = true;
      else q.answers = q.answers?.length ? q.answers : [];
      render();
    }
    if (el.dataset.change === "algo-speed") {
      algoSpeed = Number(el.value);
      if (algoInterval) {
        pauseAlgo();
        await handleAction("algo-play");
      }
    }
    if (el.id === "algoKind") {
      const form = el.closest("form");
      form.querySelector("[name=input]").value =
        el.value === "loop" ? "1, 2, 3" : el.value === "condition" ? "15" : "4";
      form.requestSubmit();
    }
    if (el.dataset.change === "code-language") {
      const f = db.files.find((f) => f.id === selectedFile);
      f.lang = el.value;
      await saveCode(false);
      highlightCode();
    }
    if (el.dataset.change === "save-chat") {
      db.settings.saveChat = el.checked;
      db.chat = el.checked ? chat.slice(-80) : [];
      await persist();
      toast(
        el.checked
          ? "Sohbet bu cihazda saklanacak."
          : "Kaydedilen sohbet silindi; açık konuşma bellekte kalır.",
      );
    }
    if (el.id === "aiDocument") aiDocId = el.value || null;
    if (el.id === "pdfUpload" && el.files[0]) {
      el.disabled = true;
      try {
        await uploadPDF(el.files[0]);
      } finally {
        el.disabled = false;
        el.value = "";
      }
    }
    if (el.id === "codeUpload" && el.files[0]) {
      const file = el.files[0];
      if (file.size > 100000)
        throw Error("Kod dosyası en fazla 100 KB olabilir.");
      if (!/\.(py|c|h|txt)$/i.test(file.name))
        throw Error("Yalnızca .py, .c, .h veya .txt dosyası açılabilir.");
      if (db.files.some((f) => f.name === file.name))
        throw Error(
          "Bu adla bir dosya zaten var. Önce mevcut dosyayı yeniden adlandır.",
        );
      const f = {
        id: uid(),
        name: file.name.slice(0, 100),
        lang: /\.(c|h)$/i.test(file.name) ? "c" : "python",
        code: await file.text(),
      };
      db.files.push(f);
      selectedFile = f.id;
      await persist();
      await go("codelab/" + f.id);
    }
    if (el.id === "importBackup" && el.files[0]) {
      const file = el.files[0];
      if (file.size > 35 * 1024 * 1024)
        throw Error("Yedek en fazla 35 MB olabilir.");
      const parsed = JSON.parse(await file.text()),
        state =
          parsed.format === "algovisual"
            ? parsed.state
            : parsed.schema === 3
              ? parsed
              : migrateLegacy(parsed);
      validateState(state);
      if (
        !confirm(
          `${state.lessons.length} ders, ${state.tests.length} test ve ${state.notes.length} not geri yüklenecek. Mevcut verilerinin bir yedeği indirilecek ve yerini bu veri kümesi alacak. Devam edilsin mi?`,
        )
      )
        return;
      exportBackup();
      db = { ...state, rev: revision, activeAttempt: null, timer: null };
      localStorage.removeItem("av-editor-recovery");
      chat = db.settings.saveChat ? db.chat : [];
      await persist();
      render();
      toast("Yedek geri yüklendi. PDF asıllarını gerekirse yeniden bağla.");
    }
  } catch (err) {
    toast(err.message || "Dosya işlenemedi.", true);
  }
});
document.addEventListener("input", (event) => {
  const el = event.target;
  if (el.dataset.ecChange === 'answer' && el.type === 'text') {
    examModule?.change(el, examContext()).catch(err => toast(err.message, true));
  }
  if (el.dataset.input === "code") {
    highlightCode();
    const f = db.files.find((f) => f.id === selectedFile);
    if (f) {
      f.code = el.value;
      try {
        localStorage.setItem(
          "av-editor-recovery",
          JSON.stringify({ ...f, recoveredAt: Date.now() }),
        );
      } catch {}
    }
    $("#codeSaveStatus").textContent = "Kaydediliyor…";
    clearTimeout(codeSaveTimer);
    codeSaveTimer = setTimeout(
      () => saveCode(false).catch((err) => toast(err.message, true)),
      450,
    );
  }
  if (el.dataset.input === "short-answer" && db.activeAttempt) {
    db.activeAttempt.answers[db.activeAttempt.index] = el.value;
    persist().catch((err) => toast(err.message, true));
  }
  if (el.id === "aiPrompt") aiDraft = el.value;
});
function syncMenu() {
  const collapsed =
    window.matchMedia("(max-width:720px)").matches &&
    !document.body.classList.contains("menu-open");
  $("#sidebar").inert = collapsed;
  document
    .querySelector(".mobile-menu")
    ?.setAttribute("aria-expanded", String(!collapsed));
}
window.addEventListener("resize", syncMenu);
window.addEventListener("hashchange", () => {
  render();
  $("#main").focus({ preventScroll: true });
  window.scrollTo({ top: 0 });
});
window.addEventListener("online", () => {
  updateShell();
  refreshHealth();
});
window.addEventListener("offline", () => {
  updateShell();
  refreshHealth();
});
window.addEventListener("beforeunload", (event) => {
  if (codeSaveTimer) {
    clearTimeout(codeSaveTimer);
    const f = db?.files.find((f) => f.id === selectedFile);
    if (f && $("#codeEditor")) f.code = $("#codeEditor").value;
    persist().catch(() => {});
  }
});
try {
  db = await openStore();
  revision = db.rev;
  try {
    const recovery = JSON.parse(
      localStorage.getItem("av-editor-recovery") || "null",
    );
    if (recovery && recovery.recoveredAt > db.updatedAt) {
      const f = db.files.find((f) => f.id === recovery.id);
      if (
        f &&
        typeof recovery.code === "string" &&
        recovery.code.length <= 100000
      ) {
        f.code = recovery.code;
        await persist();
        localStorage.removeItem("av-editor-recovery");
      }
    }
  } catch {}
  const contentUpdate = await reconcileLessons(db.lessons);
  db.lessons = contentUpdate.lessons;
  const missing = library.filter((l) => !db.lessons.some((x) => x.id === l.id));
  if (missing.length || contentUpdate.updated) {
    db.lessons.push(...structuredClone(missing));
    await persist();
  }
  chat = db.settings.saveChat ? db.chat.slice() : [];
  if (db.examCoach.sessions.some(x => x.status === 'running')) await loadExamCoach();
  render();
  setInterval(tick, 1000);
  if ("serviceWorker" in navigator)
    navigator.serviceWorker
      .register("/sw.js")
      .then((reg) => {
        reg.update().catch(() => {});
      })
      .catch(() => {
        if (!navigator.serviceWorker.controller)
          toast(
            "Çevrimdışı önbellek kurulamadı; çevrim içi kullanım devam eder.",
            true,
          );
      });
} catch (err) {
  $("#main").innerHTML =
    heading("Çalışma alanı açılamadı.", "Kayıtlar otomatik silinmedi.") +
    card(
      "",
      `<div class="notice bad">${e(err.message)}</div><p>Tarayıcının yerel depolama iznini ve boş alanını kontrol et. Eski veritabanı veya JSON yedeği varsa silmeden sakla.</p>`,
    );
}
